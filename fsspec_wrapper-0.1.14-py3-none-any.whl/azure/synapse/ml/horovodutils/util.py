from horovod.spark.common.store import FilesystemStore
from pyspark.sql import SparkSession
from urllib.parse import urlparse


class AdlsStore(FilesystemStore):
    """
    Concrete Azure Filesystem store.

    Parameters
    ----------
    prefix_path: str
        Absolute or relative path in adls where store would be created
    *args:
        Variable number of arguments
    **kwargs: dict
        Extra options that make sense to a particular storage connection, e.g.
        account_name, account_key, credential, etc.

    Examples
    --------
    Create a AdlsStore in primary storage
    >>> store = AdlsStore(prefix_path, train_path = train_path, runs_path = run_path, save_runs = bool)

    Create a AdlsStore by passing linked_service name
    >>> store = AdlsStore(prefix_path, train_path = train_path, runs_path = run_path, save_runs = bool,
                storage_options = {'linked_service': Linked_Service_Name})

    Create a AdlsStore by passing account_key
    >>> store = AdlsStore(prefix_path, train_path = train_path, runs_path = run_path, save_runs = bool,
                storage_options = {'account_name': XXXX, 'account_key': XXXX})

    Create a AdlsStore by passing credential
    >>> store = AdlsStore(prefix_path, train_path = train_path, runs_path = run_path, save_runs = bool,
                storage_options = {'account_name': XXXX, 'credential': XXXX})
    """

    def __init__(self, prefix_path, *args, **kwargs):
        self.prefix_path = self._parse_path(prefix_path)
        self.sparkconf = self._get_spark_config()
        if "storage_options" not in kwargs:
            kwargs["storage_options"] = {"sparkconf": self.sparkconf}
        else:
            kwargs["storage_options"]["sparkconf"] = self.sparkconf
        std_params = [
            "train_path",
            "val_path",
            "test_path",
            "runs_path",
            "save_runs",
            "storage_options",
        ]
        params = dict((k, kwargs[k]) for k in std_params if k in kwargs)
        super().__init__(self.prefix_path, *args, **params)

    def _parse_path(self, url: str):
        parsed_url = urlparse(url)
        if not parsed_url.scheme:
            url = url.lstrip("/")
            url = "abfs://" + url
        elif parsed_url.scheme != "abfs" and parsed_url.scheme != "abfss":
            raise ValueError(
                f"Acceptable url schemes are 'abfs' and 'abfss' but '{parsed_url.scheme}' scheme was passed."
            )
        return url

    def _get_spark_config(self):
        spark = (
            SparkSession.builder.appName("SynapseCredentialPy")
            .config("spark.executor.allowSparkContext", "true")
            .getOrCreate()
        )
        sparkConfigs = {
            "session_token": spark.conf.get("spark.synapse.session.token"),
            "appid": spark.conf.get("spark.app.id"),
            "endpoint": spark.conf.get("spark.tokenServiceEndpoint"),
            "workspace": spark.conf.get("spark.synapse.workspace.name"),
        }
        return sparkConfigs
