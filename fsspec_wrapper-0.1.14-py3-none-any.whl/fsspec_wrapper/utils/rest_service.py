import json
import time
from .common import SynapseCredential
from azure.core.credentials import AccessToken

aad_ep = "https://{}/api/token"
linked_service_ep = "https://{}/api/resolveLinkedService"
cache = {}


class RestServiceClient:
    """
    Swagger UI documentation: https://tokenservice.northeurope.azuresynapse-dogfood.net/swagger/index.html
    """

    def __init__(self, *args, **kwargs):
        self.time_delta = 300
        self.sparkconf = kwargs["sparkconf"]

    def get_account_name_and_credential_of_linked_service(
        self, linked_service: str = ""
    ) -> (str, "SynapseCredential"):
        """Gets account_name and credentials for the given linked service.

        Args:
        linked_service: Linked service name.

        Returns:
        account_name and credentials.

        Raises:
        Exception: If unable to fetch credentials and other details.
        """

        from urllib.parse import urlparse

        try:
            # primary datalake storage linked service name
            if not linked_service:
                workspace_name = self.sparkconf["workspace"]
                linked_service = workspace_name + "-WorkspaceDefaultStorage"

            curr_time = int(time.time())
            token = account_name = token_exp = None
            if linked_service in cache:
                token, account_name, token_exp = cache[linked_service]

            if token is None or curr_time > (token_exp - self.time_delta):
                token_service_endpoint = self.sparkconf["endpoint"]
                url = linked_service_ep.format(token_service_endpoint)
                payload = self._get_payload(audience=linked_service)

                response = self._fetch_token(url, payload)

                account_name = urlparse(response["data"]["serverName"]).netloc.split(
                    "."
                )[0]
                token = response["data"]["token"]
                token_exp = response["data"]["expireTime"]
                cache[linked_service] = (token, account_name, token_exp)

            # SAS token check
            if token.startswith("?"):
                return account_name, token

            _token = AccessToken(token, token_exp)
            credential = SynapseCredential(token=_token)

            return account_name, credential
        except Exception as exception:
            raise Exception(f"Unable to get account_name and credential {exception}")

    def get_aad_credential(self, audience: str) -> "SynapseCredential":
        """Gets AAD credentials.

        Args:
        audience: Audience for resource template.

        Returns:
        credentials.

        Raises:
        Exception: If unable to fetch credentials.
        """
        try:
            curr_time = int(time.time())
            token = token_exp = None
            if audience in cache:
                token, token_exp = cache[audience]

            if token is None or curr_time > (token_exp - self.time_delta):
                token_service_endpoint = self.sparkconf["endpoint"]
                url = aad_ep.format(token_service_endpoint)
                payload = self._get_payload(audience=audience)

                response = self._fetch_token(url, payload)

                token = response["data"]["token"]
                token_exp = response["data"]["expireTime"]

                cache[audience] = (token, token_exp)

            _token = AccessToken(token, int(token_exp))
            credential = SynapseCredential(token=_token)

            return credential
        except Exception as exception:
            raise Exception("Unable to fetch credentials.", exception)

    def _get_payload(self, audience: str):

        jobSessionToken = self.sparkconf["session_token"]
        appId = self.sparkconf["appid"]

        _resource = {"audience": audience, "name": ""}
        resource = json.dumps(_resource)

        payload = {
            "jobSessionToken": jobSessionToken,
            "appId": appId,
            "resource": resource,
        }
        return json.dumps(payload)

    def _fetch_token(self, url, payload):
        try:
            import requests

            headers = {
                "accept": "application/json",
                "Content-Type": "application/json",
            }

            response = requests.post(url, headers=headers, data=payload)
            return json.loads(response.text)

        except Exception as exception:
            raise Exception(exception)
