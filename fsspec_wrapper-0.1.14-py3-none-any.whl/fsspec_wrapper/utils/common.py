class SynapseCredential:  # pylint: disable=too-few-public-methods
    """
    Custom credential class implementation.
    More info: https://github.com/Azure/azure-sdk-for-python/issues/9075#issuecomment-564171752
    """

    def __init__(self, token, **kwargs):
        self.token = token

    async def get_token(self, *scopes, **kwargs):
        return self.token

    async def close(self, *scopes, **kwargs):
        pass
