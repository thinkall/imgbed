import asyncio
import logging
from typing import Any, Optional, TypeVar, Union
from urllib.parse import urlsplit

import adlfs
from adlfs.spec import AzureBlobFileSystem
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ResourceExistsError,
    ResourceNotFoundError,
    map_error,
)
from azure.core.pipeline import PipelineRequest, PipelineResponse
from azure.core.pipeline._base_async import _SansIOAsyncHTTPPolicyRunner
from azure.core.pipeline._tools_async import await_result as _await_result
from azure.core.pipeline.policies import AsyncHTTPPolicy, SansIOHTTPPolicy
from azure.storage.blob._generated.aio.operations._blob_operations import BlobOperations
from azure.storage.blob._models import BlobProperties
from azure.storage.blob._shared import models as _models
from azure.storage.blob.aio import BlobServiceClient as AIOBlobServiceClient
from azure.storage.blob.aio._list_blobs_helper import BlobPrefix
from fsspec.asyn import get_loop
from fsspec.utils import infer_storage_options
from trident_token_library_wrapper import PyTridentTokenLibrary

logger = logging.getLogger(__name__)


def make_credential(token):
    class PandasCredential:
        def __init__(self, token, **kwargs):
            self.token = token

        async def get_token(self, *scopes, **kwargs):
            return self.token

    from azure.core.credentials import AccessToken

    t = AccessToken(
        token=token, expires_on=1684934721
    )  # todo: expires_on may not be needed
    return PandasCredential(token=t)


_ROOT_PATH = "/"


async def _ls(
    self,
    path: str,
    invalidate_cache: bool = False,
    delimiter: str = "/",
    return_glob: bool = False,
    **kwargs,
):
    """
    Create a list of blob names from a blob container

    Parameters
    ----------
    path: str
        Path to an Azure Blob with its container name

    detail: bool
        If False, return a list of blob names, else a list of dictionaries with blob details

    invalidate_cache:  bool
        If True, do not use the cache

    delimiter: str
        Delimiter used to split paths

    return_glob: bool

    """
    logger.debug(f"abfs.ls() is searching for {path}")
    target_path = path.strip("/")
    container, path = self.split_path(path)

    if invalidate_cache:
        self.dircache.clear()

    cache = {}
    cache.update(self.dircache)

    if (container in ["", ".", "*", delimiter]) and (path in ["", delimiter]):
        if _ROOT_PATH not in cache or invalidate_cache or return_glob:
            # This is the case where only the containers are being returned
            logger.info(
                "Returning a list of containers in the azure blob storage account"
            )
            contents = self.service_client.list_containers(include_metadata=True)
            containers = [c async for c in contents]
            files = await self._details(containers)
            cache[_ROOT_PATH] = files

        self.dircache.update(cache)
        return cache[_ROOT_PATH]
    else:
        if target_path not in cache or invalidate_cache or return_glob:
            if container not in ["", delimiter]:
                # This is the case where the container name is passed
                async with self.service_client.get_container_client(
                    container=container
                ) as cc:
                    path = path.strip("/")
                    blobs = cc.walk_blobs(include=["metadata"], name_starts_with=path)

                # Check the depth that needs to be screened
                depth = target_path.count("/")
                outblobs = []
                try:
                    async for next_blob in blobs:
                        if depth in [0, 1] and path == "":
                            outblobs.append(next_blob)
                        elif isinstance(next_blob, BlobProperties):
                            if next_blob["name"].count("/") == depth:
                                outblobs.append(next_blob)
                            elif not next_blob["name"].endswith("/") and (
                                next_blob["name"].count("/") == (depth - 1)
                            ):
                                outblobs.append(next_blob)
                        else:
                            async for blob_ in next_blob:
                                if isinstance(blob_, BlobProperties) or isinstance(
                                    blob_, BlobPrefix
                                ):
                                    if blob_["name"].endswith("/"):
                                        if (
                                            blob_["name"].rstrip("/").count("/")
                                            == depth
                                        ):
                                            outblobs.append(blob_)
                                        elif blob_["name"].count("/") == depth and (
                                            hasattr(blob_, "size")
                                            and blob_["size"] == 0
                                        ):
                                            outblobs.append(blob_)
                                        else:
                                            pass
                                    elif blob_["name"].count("/") == (depth):
                                        outblobs.append(blob_)
                                    else:
                                        pass
                except ResourceNotFoundError:
                    raise FileNotFoundError
                finalblobs = await self._details(
                    outblobs, target_path=target_path, return_glob=return_glob
                )
                if return_glob:
                    return finalblobs
                finalblobs = await self._details(outblobs, target_path=target_path)
                if not finalblobs:
                    if not await self._exists(target_path):
                        raise FileNotFoundError
                    return []
                cache[target_path] = finalblobs
                self.dircache[target_path] = finalblobs

        return cache[target_path]


AsyncHTTPResponseType = TypeVar("AsyncHTTPResponseType")
HTTPRequestType = TypeVar("HTTPRequestType")


class _SansIOAsyncHTTPPolicyRunnerPandas(
    AsyncHTTPPolicy[HTTPRequestType, AsyncHTTPResponseType]
):  # pylint: disable=unsubscriptable-object
    """Async implementation of the SansIO policy.

    Modifies the request and sends to the next policy in the chain.
    OneLake proxy API is sending a 302 or 307 response if the request
    is coming from a different region. Until proxy API is updated to
    handle the redirection, we are overriding the send method to
    redirect the request if the URL found response is received.
    We can remove this once OneLake proxy API handles the redirection.

    :param policy: A SansIO policy.
    :type policy: ~azure.core.pipeline.policies.SansIOHTTPPolicy
    """

    def __init__(self, policy: SansIOHTTPPolicy) -> None:
        super(_SansIOAsyncHTTPPolicyRunner, self).__init__()
        self._policy = policy

    # This is required to redirect the request if 302 or 307 response is received.
    # It can be removed once OneLake proxy API handles the redirection.
    async def send(self, request: PipelineRequest) -> PipelineResponse:
        """Modifies the request and sends to the next policy in the chain.

        Redirects the request if 302 or 307 response is received, this can
        be removed once OneLake proxy API handles the redirection.

        :param request: The PipelineRequest object.
        :type request: ~azure.core.pipeline.PipelineRequest
        :return: The PipelineResponse object.
        :rtype: ~azure.core.pipeline.PipelineResponse
        """
        await _await_result(self._policy.on_request, request)
        try:
            response = await self.next.send(request)  # type: ignore
            status_code = response.http_response.status_code
            if status_code == 302 or status_code == 307:
                request_url = response.http_response.headers["Location"]
                logger.info("Requestiong response from redirection URL")
                logger.debug(f"Request path:{request_url}")
                request.http_request.url = request_url
                response = await self.next.send(request)
        except Exception:  # pylint: disable=broad-except
            if not await _await_result(self._policy.on_exception, request):
                raise
        else:
            await _await_result(self._policy.on_response, request, response)
        return response


async def delete(
    self,
    snapshot: Optional[str] = None,
    version_id: Optional[str] = None,
    timeout: Optional[int] = None,
    delete_snapshots: Optional[Union[str, "_models.DeleteSnapshotsOptionType"]] = None,
    request_id_parameter: Optional[str] = None,
    blob_delete_type: Optional[str] = "Permanent",
    lease_access_conditions: Optional["_models.LeaseAccessConditions"] = None,
    modified_access_conditions: Optional["_models.ModifiedAccessConditions"] = None,
    **kwargs: Any,
) -> None:
    """If the storage account's soft delete feature is disabled then, when a blob is deleted, it is
    permanently removed from the storage account. If the storage account's soft delete feature is
    enabled, then, when a blob is deleted, it is marked for deletion and becomes inaccessible
    immediately. However, the blob service retains the blob or snapshot for the number of days
    specified by the DeleteRetentionPolicy section of [Storage service properties]
    (Set-Blob-Service-Properties.md). After the specified number of days has passed, the blob's
    data is permanently removed from the storage account. Note that you continue to be charged for
    the soft-deleted blob's storage until it is permanently removed. Use the List Blobs API and
    specify the "include=deleted" query parameter to discover which blobs and snapshots have been
    soft deleted. You can then use the Undelete Blob API to restore a soft-deleted blob. All other
    operations on a soft-deleted blob or snapshot causes the service to return an HTTP status code
    of 404 (ResourceNotFound).
    :param snapshot: The snapshot parameter is an opaque DateTime value that, when present,
     specifies the blob snapshot to retrieve. For more information on working with blob snapshots,
     see :code:`<a
     href="https://docs.microsoft.com/en-us/rest/api/storageservices/fileservices/creating-a-snapshot-of-a-blob">Creating
     a Snapshot of a Blob.</a>`.
    :type snapshot: str
    :param version_id: The version id parameter is an opaque DateTime value that, when present,
     specifies the version of the blob to operate on. It's for service version 2019-10-10 and newer.
    :type version_id: str
    :param timeout: The timeout parameter is expressed in seconds. For more information, see
     :code:`<a
     href="https://docs.microsoft.com/en-us/rest/api/storageservices/fileservices/setting-timeouts-for-blob-service-operations">Setting
     Timeouts for Blob Service Operations.</a>`.
    :type timeout: int
    :param delete_snapshots: Required if the blob has associated snapshots. Specify one of the
     following two options: include: Delete the base blob and all of its snapshots. only: Delete
     only the blob's snapshots and not the blob itself.
    :type delete_snapshots: str or ~azure.storage.blob.models.DeleteSnapshotsOptionType
    :param request_id_parameter: Provides a client-generated, opaque value with a 1 KB character
     limit that is recorded in the analytics logs when storage analytics logging is enabled.
    :type request_id_parameter: str
    :param blob_delete_type: Optional.  Only possible value is 'permanent', which specifies to
     permanently delete a blob if blob soft delete is enabled.
    :type blob_delete_type: str
    :param lease_access_conditions: Parameter group.
    :type lease_access_conditions: ~azure.storage.blob.models.LeaseAccessConditions
    :param modified_access_conditions: Parameter group.
    :type modified_access_conditions: ~azure.storage.blob.models.ModifiedAccessConditions
    :keyword callable cls: A custom type or function that will be passed the direct response
    :return: None, or the result of cls(response)
    :rtype: None
    :raises: ~azure.core.exceptions.HttpResponseError
    """
    cls = kwargs.pop("cls", None)  # type: ClsType[None]
    error_map = {
        401: ClientAuthenticationError,
        404: ResourceNotFoundError,
        409: ResourceExistsError,
    }
    error_map.update(kwargs.pop("error_map", {}))

    _lease_id = None
    _if_modified_since = None
    _if_unmodified_since = None
    _if_match = None
    _if_none_match = None
    _if_tags = None
    if lease_access_conditions is not None:
        _lease_id = lease_access_conditions.lease_id
    if modified_access_conditions is not None:
        _if_modified_since = modified_access_conditions.if_modified_since
        _if_unmodified_since = modified_access_conditions.if_unmodified_since
        _if_match = modified_access_conditions.if_match
        _if_none_match = modified_access_conditions.if_none_match
        _if_tags = modified_access_conditions.if_tags
    accept = "application/xml"

    # Construct URL
    url = "{url}/{containerName}/{blob}"  # type: ignore
    path_format_arguments = {
        "url": self._serialize.url(
            "self._config.url", self._config.url, "str", skip_quote=True
        ),
    }
    url = self._client.format_url(url, **path_format_arguments)

    # Construct parameters
    query_parameters = {}  # type: Dict[str, Any]
    if snapshot is not None:
        query_parameters["snapshot"] = self._serialize.query(
            "snapshot", snapshot, "str"
        )
    if version_id is not None:
        query_parameters["versionid"] = self._serialize.query(
            "version_id", version_id, "str"
        )
    if timeout is not None:
        query_parameters["timeout"] = self._serialize.query(
            "timeout", timeout, "int", minimum=0
        )
    if blob_delete_type is not None:
        query_parameters["deletetype"] = self._serialize.query(
            "blob_delete_type", blob_delete_type, "str"
        )

    # Construct headers
    header_parameters = {}  # type: Dict[str, Any]
    if _lease_id is not None:
        header_parameters["x-ms-lease-id"] = self._serialize.header(
            "lease_id", _lease_id, "str"
        )
    if delete_snapshots is not None:
        header_parameters["x-ms-delete-snapshots"] = self._serialize.header(
            "delete_snapshots", delete_snapshots, "str"
        )
    if _if_modified_since is not None:
        header_parameters["If-Modified-Since"] = self._serialize.header(
            "if_modified_since", _if_modified_since, "rfc-1123"
        )
    if _if_unmodified_since is not None:
        header_parameters["If-Unmodified-Since"] = self._serialize.header(
            "if_unmodified_since", _if_unmodified_since, "rfc-1123"
        )
    if _if_match is not None:
        header_parameters["If-Match"] = self._serialize.header(
            "if_match", _if_match, "str"
        )
    if _if_none_match is not None:
        header_parameters["If-None-Match"] = self._serialize.header(
            "if_none_match", _if_none_match, "str"
        )
    if _if_tags is not None:
        header_parameters["x-ms-if-tags"] = self._serialize.header(
            "if_tags", _if_tags, "str"
        )
    header_parameters["x-ms-version"] = self._serialize.header(
        "self._config.version", self._config.version, "str"
    )
    if request_id_parameter is not None:
        header_parameters["x-ms-client-request-id"] = self._serialize.header(
            "request_id_parameter", request_id_parameter, "str"
        )
    header_parameters["Accept"] = self._serialize.header("accept", accept, "str")

    request = self._client.delete(url, query_parameters, header_parameters)
    pipeline_response = await self._client._pipeline.run(
        request, stream=False, **kwargs
    )
    response = pipeline_response.http_response

    if response.status_code not in [202, 200]:
        map_error(
            status_code=response.status_code, response=response, error_map=error_map
        )
        error = self._deserialize.failsafe_deserialize(_models.StorageError, response)
        raise HttpResponseError(response=response, model=error)

    response_headers = {}
    response_headers["x-ms-client-request-id"] = self._deserialize(
        "str", response.headers.get("x-ms-client-request-id")
    )
    response_headers["x-ms-request-id"] = self._deserialize(
        "str", response.headers.get("x-ms-request-id")
    )
    response_headers["x-ms-version"] = self._deserialize(
        "str", response.headers.get("x-ms-version")
    )
    response_headers["Date"] = self._deserialize(
        "rfc-1123", response.headers.get("Date")
    )

    if cls:
        return cls(pipeline_response, None, response_headers)


class OnelakeFileSystem(adlfs.AzureBlobFileSystem):
    """
    Access OneLake File System if it were a file system using Multiprotocol Access

    args and kwargs are passed to ``adlfs.AzureBlobFileSystem``.
    """

    def __init__(self, *args, **kwargs):
        logger.info(f"OnelakeFileSystem: args:{args} | kwargs:{kwargs}")
        account_name = kwargs["account_name"]
        account_host = kwargs["account_host"]
        credential = None

        self.original_kwargs = kwargs.copy()
        kwargs = kwargs["storage_options"] if "storage_options" in kwargs else kwargs

        if "credential" in kwargs:
            credential = kwargs["credential"]
        elif "token" in kwargs:
            token = kwargs["token"]
            credential = make_credential(token)
        else:
            resource = "https://storage.azure.com"
            token = PyTridentTokenLibrary.get_access_token(resource)
            logger.debug(f"assigning token:{token}")
            credential = make_credential(token)

        if not hasattr(self, "account_name") or self.account_name is None:
            self.account_name = account_name
            self.account_host = account_host
        if not hasattr(self, "credential") or self.credential is None:
            self.credential = credential

        logger.debug(f"assigning account_name:{self.account_name}")
        logger.debug(f"assigning account_host:{self.account_host}")
        logger.debug(f"assigning credential:{self.credential}")
        kwargs["account_name"] = self.account_name
        kwargs["credential"] = self.credential

        AzureBlobFileSystem._ls = _ls
        _SansIOAsyncHTTPPolicyRunner.send = _SansIOAsyncHTTPPolicyRunnerPandas.send
        BlobOperations.delete = delete
        super().__init__(*args, **kwargs)

    @classmethod
    def _strip_protocol(cls, path: str) -> str:
        """
        Remove the protocol from the input path

        Parameters
        ----------
        path: str
            Path to remove the protocol from

        Returns
        -------
        str
            Returns a path without the protocol
        """
        STORE_SUFFIX = ".dfs.core.windows.net"
        LAKE_SUFFIX = ".windows-int.net"
        if not path.startswith(("abfs://", "az://", "abfss")):
            path = path.lstrip("/")
            path = "abfs://" + path
        ops = infer_storage_options(path)
        if "username" in ops:
            if ops.get("username", None):
                ops["path"] = ops["username"] + ops["path"]
        # we need to make sure that the path retains
        # the format {host}/{path}
        # here host is the container_name
        elif ops.get("host", None):
            if (
                ops["host"].count(STORE_SUFFIX) == 0
                and ops["host"].count(LAKE_SUFFIX) == 0
            ):  # no store-suffix, so this is container-name
                ops["path"] = ops["host"] + ops["path"]

        return ops["path"]

    def do_connect(self):
        """Connect to the BlobServiceClient, using user-specified connection details.
        Tries credentials first, then connection string and finally account key

        Raises
        ------
        ValueError if none of the connection details are available
        """
        try:
            if self.connection_string is not None:
                self.service_client = AIOBlobServiceClient.from_connection_string(
                    conn_str=self.connection_string
                )
            elif self.account_name is not None:
                if hasattr(self, "account_host"):
                    logger.info(
                        f"AzureBlobFileSystem.do_connect: connecting to host {self.account_host}"
                    )
                    self.account_url: str = f"https://{self.account_host}"
                else:
                    self.account_url: str = (
                        f"https://{self.account_name}.blob.core.windows.net"
                    )
                    logger.info(
                        f"AzureBlobFileSystem.do_connect: connecting to url {self.account_url}"
                    )

                creds = [self.credential, self.account_key]
                if any(creds):
                    self.service_client = [
                        AIOBlobServiceClient(
                            account_url=self.account_url,
                            credential=cred,
                            _location_mode=self.location_mode,
                        )
                        for cred in creds
                        if cred is not None
                    ][0]
                elif self.sas_token is not None:
                    if not self.sas_token.startswith("?"):
                        self.sas_token = f"?{self.sas_token}"
                    self.service_client = AIOBlobServiceClient(
                        account_url=self.account_url + self.sas_token,
                        credential=None,
                        _location_mode=self.location_mode,
                    )
                elif self.anon is False:
                    self._get_default_azure_credential()
                else:
                    # Fall back to anonymous login, and assume public container
                    self.service_client = AIOBlobServiceClient(
                        account_url=self.account_url
                    )
            else:
                raise ValueError(
                    "Must provide either a connection_string or account_name with credentials!!"
                )

        except RuntimeError:
            loop = get_loop()
            asyncio.set_event_loop(loop)
            self.do_connect()

        except Exception as e:
            raise ValueError(f"unable to connect to account for {e}")

    def connect_client(self):
        """Connect to the Asynchronous BlobServiceClient, using user-specified connection details.
        Tries credentials first, then connection string and finally account key

        Raises
        ------
        ValueError if none of the connection details are available
        """
        try:
            if hasattr(self.fs, "account_host"):
                logger.info(
                    f"AzureBlobFile.connect_client: connecting to host: {self.fs.account_host}"
                )
                self.fs.account_url: str = f"https://{self.fs.account_host}"
            else:
                self.fs.account_url: str = (
                    f"https://{self.fs.account_name}.blob.core.windows.net"
                )
                logger.info(
                    f"AzureBlobFile.connect_client: connecting to account url: {self.fs.account_url}"
                )

            creds = [self.fs.sync_credential, self.fs.account_key, self.fs.credential]
            if any(creds):
                self.container_client = [
                    AIOBlobServiceClient(
                        account_url=self.fs.account_url,
                        credential=cred,
                        _location_mode=self.fs.location_mode,
                    ).get_container_client(self.container_name)
                    for cred in creds
                    if cred is not None
                ][0]
            elif self.fs.connection_string is not None:
                self.container_client = AIOBlobServiceClient.from_connection_string(
                    conn_str=self.fs.connection_string
                ).get_container_client(self.container_name)
            elif self.fs.sas_token is not None:
                self.container_client = AIOBlobServiceClient(
                    account_url=self.fs.account_url + self.fs.sas_token, credential=None
                ).get_container_client(self.container_name)
            else:
                self.container_client = AIOBlobServiceClient(
                    account_url=self.fs.account_url
                ).get_container_client(self.container_name)

        except Exception as e:
            raise ValueError(
                f"Unable to fetch container_client with provided params for {e}!!"
            )

    @staticmethod
    def _get_kwargs_from_urls(path: str) -> {}:
        """Gets storage_options such as account_name from url paths

        Args:
        path: url.

        Returns:
        Dictionary containing the storage_options.
        """
        out = {}
        parsed_path = urlsplit(path)
        if "@" not in parsed_path.netloc:
            return {}
        ops = infer_storage_options(path)
        if ops.get("host", None):
            out["account_name"] = ops["host"].split(".")[0]
            out["account_host"] = ops["host"]
        logger.info(f"_get_kwargs_from_urls: out:{out}")
        return out
