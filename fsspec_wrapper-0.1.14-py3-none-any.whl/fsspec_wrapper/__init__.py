from .core import AzureBlobFileSystem
from .version import VERSION as __version__  # noqa

__all__ = ["AzureBlobFileSystem"]
