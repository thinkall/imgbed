from fsspec.utils import infer_storage_options
from urllib.parse import urlsplit
from .utils import logger as synapseml_pandas_logger
from .utils.common import SynapseCredential
from azure.storage.blob.aio import BlobServiceClient as AIOBlobServiceClient
import adlfs
import time
import re


tokenExpiryCushion = 300  # token expiration delta = 5 mins
token_default_exp = int(9999999999)


class AzureBlobFileSystem(adlfs.AzureBlobFileSystem):

    def __init__(self, *args, **kwargs):
        try:
            synapseml_pandas_logger.info("Fsspec_wrapper call")

            account_host = kwargs["account_host"] if "account_host" in kwargs else None
            kwargs = (
                kwargs["storage_options"] if "storage_options" in kwargs else kwargs
            )
            self.original_kwargs = kwargs.copy()
            self.token_exp = None

            self.account_name, self.credential = self._get_storage_options()
            if self.account_name is not None:
                kwargs["account_name"] = self.account_name
            if self.credential is not None:
                kwargs["credential"] = self.credential

            if not hasattr(self, "account_host") or self.account_host is None:
                self.account_host = account_host

            kwargs["account_host"] = self.account_host
            synapseml_pandas_logger.info("Assigned account_host successfully")
            self._update_token_exp()

            super().__init__(*args, **kwargs)
        except Exception as exception:
            raise Exception(f"Unable to connect to account for {exception}")

    def _get_storage_options(self) -> (str, "SynapseCredential"):
        """
        Get storage_options parameters
        Returns:
        account_name and credentials.
        """
        if "sparkconf" in self.original_kwargs:
            from .utils import rest_service

            client = rest_service.RestServiceClient(
                sparkconf=self.original_kwargs["sparkconf"]
            )
        else:
            from .utils import token_service

            client = token_service.TokenServiceClient()

        account_name = None
        credential = None
        if "connection_string" in self.original_kwargs:
            synapseml_pandas_logger.info("Authentication mode: connection_string")
            pass
        else:
            # if linked_service is provided as storage_options
            if "linked_service" in self.original_kwargs:
                linked_service = self.original_kwargs["linked_service"]
                account_name, credential = (
                    client.get_account_name_and_credential_of_linked_service(
                        linked_service
                    )
                )
            elif "account_name" in self.original_kwargs:
                account_name = self.original_kwargs["account_name"]
                if any(
                    param in self.original_kwargs
                    for param in {"credential", "account_key", "sas_token", "client_id"}
                ):
                    synapseml_pandas_logger.info(
                        "Authentication credentials passed as storage_options."
                    )
                    pass
                else:
                    credential = client.get_aad_credential(audience="storage")
            else:
                synapseml_pandas_logger.info("Accessing default storage.")
                account_name, credential = (
                    client.get_account_name_and_credential_of_linked_service()
                )

        return account_name, credential
    
    def __getattribute__(self, attr):
        orig_attr = super().__getattribute__(attr)
        if callable(orig_attr) and not orig_attr.__name__.startswith("_") and "ls" not in orig_attr.__name__:
            curr_time = int(time.time())
            synapseml_pandas_logger.info("checking token exp")
            if self.token_exp is not None:
                synapseml_pandas_logger.info("refreshing token")
                self.account_name, self.credential = super().__getattribute__("_get_storage_options")()
                if self.credential is not None:
                    super().__dict__["credential"] = self.credential
                    super().__getattribute__("_update_token_exp")()
                    super().do_connect()

            def hooked(*args, **kwargs):
                return orig_attr(*args, **kwargs)

            return hooked
        return orig_attr
        
    def _get_sastoken_exp(self, token: str) -> int:
        """
        Gets expiration of the SAS token.
        Args:
        token: Token.
        Returns:
        expiration time.
        """
        try:
            from calendar import timegm

            attributes = token.split("&")
            endtime_keyword = "se="
            exp_time = None
            for attribute in attributes:
                if attribute.startswith(endtime_keyword):
                    exp_time = attribute[3:]
                    break
            if exp_time is None:
                return int(9999999999)
            exp_time = re.sub("%3A", ":", exp_time)
            utc_time = time.strptime(exp_time, "%Y-%m-%dT%H:%M:%SZ")
            return timegm(utc_time)  # epoch time
        except Exception as exception:
            raise Exception(
                f"Unable to fetch SAS token expiration time because {exception}"
            )

    def _update_token_exp(self):
        """
        Update the token expiration.
        """
        if self.credential is not None:
            if isinstance(self.credential, SynapseCredential):
                self.token_exp = self.credential.token.expires_on
            else:
                self.token_exp = self._get_sastoken_exp(self.credential)
        else:
            if any(
                param in self.original_kwargs for param in {"credential", "sas_token"}
            ):
                # sas token can be passed as credential or sas_token
                if "credential" in self.original_kwargs and self.original_kwargs[
                    "credential"
                ].startswith("?"):
                    self.token_exp = self._get_sastoken_exp(
                        self.original_kwargs["credential"]
                    )
                else:
                    self.token_exp = self._get_sastoken_exp(
                        self.original_kwargs["sas_token"]
                    )

    def walk(self, path, maxdepth=None, **kwargs):
        """
        Overwrite the walk method to invalidate cache.
        """
        kwargs["invalidate_cache"] = True
        return super().walk(path, maxdepth, **kwargs)

    @classmethod
    def _strip_protocol(cls, path: str) -> str:
        """
        fsspec & AzureBlobFileSystem uses this API to get path portion of a URL.

        More info: https://git.io/JGZd1
        Here, we add support for more URL formats:
            abfs://<filesystem>@<account>.dfs.core.windows.net/<path>
            abfs://<filesystem>/<path>
            /<filesystem>/<path>
            /<filesystem>@<account>.dfs.core.windows.net/<path>
            <filesystem>/<path>
            <filesystem>@<account>.dfs.core.windows.net/<path>
            <account>.dfs.core.windows.net/<filesystem>/<path>
        returns: <filesystem>/<path>
        """
        STORE_SUFFIX = ".dfs.core.windows.net"
        if not path.startswith(("abfs://", "az://", "abfss")):
            path = path.lstrip("/")
            path = "abfs://" + path
        ops = infer_storage_options(path)
        if "username" in ops:
            if ops.get("username", None):
                ops["path"] = ops["username"] + ops["path"]
        # we need to make sure that the path retains
        # the format {host}/{path}
        # here host is the container_name
        elif ops.get("host", None):
            if (
                ops["host"].count(STORE_SUFFIX) == 0
            ):  # no store-suffix, so this is container-name
                ops["path"] = ops["host"] + ops["path"]

        return ops["path"]

    @staticmethod
    def _get_kwargs_from_urls(path: str) -> {}:
        """
        Gets storage_options such as account_name from url paths

        Args:
        path: url.

        Returns:
        Dictionary containing the storage_options.
        """
        out = {}
        parsed_path = urlsplit(path)
        if "@" not in parsed_path.netloc:
            return {}
        ops = infer_storage_options(path)
        if ops.get("host", None):
            account_host = ops["host"]
            out["account_name"] = account_host.split(".")[0]
            if "windows" not in account_host.lower():
                synapseml_pandas_logger.info("Received non-public host")
                import re

                account_host = re.sub(r"\.dfs\.", ".blob.", account_host)
                out["account_host"] = account_host
        return out

    def do_connect(self):
        """
        Connect to the BlobServiceClient, using user-specified connection details.
        Tries credentials first, then connection string and finally account key
        Raises
        ------
        ValueError if none of the connection details are available
        """
        try:
            if self.connection_string is not None:
                self.service_client = AIOBlobServiceClient.from_connection_string(
                    conn_str=self.connection_string
                )
            elif self.account_name is not None:
                if hasattr(self, "account_host") and self.account_host is not None:
                    self.account_url: str = f"https://{self.account_host}"
                    synapseml_pandas_logger.info("Using custom/non-public account url")
                else:
                    self.account_url: str = (
                        f"https://{self.account_name}.blob.core.windows.net"
                    )
                    synapseml_pandas_logger.info("Using public blob url")

                creds = [self.credential, self.account_key]
                if any(creds):
                    self.service_client = [
                        AIOBlobServiceClient(
                            account_url=self.account_url,
                            credential=cred,
                            _location_mode=self.location_mode,
                        )
                        for cred in creds
                        if cred is not None
                    ][0]
                elif self.sas_token is not None:
                    if not self.sas_token.startswith("?"):
                        self.sas_token = f"?{self.sas_token}"
                    self.service_client = AIOBlobServiceClient(
                        account_url=self.account_url + self.sas_token,
                        credential=None,
                        _location_mode=self.location_mode,
                    )
                else:
                    # Fall back to anonymous login, and assume public container
                    self.service_client = AIOBlobServiceClient(
                        account_url=self.account_url
                    )
            else:
                raise ValueError(
                    "Must provide either a connection_string or account_name with credentials!!"
                )

        except RuntimeError:
            loop = get_loop()  # noqa: F821
            asyncio.set_event_loop(loop)  # noqa: F821
            self.do_connect()

        except Exception as e:
            raise ValueError(f"unable to connect to account for {e}")

    def connect_client(self):
        """
        Connect to the Asynchronous BlobServiceClient, using user-specified connection details.
        Tries credentials first, then connection string and finally account key
        Raises
        ------
        ValueError if none of the connection details are available
        """
        try:
            if hasattr(self.fs, "account_host") and self.fs.account_host is not None:
                self.fs.account_url: str = f"https://{self.fs.account_host}"
                synapseml_pandas_logger.info("Using custom/non-public account url")
            else:
                self.fs.account_url: str = (
                    f"https://{self.fs.account_name}.blob.core.windows.net"
                )
                synapseml_pandas_logger.info("Using public blob url")

            creds = [self.fs.sync_credential, self.fs.account_key, self.fs.credential]
            if any(creds):
                self.container_client = [
                    AIOBlobServiceClient(
                        account_url=self.fs.account_url,
                        credential=cred,
                        _location_mode=self.fs.location_mode,
                    ).get_container_client(self.container_name)
                    for cred in creds
                    if cred is not None
                ][0]
            elif self.fs.connection_string is not None:
                self.container_client = AIOBlobServiceClient.from_connection_string(
                    conn_str=self.fs.connection_string
                ).get_container_client(self.container_name)
            elif self.fs.sas_token is not None:
                self.container_client = AIOBlobServiceClient(
                    account_url=self.fs.account_url + self.fs.sas_token, credential=None
                ).get_container_client(self.container_name)
            else:
                self.container_client = AIOBlobServiceClient(
                    account_url=self.fs.account_url
                ).get_container_client(self.container_name)

        except Exception as e:
            raise ValueError(
                f"Unable to fetch container_client with provided params for {e}!!"
            )
