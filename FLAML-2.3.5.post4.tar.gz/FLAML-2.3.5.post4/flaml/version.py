__version__ = "2.3.5.post4"
# Anything else must be added after this line in order to support version_match in conda-build.
# conda version doesn't support "-" in version string.
# Universal package versions must be lowercase SemVer 2.0 versions without build metadata.
