NOTICES AND INFORMATION
Do Not Translate or Localize

This software incorporates material from third parties.
Microsoft makes certain open source code available at https://3rdpartysource.microsoft.com,
or you may send a check or money order for US $5.00, including the product name,
the open source component name, platform, and version number, to:

Source Code Compliance Team
Microsoft Corporation
One Microsoft Way
Redmond, WA 98052
USA

Notwithstanding any other terms, you may reverse engineer this software to the extent
required to debug changes to any libraries licensed under the GNU Lesser General Public License.

---------------------------------------------------------

autopage 0.5.1 - Apache-2.0


(c) 2020-2022 by Zane Bitter

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

cliff 4.3.0 - Apache-2.0


copyright 2012- s, Doug Hellmann
Copyright (c) 2017, Red Hat, Inc.
Copyright (c) 2013 Hewlett-Packard Development Company, L.P.

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

databricks-cli 0.17.7 - Apache-2.0


Copyright 2017 Databricks, Inc.
Copyright 2018 Databricks, Inc.
Copyright 2021 Databricks, Inc.
Copyright 2022 Databricks, Inc.

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

docker 6.1.2 - Apache-2.0


copyright d Docker Inc
Copyright 2016 Docker, Inc.

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

importlib-metadata 6.6.0 - Apache-2.0



Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

importlib-resources 5.12.0 - Apache-2.0



Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

mlflow 2.3.2 - Apache-2.0


(c) Ga (c)
(c) La (c)
(c) Mapbox
Xa aa (c) Ya
(c) Kyle Simpson
(c) Sindre Sorhus
copyright Koen Bok
(c) 2012 IEM Nexrad
(c) Dustin Diaz 2015
Copyright (c) TanStack
(c) 2010-2011 CloudMade
(c) 2014 Julian Shapiro
(c) 2007 Steven Levithan
(c) 2019 Denis Pushkarev
Copyright Dave Gandy 2016
(c) available from the ASN
Copyright 2015, Yahoo Inc.
Copyright Gaetan Renaudeau
Copyright 2015, Yahoo! Inc.
Copyright 2018 Mike Bostock
Copyright 2019 Mike Bostock
Copyright 2020 Mike Bostock
(c) 2007-2009 Steven Levithan
Copyright (c) 2015 Jed Watson
Copyright (c) 2018 Jed Watson
(c) 2014 The jQuery Foundation
(c) http://osm.org/copyright'>
Copyright (c) 2011 Google Inc.
Copyright (c) 2014, Yahoo! Inc.
Copyright 2018 Databricks, Inc.
(c) 2010-2022 Vladimir Agafonkin
Copyright (c) Remix Software Inc.
Copyright 2012 Mozilla Foundation
Copyright 2012-2021, Plotly, Inc.
Copyright 2014 Mozilla Foundation
Copyright 2014 Opera Software ASA
Copyright 2015 Mozilla Foundation
Copyright 2016 Mozilla Foundation
Copyright 2017 Mozilla Foundation
Copyright 2018 Mozilla Foundation
copyright (c) 2019 Denis Pushkarev
copyright (c) 2020 Denis Pushkarev
Array compacting. Copyright Lo-Dash
Copyright (c) Microsoft Corporation
Copyright 2013-2015, Facebook, Inc.
Copyright 1996-2003 Glyph & Cog, LLC
Copyright 2015-present, Alipay, Inc.
Copyright (c) 2011-2019, Gregor Aisch
Copyright (c) 2012-2014 Roman Shtylman
Copyright (c) 2012-2014 TJ Holowaychuk
Copyright (c) 2014-2015, Facebook, Inc.
Copyright (c) 2014-2015, Jon Schlinkert
Copyright (c) 2013-present, Facebook, Inc.
Copyright (c) 2014-present, Facebook, Inc.
Copyright 2014-2017 by Christopher Crouzet
Copyright 2011 The Closure Compiler Authors
(c) https://www.openstreetmap.org/copyright'>
Copyright (c) 2015 Douglas Christopher Wilson
Copyright (c) Facebook, Inc. and its affiliates
Copyright (c) 2009 Thomas Robinson <280north.com>
Copyright 2011 Mozilla Foundation and contributors
Copyright 2014 Mozilla Foundation and contributors
Copyright Joyent, Inc. and other Node contributors
Copyright (c) 2015 Twitter, Inc. and other contributors
Copyright 2009-2011 Mozilla Foundation and contributors
Copyright (c) 2017 Michael Mclaughlin <M8ch88l@gmail.com>
copyright 2016 Sean Connelly (@voidqk), http://syntheti.cc
(c) Copyright 2016, Sean Connelly (@voidqk), http://syntheti.cc
(c) Copyright 2017, Sean Connelly (@voidqk), http://syntheti.cc
Copyright (c) 2011-2012, Cyril Agosta ( cyril.agosta.dev@gmail.com)
Copyright 2012-2015 The Dojo Foundation <http://dojofoundation.org/>
Copyright JS Foundation and other contributors, https://js.foundation
Copyright jQuery Foundation and other contributors <https://jquery.org/>
Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
Copyright (c) 2002 Cynthia Brewer, Mark Harrower, and The Pennsylvania State University
Copyright Tim Down http://stackoverflow.com/questions/5623838/rgb-to-hex-and-hex-to-rgb
Copyright 2009-2015 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
Copyright (c) 2018 Dmitriy Kubyshkin Copied from https://github.com/grassator/insert-text-at-cursor

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

pbr 5.11.1 - Apache-2.0


Copyright 2021 Monty Taylor
Copyright 2012 Red Hat, Inc.
Copyright 2018 Red Hat, Inc.
Copyright (c) 2020 Red Hat, Inc.
Copyright (c) 2013 Testrepository
Copyright 2011 OpenStack Foundation
Copyright 2012 OpenStack Foundation
copyright 2013, OpenStack Foundation
copyright u'2013, OpenStack Foundation
Copyright (c) 2011 OpenStack Foundation
Copyright 2010-2011 OpenStack Foundation
Copyright (c) 2013 New Dream Network, LLC
Copyright 2013 Hewlett-Packard Development Company, L.P.
Copyright 2014 Hewlett-Packard Development Company, L.P.
Copyright (c) 2013 Hewlett-Packard Development Company, L.P.
Copyright (c) 2015 Hewlett-Packard Development Company, L.P.
Copyright 2012-2013 Hewlett-Packard Development Company, L.P.
Copyright (c) 2005 Association of Universities for Research in Astronomy (AURA)
Copyright (c) 2013 Association of Universities for Research in Astronomy (AURA)

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

pyarrow 11.0.0 - Apache-2.0


Copyright 2011 Kitware, Inc.
Copyright 2012 Cloudera Inc.
Copyright 2001-2009 Kitware, Inc.
Copyright 2012 Continuum Analytics, Inc.
Copyright 2012-2014 Continuum Analytics, Inc.

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

pyspark 3.2.3 - Apache-2.0


Copyright 2014 Mohsen Azimi
Copyright (c) 2012 Scott Jehl
Copyright (c) 2013 Chris Pettitt
Copyright (c) 2011, Paul Phillips
Copyright (c) 2009 Chris Wanstrath
Copyright (c) 2010-2014 Jan Lehnardt
Copyright (c) 2011-2019 Twitter, Inc.
Copyright (c) 2008-2020, SpryMedia Ltd.
Copyright (c) 1997-2007 Stuart Langridge
Copyright (c) 2010-2015, Michael Bostock
Copyright (c) 2009-2011, Barthelemy Dagenais
Copyright (c) 2011-2019 The Bootstrap Authors
Copyright (c) 2010-2015 The mustache.js community
Copyright (c) 2011-2017 Almende B.V, http://almende.com
Copyright (c) 2011, Douban Inc. <http://www.douban.com/>
Copyright (c) 2009 PiCloud, Inc. <http://www.picloud.com>
copyright (c) 2012 Scott Jehl, Paul Irish, Nicholas Zakas
Copyright (c) 2012, Regents of the University of California
Copyright JS Foundation and other contributors, https://js.foundation
Copyright (c) 2009 PiCloud, Inc. <https://web.archive.org/web/20140626004012/http://www.picloud.com/>
Copyright (c) 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019 Python Software Foundation

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

python-dateutil 2.8.2 - Apache-2.0


copyright 2019, dateutil
Copyright 2017- dateutil contributors
Copyright (c) 2015- - dateutil contributors
Copyright 2017- Paul Ganssle <paul@ganssle.io>
Copyright (c) 2015- - Paul Ganssle <paul@ganssle.io>
Copyright (c) 2014-2016 - Yaron de Leeuw <me@jarondl.net>
Copyright (c) 2003-2011 - Gustavo Niemeyer <gustavo@niemeyer.net>
Copyright (c) 2012-2014 - Tomi Pievilainen <tomi.pievilainen@iki.fi>

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

requests 2.31.0 - Apache-2.0


Copyright Kenneth Reitz
Copyright 2019 Kenneth Reitz
copyright (c) 2012 by Kenneth Reitz
copyright (c) 2017 by Kenneth Reitz

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

tzdata 2023.3 - Apache-2.0


Copyright (c) 2020, Paul Ganssle
copyright 2020, Python Software Foundation

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

xgboost 1.7.5 - Apache-2.0


Copyright 2014
Copyright 2015
Copyright 2017
Copyright 2018
Copyright 2019
Copyright 2020
Copyright 2021
Copyright (c) 2014
Copyright (c) 2015
Copyright (c) 2016
Copyright (c) 2017
Copyright (c) 2018
Copyright (c) 2019
Copyright (c) 2020
Copyright (c) 2021
Copyright 2014-2019
Copyright 2014-2020
Copyright 2014-2021
Copyright 2014-2022
Copyright 2015-2018
Copyright 2015-2019
Copyright 2015-2020
Copyright 2015-2021
Copyright 2015-2022
Copyright 2017-2020
Copyright 2017-2021
Copyright 2017-2022
Copyright 2018-2019
Copyright 2018-2020
Copyright 2018-2022
Copyright 2019-2020
Copyright 2019-2022
Copyright 2020-2022
Copyright 2021-2022
Copyright 2017 XGBoost
Copyright 2018 XGBoost
Copyright 2019 XGBoost
Copyright 2020 XGBoost
Copyright 2021 XGBoost
Copyright 2022 XGBoost
Copyright (c) 2014-2019
Copyright (c) 2014-2022
Copyright (c) 2015-2018
Copyright (c) 2015-2019
Copyright (c) 2015-2021
Copyright (c) 2015-2022
Copyright (c) 2019-2022
Copyright (c) 2019~2021
Copyright 2022, XGBoost
(c) by Contributors 2020
Copyright 2018 Ulf Adams
Copyright 2015-2022 XGBoost
Copyright 2017-2019 XGBoost
Copyright 2017-2020 XGBoost
Copyright 2017-2022 XGBoost
Copyright 2018-2022 XGBoost
Copyright 2018~2020 XGBoost
Copyright 2019-2020 XGBoost
Copyright 2019-2021 XGBoost
Copyright 2019-2022 XGBoost
Copyright 2020-2022 XGBoost
Copyright 2021-2022 XGBoost
Copyright 2020-2022, XGBoost
(c) by Contributors 2019-2022
Copyright by Contributors 2019
(c) 2015-2016 Cameron Desrochers
Copyright (c) 2015 Jeff Preshing
Copyright (c) 2016 Domagoj Saric
Copyright by Contributors 2017-2019
Copyright by Contributors 2017-2020
Copyright by Contributors 2017-2021
Copyright 2015 The TensorFlow Authors
Copyright 2019 by XGBoost Contributors
Copyright 2020 by XGBoost Contributors
Copyright 2021 by XGBoost Contributors
Copyright 2022 by XGBoost Contributors
Copyright (c) 2022, NVIDIA CORPORATION.
Copyright 2022, by XGBoost Contributors
Copyright (c) 2015 Microsoft Corporation
Copyright (c) 2022 by XGBoost Contributors
Copyright (c) 2013-2016, Cameron Desrochers
Copyright 2014-2022 by XGBoost Contributors
Copyright 2014~2022 by XGBoost Contributors
Copyright 2015-2022 by XGBoost Contributors
Copyright 2017-2022 by XGBoost Contributors
Copyright 2018-2022 by XGBoost Contributors
Copyright 2019-2021 by XGBoost Contributors
Copyright 2019-2022 by XGBoost Contributors
Copyright 2019-2023 by XGBoost Contributors
Copyright 2020-2021 by XGBoost Contributors
Copyright 2020-2022 by XGBoost Contributors
Copyright 2021-2022 by XGBoost Contributors
Copyright by XGBoost Contributors 2014-2022
Copyright (c) 2014-2022 by XGBoost Contributors
Copyright (c) 2015-2022 by XGBoost Contributors
Copyright (c) 2015~2022 by XGBoost Contributors
Copyright (c) 2021-2022 by XGBoost Contributors
Copyright (c) by XGBoost Contributors 2019-2022

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/ TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.



      "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.



      "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.



      "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.



      "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.



      "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.



      "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.



      "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).



      "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.



      "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."



      "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

      (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

      You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability. END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.

Copyright [yyyy] [name of copyright owner]

Licensed under the Apache License, Version 2.0 (the "License");

you may not use this file except in compliance with the License.

You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software

distributed under the License is distributed on an "AS IS" BASIS,

WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the License for the specific language governing permissions and

limitations under the License.

---------------------------------------------------------

---------------------------------------------------------

fonttools 4.39.4 - Apache-2.0 AND BSD-3-Clause AND MIT AND OFL-1.1


Copyright 2017
Copyright 2018
Copyright c 2015
COPYRIGHT STRING.
(c) 2022 Unicode(r), Inc.
Copyright 2011 Google Inc.
Copyright 2013 Google Inc.
Copyright 2015 Google Inc.
Copyright 2016 Google Inc.
Copyright 2019 Google Inc.
Copyright 2023 Google Inc.
(c) 2010 by Pablo Impallari
Copyright 2013 Google, Inc.
Copyright (c) 2000 BeOpen.com
Copyright 2017 by Jens Kutilek
Copyright 2021 Behdad Esfahbod
Copyright 2023 Behdad Esfahbod
Copyright (c) 2015 by FontTools
Copyright 2015-2021 Google LLC.
Copyright (c ) 2015 by FontTools
Copyright 2008 The Bungee Project
Copyright 2021 The Qahiri Project
Copyright (c) 2009 Type Supply LLC
Copyright (c) 2017 Just van Rossum
(c) 2002 Adobe Systems Incorporated
Copyright (c) 2010 by Pablo Impallari
Copyright (c) 2015-2019 Belleve Invis
Copyright 2010-2020 The Amiri Project
Copyright 2017 The Roboto Flex Project
Copyright (c) 2013-2014 Lennart Regebro
Copyright 2015 Adobe System Incorporated
Copyright 2014 Adobe Systems Incorporated
Copyright (c) 2018 Adobe systems Co., Ltd.
Copyright 2015-2021 The Aref Ruqaa Project
Copyright (c) 2002 Adobe Systems Incorporated
Portions copyright (c) 1990 by Elsevier, Inc.
(c) 2010 by Pablo Impallari. www.impallari.com
Copyright (c) 2012-2019 The Libertinus Project
copyright (c) 2005-2016, The RoboFab Developers
Copyright (c) 2001-2010 by the STI Pub Companies
Copyright (c) 2001-2011 by the STI Pub Companies
Copyright (c) 2015-2019 The Mada Project Authors
Copyright 2010 - 2012 Adobe Systems Incorporated
Portions copyright (c) 2009-2012 by Khaled Hosny
copyright 2020, Just van Rossum, Behdad Esfahbod
Copyright 2002-2019 Adobe (http://www.adobe.com/)
Copyright 1998, Just van Rossum <just@letterror.com>
Portions copyright (c) 1998-2003 by MicroPress, Inc.
(c) Copyright 1994-1997 Summer Institute of Linguistics
Copyright (c) 2010 by Pablo Impallari. www.impallari.com
Copyright (c) 2015-2020 Belleve Invis (belleve@typeof.net)
Copyright c 1997, 2009, 2011 American Mathematical Society
(c) 2010, Pablo Impallari (www.impallari.com impallari@gmail.com)
Copyright (c) 1991-1995 Stichting Mathematisch Centrum, Amsterdam
(c) 2010 - 2012 Adobe Systems Incorporated (http://www.adobe.com/)
Copyright (c) 1995-2001 Corporation for National Research Initiatives
Copyright (c) 1999-2004 Just van Rossum, LettError (just@letterror.com)
Copyright 2014, 2015 Adobe Systems Incorporated (http://www.adobe.com/)
Copyright (c) 2010, Pablo Impallari (www.impallari.com impallari@gmail.com)
Copyright (c) 2014, 2015 Adobe Systems Incorporated (http://www.adobe.com/)
Copyright 2014, 2015, 2016 Adobe Systems Incorporated (http://www.adobe.com/)
Copyright (c) 1997, 2009, 2011 American Mathematical Society http://www.ams.org

Apache-2.0 AND BSD-3-Clause AND MIT AND OFL-1.1

---------------------------------------------------------

---------------------------------------------------------

packaging 23.1 - Apache-2.0 OR (Apache-2.0 AND BSD-2-Clause AND BSD-3-Clause)


copyright 2014-2019 s
Copyright (c) Donald Stufft and individual contributors

Apache-2.0 OR (Apache-2.0 AND BSD-2-Clause AND BSD-3-Clause)

---------------------------------------------------------

---------------------------------------------------------

cloudpickle 2.2.1 - BSD-2-Clause


Copyright (c) 2015, Cloudpickle
Copyright (c) 2009 PiCloud, Inc. http://www.picloud.com
Copyright (c) 2012, Regents of the University of California
Copyright (c) 2009 PiCloud, Inc. <https://web.archive.org/web/20140626004012/http://www.picloud.com/>

Copyright (c) <year> <owner> . All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------

---------------------------------------------------------

jinja2 3.1.2 - BSD-2-Clause


Copyright 2007 Pallets
copyright 2007 Pallets
(c) Copyright 2008 by http://domain.invalid/'>

Copyright (c) <year> <owner> . All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------

---------------------------------------------------------

kiwisolver 1.4.4 - BSD-2-Clause


copyright 2018-2021, Nucleic team
Copyright (c) 2001. Addison-Wesley
Copyright (c) 2019-2021 Martin Ankerl
Copyright (c) 2001 by Andrei Alexandrescu
Copyright (c) 2013, Nucleic Development Team
Copyright (c) 2019, Nucleic Development Team
Copyright (c) 2020, Nucleic Development Team
Copyright (c) 2021, Nucleic Development Team
Copyright (c) 2013-2017, Nucleic Development Team
Copyright (c) 2013-2019, Nucleic Development Team
Copyright (c) 2013-2021, Nucleic Development Team
Copyright (c) 2013-2022, Nucleic Development Team
Copyright (c) 2014-2021, Nucleic Development Team
Copyright (c) 2014-2022, Nucleic Development Team
Copyright 2000, 2004, 2005Adobe Systems Incorporated
Copyright (c) 2019-2021 Martin Ankerl <martin.ankerl@gmail.com>

Copyright (c) <year> <owner> . All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------

---------------------------------------------------------

markdown 3.4.3 - BSD-2-Clause


(c) 2004 Foo Corporation
Copyright 2004 Manfred Stienstra
Copyright The Python Markdown Project
Copyright (c) 1999-2007 by Fredrik Lundh
Copyright 2004, 2005, 2006 Yuri Takhteyev
Copyright 2007-2018 The Python Markdown Project
Copyright 2007-2019 The Python Markdown Project
Copyright 2007-2020 The Python Markdown Project
Copyright 2007-2021 The Python Markdown Project
Copyright 2007-2022 The Python Markdown Project
Copyright 2008-2014 The Python Markdown Project
Copyright 2011-2014 The Python Markdown Project
Copyright 2013-2014 The Python Markdown Project
Copyright 2015-2018 The Python Markdown Project
Copyright 2007, 2008 The Python Markdown Project
Copyright 2008 Jack Miller (https://codezen.org/)
Copyright Waylan Limberg (http://achinghead.com/)
The Python-Markdown Project Copyright (c) 2010-2023
Copyright 2008 Waylan Limberg (http://achinghead.com)
Copyright 2009 Waylan Limberg (http://achinghead.com)
Copyright 2011 Waylan Limberg (http://achinghead.com)
Copyright 2011 Waylan Limberg (http://achinghead.com/)
Copyright Tiago Serafim (https://www.tiagoserafim.com/)
Copyright 2011 Brian Neal (https://deathofagremmie.com/)
Copyright 2007-2008 Waylan Limberg (http://achinghead.com)
Copyright (c) 2004, 2007 Chad Miller <http://web.chad.org/>
Copyright 2006-2008 Waylan Limberg (http://achinghead.com/)
Copyright 2007-2008 Waylan Limberg (http://achinghead.com/)
Copyright (c) 2003 John Gruber <https://daringfireball.net/>
Copyright 2007-2008 Waylan Limberg (http://achinghead.com/) and Seemant Kulleen (http://www.kulleen.org/)

Copyright (c) <year> <owner> . All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------

---------------------------------------------------------

markupsafe 2.1.2 - BSD-2-Clause


Copyright 2010 Pallets
copyright 2010 Pallets

Copyright (c) <year> <owner> . All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------

---------------------------------------------------------

numpy 1.23.5 - BSD-2-Clause


Copyright (c) 2017
(c) Convert Chebyshev
(c) Multiply a Hermite
(c) Multiply a Laguerre
(c) Multiply a Legendre
(c) Multiply a Chebyshev
Copyright (c) 2010 - 2019
Copyright Absoft Corporation
(c), True, True, False, False
Copyright 2000 Pearu Peterson
Copyright 2002 Pearu Peterson
(c), False, False, False, True
(c), False, False, True, False
Copyright (c) 2012 Google Inc.
Copyright (c) 2014 Ryan Juckett
Copyright 2011 by Enthought, Inc
Copyright (c) 2011 Enthought, Inc
Copyright (c) 2015 Pauli Virtanen
Copyright (c) 2019 Kevin Sheppard
Copyright 1999 2011 Pearu Peterson
Copyright 1999,2000 Pearu Peterson
Copyright 1999-2004 Pearu Peterson
Copyright 2001-2005 Pearu Peterson
Copyright (c) 2019 NumPy Developers
Copyright (c) 2007 Cybozu Labs, Inc.
Copyright (c) 2021 Intel Corporation
Copyright 1999 - 2011 Pearu Peterson
Copyright (c) 2011 by Enthought, Inc.
Copyright (c) 2014 Mathjax Consortium
Copyright (c) 2015 Melissa E. O'Neill
Copyright (c) 2015-2017 Martin Hensel
Copyright (c) 2018 Melissa E. O'Neill
copyright 2008-2022, NumPy Developers
Copyright 2007-2018 by the Sphinx team
copyright u'2017-2018, NumPy Developers
Copyright (c) 2021 Microsoft Corporation
Copyright 2010-2012, D. E. Shaw Research
Copyright (c) 2005-2015, NumPy Developers
Copyright (c) 2005-2017, NumPy Developers
Copyright (c) 2005-2021, NumPy Developers
Copyright (c) 2005-2022, NumPy Developers
Copyright (c) 1993 by Sun Microsystems, Inc.
Copyright (c) 2011-2014, The OpenBLAS Project
Copyright (c) 2009-2017 The MathJax Consortium
Copyright (c) 2010-2017 The MathJax Consortium
Copyright (c) 2011-2015 The MathJax Consortium
Copyright (c) 2011-2017 The MathJax Consortium
Copyright (c) 2013-2017 The MathJax Consortium
Copyright (c) 2014-2017 The MathJax Consortium
Copyright (c) 2015-2017 The MathJax Consortium
Copyright (c) 2016-2017 The MathJax Consortium
Copyright (c) 2008 Ian Bicking and Contributors
copyright 2010 David Wolever <david@wolever.net>
Copyright (c) 2010 The Android Open Source Project
Copyright 2015 Robert Kern <robert.kern@gmail.com>
Copyright (c) 2002-2017 Free Software Foundation, Inc.
Copyright 2014 Melissa O'Neill <oneill@pcg-random.org>
Copyright (c) Donald Stufft and individual contributors
Copyright (c) 2007, 2011 David Schultz <das@FreeBSD.ORG>
Copyright (c) 2006-2013 The University of Colorado Denver
Copyright Absoft Corporation 1994-2002 Absoft Pro FORTRAN
Copyright (c) 1995, 1996, 1997 Jim Hugunin, hugunin@mit.edu
Copyright (c) 2003-2005, Jean-Sebastien Roy (js@jeannot.org)
Copyright (c) 2000-2013 The University of California Berkeley
Copyright (c) 2016 - 2019 Kim Walisch, <kim.walisch@gmail.com>
Copyright 2016-2021 Matthew Brett, Isuru Fernando, Matti Picus
Copyright (c) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura
Copyright (c) 2004-2018 Max-Planck-Society author Martin Reinecke
Copyright (c) 2012 Stephen Montgomery-Smith <stephen@FreeBSD.ORG>
Copyright 1999, 2000, 2001 Regents of the University of California
Copyright (c) 2007 Free Software Foundation, Inc. <http://fsf.org/>
Copyright (c) 2009 Free Software Foundation, Inc. <http://fsf.org/>
Copyright (c) 2006, University of Georgia and Pierre G.F. Gerard-Marchant
Copyright Absoft Corporation 1994-1998 mV2 Cray Research, Inc. 1994-1996 CF90
Copyright (c) 2010 by Mark Wiebe (mwwiebe@gmail.com) The University of British Columbia
Copyright (c) 2011 by Mark Wiebe (mwwiebe@gmail.com) The University of British Columbia
Copyright (c) 2010-2011 by Mark Wiebe (mwwiebe@gmail.com) The University of British Columbia
Copyright (c) 2009-2019 Jeff Bezanson, Stefan Karpinski, Viral B. Shah, and other contributors
Copyright (c) 1992-2013 The University of Tennessee and The University of Tennessee Research Foundation

Copyright (c) <year> <owner> . All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------

---------------------------------------------------------

numpy 1.24.3 - BSD-2-Clause


Copyright (c) 2017
(c) Convert Chebyshev
(c) Multiply a Hermite
(c) Multiply a Laguerre
(c) Multiply a Legendre
(c) Multiply a Chebyshev
Copyright (c) 2010 - 2019
Copyright Absoft Corporation
(c), True, True, False, False
Copyright 2000 Pearu Peterson
Copyright 2002 Pearu Peterson
(c), False, False, False, True
(c), False, False, True, False
Copyright (c) 2012 Google Inc.
Copyright (c) 2014 Ryan Juckett
Copyright 2011 by Enthought, Inc
Copyright (c) 2011 Enthought, Inc
Copyright (c) 2015 Pauli Virtanen
Copyright (c) 2019 Kevin Sheppard
Copyright 1999 2011 Pearu Peterson
Copyright 1999,2000 Pearu Peterson
Copyright 1999-2004 Pearu Peterson
Copyright 2001-2005 Pearu Peterson
Copyright (c) 2019 NumPy Developers
Copyright (c) 2007 Cybozu Labs, Inc.
Copyright (c) 2021 Intel Corporation
Copyright 1999 - 2011 Pearu Peterson
Copyright (c) 2011 by Enthought, Inc.
Copyright (c) 2014 Mathjax Consortium
Copyright (c) 2015 Melissa E. O'Neill
Copyright (c) 2015-2017 Martin Hensel
Copyright (c) 2018 Melissa E. O'Neill
copyright 2008-2022, NumPy Developers
copyright 2017-2018, NumPy Developers
Copyright 2007-2018 by the Sphinx team
Copyright (c) 2021 Microsoft Corporation
Copyright 2010-2012, D. E. Shaw Research
Copyright (c) 2005-2015, NumPy Developers
Copyright (c) 2005-2017, NumPy Developers
Copyright (c) 2005-2021, NumPy Developers
Copyright (c) 2005-2022, NumPy Developers
Copyright (c) 1993 by Sun Microsystems, Inc.
Copyright (c) 2011-2014, The OpenBLAS Project
Copyright (c) 2009-2017 The MathJax Consortium
Copyright (c) 2010-2017 The MathJax Consortium
Copyright (c) 2011-2015 The MathJax Consortium
Copyright (c) 2011-2017 The MathJax Consortium
Copyright (c) 2013-2017 The MathJax Consortium
Copyright (c) 2014-2017 The MathJax Consortium
Copyright (c) 2015-2017 The MathJax Consortium
Copyright (c) 2016-2017 The MathJax Consortium
Copyright (c) 2008 Ian Bicking and Contributors
copyright 2010 David Wolever <david@wolever.net>
Copyright (c) 2010 The Android Open Source Project
Copyright 2015 Robert Kern <robert.kern@gmail.com>
Copyright (c) 2002-2017 Free Software Foundation, Inc.
Copyright 2014 Melissa O'Neill <oneill@pcg-random.org>
Copyright (c) Donald Stufft and individual contributors
Copyright (c) 2007, 2011 David Schultz <das@FreeBSD.ORG>
Copyright (c) 2006-2013 The University of Colorado Denver
Copyright Absoft Corporation 1994-2002 Absoft Pro FORTRAN
Copyright (c) 1995, 1996, 1997 Jim Hugunin, hugunin@mit.edu
Copyright (c) 2003-2005, Jean-Sebastien Roy (js@jeannot.org)
Copyright (c) 2000-2013 The University of California Berkeley
Copyright (c) 2016 - 2019 Kim Walisch, <kim.walisch@gmail.com>
Copyright 2016-2021 Matthew Brett, Isuru Fernando, Matti Picus
Copyright (c) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura
Copyright (c) 2004-2018 Max-Planck-Society author Martin Reinecke
Copyright (c) 2012 Stephen Montgomery-Smith <stephen@FreeBSD.ORG>
Copyright 1999, 2000, 2001 Regents of the University of California
Copyright (c) 2007 Free Software Foundation, Inc. <http://fsf.org/>
Copyright (c) 2009 Free Software Foundation, Inc. <http://fsf.org/>
Copyright (c) 2006, University of Georgia and Pierre G.F. Gerard-Marchant
Copyright Absoft Corporation 1994-1998 mV2 Cray Research, Inc. 1994-1996 CF90
Copyright (c) 2010 by Mark Wiebe (mwwiebe@gmail.com) The University of British Columbia
Copyright (c) 2011 by Mark Wiebe (mwwiebe@gmail.com) The University of British Columbia
Copyright (c) 2010-2011 by Mark Wiebe (mwwiebe@gmail.com) The University of British Columbia
Copyright (c) 2009-2019 Jeff Bezanson, Stefan Karpinski, Viral B. Shah, and other contributors
Copyright (c) 1992-2013 The University of Tennessee and The University of Tennessee Research Foundation

Copyright (c) <year> <owner> . All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------

---------------------------------------------------------

prettytable 3.7.0 - BSD-2-Clause


Copyright (c) 2009-2014 Luke Maurits <luke@maurits.id.au>
Copyright (c) 2009-2014, Luke Maurits <luke@maurits.id.au>

Copyright (c) <year> <owner> . All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------

---------------------------------------------------------

colorama 0.4.6 - BSD-2-Clause AND BSD-3-Clause


Copyright Jonathan Hartley 2013
Copyright (c) 2010 Jonathan Hartley
Copyright Jonathan Hartley & Arnon Yaari, 2013-2020

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

contourpy 1.0.7 - BSD-2-Clause AND BSD-3-Clause


copyright 2021-2023, ContourPy
Copyright (c) 2021-2023, ContourPy Developers

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

cycler 0.11.0 - BSD-2-Clause AND BSD-3-Clause


copyright 2015, Matplotlib Developers
Copyright (c) 2015, matplotlib project

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

flask 2.3.2 - BSD-2-Clause AND BSD-3-Clause


Copyright 2010 Pallets
copyright 2010 Pallets
Copyright (c) 2015 CERN.
(c) Copyright 2010 by http://domain.invalid/'>

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

itsdangerous 2.1.2 - BSD-2-Clause AND BSD-3-Clause


Copyright 2011 Pallets
copyright 2011 Pallets

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

joblib 1.2.0 - BSD-2-Clause AND BSD-3-Clause


Copyright 2009 Brian Quinlan
Copyright 2017, Thomas Moreau
Copyright 2010, Gael Varoquaux
Copyright 2012, Olivier Grisel
Copyright (c) 2008 Gael Varoquaux
Copyright (c) 2009 Gael Varoquaux
Copyright (c) 2010 Gael Varoquaux
Copyright (c) 2008-2021, The joblib
Copyright (c) 2010-2011 Gael Varoquaux
copyright 2008-2021, Joblib developers
Copyright (c) 2012, Regents of the University of California
Copyright 2010, Gael Varoquaux 2001-2004, Fernando Perez 2001 Nathaniel Gray
Copyright (c) 2009 PiCloud, Inc. <https://web.archive.org/web/20140626004012/http://www.picloud.com/>

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

oauthlib 3.2.2 - BSD-2-Clause AND BSD-3-Clause


(c) Access Token
(c) Redirection URI
Copyright (c) 2019 The OAuthlib Community
copyright (c) 2019 by The OAuthlib Community

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

pandas 1.5.3 - BSD-2-Clause AND BSD-3-Clause


Copyright (c) 2009', join
Copyright 2014-2019, xarray
Copyright (c) 2012 Google Inc.
Copyright (c) 2015 Jared Hobbs
Copyright (c) 1994 David Burren
Copyright (c) 2011 Szabolcs Nagy
Copyright (c) 2011 Valentin Ochs
Copyright (c) 2017 Anthony Sottile
Copyright (c) 2005-2014 Rich Felker
Copyright (c) 2010, Albert Sweigart
Copyright (c) 2002 Michael Ringgaard
Copyright (c) 2003-2011 David Schultz
Copyright (c) 2008 Stephen L. Moshier
Copyright (c) 2011 by Enthought, Inc.
Copyright 2017- dateutil contributors
Copyright (c) 2003-2009 Bruce D. Evans
Copyright (c) 2001-2008 Ville Laurikari
Copyright (c) 2003-2009 Steven G. Kargl
Copyright (c) 1993,2004 Sun Microsystems
Copyright (c) 2001, 2002 Enthought, Inc.
Copyright (c) 2003-2012 SciPy Developers
Copyright (c) 2012, Lambda Foundry, Inc.
Copyright (c) 1994 Sun Microsystems, Inc.
Copyright (c) 2005-2011, NumPy Developers
Copyright (c) 2017 - dateutil contributors
Copyright (c) 2015- - dateutil contributors
Copyright (c) 2016, PyData Development Team
Copyright (c) 2020, PyData Development Team
Copyright 2017- Paul Ganssle <paul@ganssle.io>
Copyright (c) 2011-2022, Open source contributors
Copyright (c) 2008 The Android Open Source Project
Copyright (c) 2015- - Paul Ganssle <paul@ganssle.io>
Copyright (c) 2010-2012 Archipel Asset Management AB.
Copyright (c) 2007 Nick Galbreath nickg at modp dot com
Copyright (c) Donald Stufft and individual contributors
Copyright (c) 2014-2016 - Yaron de Leeuw <me@jarondl.net>
Copyright (c) 2019 Hadley Wickham RStudio and Evan Miller
Copyright (c) 2008- Attractive Chaos <attractor@live.co.uk>
Copyright (c) 2003-2011 - Gustavo Niemeyer <gustavo@niemeyer.net>
Copyright (c) 1988-1993 The Regents of the University of California
Copyright (c) 2011-2013, ESN Social Software AB and Jonas Tarnstrom
Copyright (c) 2012-2014 - Tomi Pievilainen <tomi.pievilainen@iki.fi>
Copyright (c) 1995-2001 Corporation for National Research Initiatives
Copyright (c) 2008, 2009, 2011 by Attractive Chaos <attractor@live.co.uk>
Copyright (c) 1991 - 1995, Stichting Mathematisch Centrum Amsterdam, The Netherlands
Copyright (c) 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010 Python Software Foundation
Copyright (c) 2008-2011, AQR Capital Management, LLC, Lambda Foundry, Inc. and PyData Development Team

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

pyperclip 1.8.2 - BSD-2-Clause AND BSD-3-Clause


copyright 2014, Al Sweigart
Copyright (c) 2014, Al Sweigart

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

scikit-learn 1.2.2 - BSD-2-Clause AND BSD-3-Clause


(c) 2014
(c) INRIA
(c) INRIA 2010
(c) INRIA 2011
(c) INRIA 2014
Copyright INRIA
(c) 2011 import warnings
Copyright (c) 2011, 2012
Copyright (c) 2018, pandas
Copyright 2014 Steven Loria
Copyright 2011-2019 Twitter, Inc.
(c) INRIA, University of Amsterdam
Copyright 2015 Jon Lund Steffensen
Copyright (c) 2003-2016 Paul T. McGuire
Copyright (c) 2007-2022 The scikit-learn
Copyright 2011-2019 The Bootstrap Authors
Copyright (c) 2011 Renato de Pontes Pereira
(c) OpenJS Foundation and other contributors
Copyright (c) 2007-2014 The LIBLINEAR Project
copyrights by Aric Hagberg <hagberg@lanl.gov>
Copyright (c) 2004-2017 Holger Krekel and others
copyright f'2007 - datetime.now .year, scikit-learn
Copyright (c) Donald Stufft and individual contributors
Copyright (c) 2000-2009 Chih-Chung Chang and Chih-Jen Lin
Copyright (c) 2011 Olivier Grisel <olivier.grisel@ensta.org>
Copyright (c) 2011 David Warde-Farley <wardefar at iro dot umontreal dot ca>
Copyright 2011-2019 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
Copyright (c) 2007-2009 Cournapeau David <cournape@gmail.com> 2010 Fabian Pedregosa <fabian.pedregosa@inria.fr>
Copyright (c) 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018 Python Software Foundation
Copyright (c) 2007 David Cournapeau <cournape@gmail.com> 2010 Fabian Pedregosa <fabian.pedregosa@inria.fr> 2010 Olivier Grisel <olivier.grisel@ensta.org>

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

scipy 1.10.1 - BSD-2-Clause AND BSD-3-Clause


(c), (c)
(c) . B' Both
(c) B Whether
Copyright 2001
Copyright 2003
Copyright 2008
(c) 2003, C. Bond
(c) Case 2 Caller
(c) Copyright John
Copyright 2014 LRI
Copyright 2015 LRI
(c) Date July, 1988
Copyright 2018 Nico
Gamma (c) Gamma (c)
(c) Compute Hessian H
Copyright 2014 LASMEA
Copyright Jens Maurer
copyright Cephes Math
(c) David Abrahams 2002
Copyright (c) 2010 Ilya
Copyright Albert Steppi
Copyright Gautam Sewani
Copyright Nat Goodspeed
(c) 2008 Gordon Woodhull
(c) 2011 import warnings
Copyright (c) 2018 Yi Ji
Copyright 2012 IBM Corp.
Copyright 2013 Kyle Lutz
Copyright 2018 Ulf Adams
Copyright Catch2 Authors
Copyright Lingxi Li 2015
copyright Boost Software
copyright Xiaogang Zhang
copyrighted by Alan Genz
(c) Peter Kankowski, 2008
Copyright (c) 2019 Damian
Copyright 2003 Bruce Barr
Copyright 2006 Johan Rade
Copyright 2011 Simon West
Copyright 2012 K R Walker
Copyright Jaap Suter 2003
Copyright Jan Langer 2002
Copyright Paul A. Bristow
Csp self.spmatrix (c) Dsp
copyright Jason Rice 2016
copyright Jason Rice 2017
copyright by Renee Touzin
Copyright 2000 Jens Maurer
Copyright 2003 Jeremy Siek
Copyright 2005 Dan Marsden
Copyright 2005 Peter Dimov
Copyright 2007 Peter Dimov
Copyright 2008 Beman Dawes
Copyright 2008 Peter Dimov
Copyright 2009 Neil Groves
Copyright 2010 Beman Dawes
Copyright 2013 Ankur Sinha
Copyright 2013 Peter Dimov
Copyright 2014 Neil Groves
Copyright 2014 Peter Dimov
Copyright 2015 Peter Dimov
Copyright 2016 Jorge Lodos
Copyright 2017 Peter Dimov
Copyright 2018 Peter Dimov
Copyright 2019 Peter Dimov
Copyright 2020 Peter Dimov
Copyright Beman Dawes 2001
Copyright Beman Dawes 2002
Copyright Beman Dawes 2003
Copyright Beman Dawes 2005
Copyright Beman Dawes 2006
Copyright Beman Dawes 2007
Copyright Beman Dawes 2008
Copyright Beman Dawes 2009
Copyright Beman Dawes 2010
Copyright Beman Dawes 2011
Copyright Beman Dawes 2013
Copyright Beman Dawes 2014
Copyright Beman Dawes 2015
Copyright Bruno Dutra 2015
Copyright Evan Miller 2020
Copyright Franz Detro 2014
Copyright Jens Maurer 2000
Copyright Jens Maurer 2002
Copyright Jens Maurer 2006
Copyright Joel Falcou 2015
Copyright Neil Groves 2007
Copyright Neil Groves 2009
Copyright Neil Groves 2010
Copyright Neil Groves 2014
Copyright Peter Dimov 2001
Copyright Peter Dimov 2019
Copyright Rene Rivera 2013
Copyright Rene Rivera 2014
Copyright Rene Rivera 2015
Copyright Rene Rivera 2017
Copyright Thomas Mang 2012
Copyright ohn Maddock 2012
(c) 2011 import numpy as np
(c) 2012 import numpy as np
(c) 2014 import numpy as np
(c) Copyright 2014 Jim Bell
Copyright (c) 2011 Jamboree
Copyright (c) 2013 Jamboree
Copyright (c) 2014 Jamboree
Copyright 2000 by Alan Genz
Copyright 2001 John Maddock
Copyright 2004 Eric Niebler
Copyright 2005 Eric Niebler
Copyright 2006 Eric Niebler
Copyright 2006 John Maddock
Copyright 2007 Eric Niebler
Copyright 2008 Eric Niebler
Copyright 2008 John Maddock
Copyright 2009 Eric Niebler
Copyright 2010 Eric Niebler
Copyright 2010 John Maddock
Copyright 2011 Eric Niebler
Copyright 2011 John Maddock
Copyright 2011, Andrew Ross
Copyright 2012 Eric Niebler
Copyright 2012 John Maddock
Copyright 2013 John Maddock
Copyright 2013 Paul Bristow
Copyright 2014 John Maddock
Copyright 2014 NumScale SAS
Copyright 2014 Paul Bristow
Copyright 2015 John Maddock
Copyright 2015 NumScale SAS
Copyright 2016 John Maddock
Copyright 2017 Daniel James
Copyright 2017 John Maddock
Copyright 2017 Vinnie Falco
Copyright 2018 John Maddock
Copyright 2019 John Maddock
Copyright 2020 John Maddock
Copyright Beman Dawes, 2009
Copyright Eric Niebler 2005
Copyright Eric Niebler 2008
Copyright Eric Niebler 2009
Copyright Eric Niebler 2014
Copyright John Maddock 2005
Copyright John Maddock 2006
Copyright John Maddock 2007
Copyright John Maddock 2008
Copyright John Maddock 2009
Copyright John Maddock 2010
Copyright John Maddock 2011
Copyright John Maddock 2012
Copyright John Maddock 2013
Copyright John Maddock 2014
Copyright John Maddock 2015
Copyright John Maddock 2016
Copyright John Maddock 2017
Copyright John Maddock 2018
Copyright Louis Dionne 2013
Copyright Orson Peters 2017
Copyright Paul Bristow 2007
Copyright Paul Bristow 2014
Copyright Robert Ramey 2007
Copyright Robin Eckert 2015
Copyright Timmo Stange 2007
copyright Louis Dionne 2016
(c) Copyright Francois Faure
(c) Copyright Howard Hinnant
Copyright (c) 2017 Dynatrace
Copyright (c) 2018 ERGO-Code
Copyright (c) 2021 ERGO-Code
Copyright (c) 2022 ERGO-Code
Copyright (c) Piers Lawrence
Copyright 2002 Daryle Walker
Copyright 2003 - 2011 LASMEA
Copyright 2005 Ben Hutchings
Copyright 2005 Daniel Egloff
Copyright 2005 Daniel Wallin
Copyright 2006 Andy Tompkins
Copyright 2006 Ion Gaztanaga
Copyright 2007 Aaron Windsor
Copyright 2007 Andy Tompkins
Copyright 2007 Baruch Zilber
Copyright 2007 Boris Gubenko
Copyright 2007 David Jenkins
Copyright 2008 CodeRage, LLC
Copyright 2008 David Jenkins
Copyright 2008 Gautam Sewani
Copyright 2009 Andy Tompkins
Copyright 2010 Andy Tompkins
Copyright 2012 Chung-Lin Wen
Copyright 2012 Denis Demidov
Copyright 2013 Andrea Gavana
Copyright 2014 MetaScale SAS
Copyright 2015 John Fletcher
Copyright 2020 Ion Gaztanaga
Copyright Andy Tompkins 2006
Copyright Bryce Lelbach 2010
Copyright Daniel Walker 2006
Copyright Daniel Walker 2007
Copyright Daniel Wallin 2005
Copyright Daniel Wallin 2006
Copyright Daniel Wallin 2007
Copyright Dietmar Kuehl 2001
Copyright Eric Friedman 2002
Copyright Eric Friedman 2003
Copyright Gautam Sewani 2008
Copyright John Maddock, 2020
Copyright Nat Goodspeed 2014
Copyright Nick Thompson 2017
Copyright Nick Thompson 2019
Copyright Samuel Krempp 2003
Copyright Vladimir Prus 2002
Copyright Vladimir Prus 2004
Copyright Yosef Meller, 2009
(c) Copyright Bill Kempf 2001
(c) Copyright Bill Kempf 2002
(c) Copyright Brian Kuhl 2016
(c) Copyright Jens Mauer 2001
(c) Copyright Johan Rade 2006
(c) Copyright Paul Moore 1999
(c) Copyright Synge Todo 2003
Copyright (c) 2002 Bill Kempf
Copyright (c) 2004 Peder Holt
Copyright (c) 2005 Peder Holt
Copyright (c) 2006 Johan Rade
Copyright (c) 2007 Peder Holt
Copyright (c) 2010 Peder Holt
Copyright (c) 2014 Eric Moore
Copyright (c) 2014 Ian Forbed
Copyright (c) 2015 Mario Lang
Copyright (c) 2018 Fady Essam
Copyright (c) 2018 agate-pris
Copyright (c) 2019 Peter Bell
Copyright (c) 2019 agate-pris
Copyright (c) 2020 Jeff Trull
Copyright 2002 Gary Strangman
Copyright 2002 Pearu Peterson
Copyright 2005 Douglas Gregor
Copyright 2005 Jeremy G. Siek
Copyright 2005 Joel de Guzman
Copyright 2006 Douglas Gregor
Copyright 2006 Roland Schwarz
Copyright 2008 Hartmut Kaiser
Copyright 2008 Howard Hinnant
Copyright 2009, Andrew Sutton
Copyright 2010 Mario Mulansky
Copyright 2011 Karsten Ahnert
Copyright 2011 Mario Mulansky
Copyright 2012 Christoph Koke
Copyright 2012 Karsten Ahnert
Copyright 2012 Mario Mulansky
Copyright 2013 Karsten Ahnert
Copyright 2013 Mario Mulansky
Copyright 2013 Nikhar Agrawal
Copyright 2014 Anton Bikineev
Copyright 2014 Bill Gallafent
Copyright 2014, Eric W. Moore
Copyright 2015 Mario Mulansky
Copyright 2018 Hans Dembinski
Copyright 2018 Stefan Seefeld
Copyright 2019 Hans Dembinski
Copyright 2019 Mateusz Loskot
Copyright 2020 Hans Dembinski
Copyright 2020 Madhur Chauhan
Copyright Alain Miniussi 2014
Copyright Andreas Schwab 2019
Copyright Beman Dawes 1994-99
Copyright Christian Lorentzen
Copyright David Abrahams 2001
Copyright David Abrahams 2002
Copyright David Abrahams 2003
Copyright David Abrahams 2004
Copyright David Abrahams 2005
Copyright David Abrahams 2006
Copyright David Abrahams 2009
Copyright Douglas Gregor 2003
Copyright Douglas Gregor 2004
Copyright Hans Dembinski 2020
Copyright Jim Bosch 2010-2012
Copyright John Maddock 2006-7
Copyright John Maddock 2007-8
Copyright Marco Guazzone 2014
Copyright Nick Thompson, 2017
Copyright Nick Thompson, 2018
Copyright Nick Thompson, 2019
Copyright Nick Thompson, 2020
Copyright Oliver Kowalke 2009
Copyright Oliver Kowalke 2013
Copyright Oliver Kowalke 2014
Copyright Oliver Kowalke 2015
Copyright Oliver Kowalke 2016
Copyright Oliver Kowalke 2017
Copyright Oliver Kowalke 2018
Copyright Ruslan Baratov 2017
Copyright Shreyans Doshi 2017
Copyright Stefan Seefeld 2005
Copyright Stefan Seefeld 2016
Copyright Steven J. Ross 2014
Copyright Vladimir Prus, 2002
Copyright Xiaogang Zhang 2006
(c) Copyright Beman Dawes 1999
(c) Copyright Beman Dawes 2000
(c) Copyright Beman Dawes 2001
(c) Copyright Beman Dawes 2002
(c) Copyright Beman Dawes 2003
(c) Copyright Boris Rasin 2014
(c) Copyright Darin Adler 2000
(c) Copyright Darin Adler 2001
(c) Copyright Jens Maurer 2001
(c) Copyright Jens Maurer 2003
(c) Copyright Jeremy Siek 1999
(c) Copyright Jeremy Siek 2000
(c) Copyright Jeremy Siek 2001
(c) Copyright Jeremy Siek 2002
(c) Copyright Jeremy Siek 2004
(c) Copyright Jeremy Siek 2006
(c) Copyright Jim Douglas 2005
(c) Copyright Jorge Lodos 2008
(c) Copyright Peter Dimov 2001
(c) Copyright Peter Dimov 2002
(c) Copyright Peter Dimov 2008
(c) Copyright Peter Dimov 2017
(c) Copyright Peter Dimov 2019
(c) Copyright Rene Rivera 2005
(c) Copyright Thomas Witt 2002
(c) Copyright Tobias Schwinger
(c) Copyright Toon Knapen 2001
(c) Copyright Toon Knapen 2003
Copyright (c) 2001 Darin Adler
Copyright (c) 2001 Doug Gregor
Copyright (c) 2001 Peter Dimov
Copyright (c) 2002 Beman Dawes
Copyright (c) 2002 Jens Maurer
Copyright (c) 2002 Peter Dimov
Copyright (c) 2003 Daniel Frey
Copyright (c) 2003 Peter Dimov
Copyright (c) 2003 Thomas Witt
Copyright (c) 2005 Dan Marsden
Copyright (c) 2005 Peter Dimov
Copyright (c) 2006 Dan Marsden
Copyright (c) 2006 Peter Dimov
Copyright (c) 2007 Dan Marsden
Copyright (c) 2007 Peter Dimov
Copyright (c) 2008 Beman Dawes
Copyright (c) 2008 Damian Eads
Copyright (c) 2008 Peter Dimov
Copyright (c) 2009 Carl Barron
Copyright (c) 2009 Peter Dimov
Copyright (c) 2010 Neil Groves
Copyright (c) 2012 David Stone
Copyright (c) 2012 Google Inc.
Copyright (c) 2013 Carl Barron
Copyright (c) 2013 Peter Dimov
Copyright (c) 2014 Lee Clagett
Copyright (c) 2014 Peter Dimov
Copyright (c) 2014 Tomoki Imai
Copyright (c) 2015 Seth Heeren
Copyright (c) 2016 Lee Clagett
Copyright (c) 2016 Peter Dimov
Copyright (c) 2018 Peter Dimov
Copyright (c) 2019 Peter Dimov
Copyright (c) 2020 Peter Dimov
Copyright (c) Beman Dawes 2011
Copyright (c) Beman Dawes 2015
Copyright (c) Dan Watkins 2003
Copyright (c) Jeremy Siek 2001
Copyright (c) Thomas Witt 2002
Copyright 1999 Travis Oliphant
Copyright 2000 Maarten Keijzer
Copyright 2005 Matthias Troyer
Copyright 2005 Travis Oliphant
Copyright 2008 Joaquin M Lopez
Copyright 2009 Steven Watanabe
Copyright 2010 Kenneth Riddile
Copyright 2010 Paul A. Bristow
Copyright 2011 Paul A. Bristow
Copyright 2011 Steven Watanabe
Copyright 2012 Andreas Pokorny
Copyright 2012 Paul A. Bristow
Copyright 2012 Steven Watanabe
Copyright 2012-20 John Maddock
Copyright 2013 Andrey Semashev
Copyright 2013 Pascal Germroth
Copyright 2014 Andrey Semashev
Copyright 2014 Antony Polukhin
Copyright 2015 Andrey Semashev
Copyright 2015 Antony Polukhin
Copyright 2015 Steven Watanabe
Copyright 2016 Andrey Semashev
Copyright 2016 Joaquin M Lopez
Copyright 2017 Andrey Semashev
Copyright 2017 Joaquin M Lopez
Copyright 2018 Joaquin M Lopez
Copyright 2018 Steven Watanabe
Copyright 2019 Emil Dotchevski
Copyright 2019 Henry Schreiner
Copyright 2020 Andrey Semashev
Copyright 2020 Samuel Debionne
Copyright Adam D. Walling 2012
Copyright Alexander Grund 2018
Copyright Andrey Semashev 2013
Copyright Andrey Semashev 2015
Copyright Andrey Semashev 2016
Copyright Andrey Semashev 2018
Copyright Andrey Semashev 2019
Copyright Andrey Semashev 2020
Copyright Bertolt Mildner 2004
Copyright Daniel Trebbien 2010
Copyright Emil Dotchevski 2007
Copyright Frank Mori Hess 2007
Copyright Frank Mori Hess 2008
Copyright Frank Mori Hess 2009
Copyright John Maddock 2008-11
Copyright John R. Bandela 2001
Copyright Paul A. Bristow 2006
Copyright Paul A. Bristow 2007
Copyright Paul A. Bristow 2010
Copyright Paul A. Bristow 2012
Copyright Paul A. Bristow 2013
Copyright Paul A. Bristow 2014
Copyright Paul A. Bristow 2017
Copyright Paul Mensonides 2003
Copyright Sergey Krivonos 2017
Copyright Steven Watanabe 2009
Copyright Steven Watanabe 2010
Copyright Steven Watanabe 2011
Copyright Steven Watanabe 2014
copyrighted by Enthought, Inc.
(c) Copyright 2005 John Maddock
(c) Copyright 2008 Robert Ramey
(c) Copyright 2010 Daniel James
(c) Copyright 2010 Robert Ramey
(c) Copyright 2020 Robert Ramey
(c) Copyright Daniel K. O. 2005
(c) Copyright Hubert Holin 2001
(c) Copyright Hubert Holin 2003
(c) Copyright Jeremy Siek, 2001
(c) Copyright John Maddock 2000
(c) Copyright John Maddock 2001
(c) Copyright John Maddock 2002
(c) Copyright John Maddock 2003
(c) Copyright John Maddock 2005
(c) Copyright John Maddock 2006
(c) Copyright John Maddock 2007
(c) Copyright John Maddock 2008
(c) Copyright John Maddock 2010
(c) Copyright John Maddock 2011
(c) Copyright John Maddock 2015
(c) Copyright John Maddock 2017
(c) Copyright John Maddock 2018
(c) Copyright Lie-Quan Lee 2001
(c) Copyright Martin Wille 2003
(c) Copyright Orson Peters 2017
(c) Copyright Rani Sharoni 2003
(c) Copyright Robert Ramey 2004
Copyright (c) 2002 John Maddock
Copyright (c) 2003 John Maddock
Copyright (c) 2003 Martin Wille
Copyright (c) 2004 John Maddock
Copyright (c) 2005 Eric Niebler
Copyright (c) 2006 Eric Niebler
Copyright (c) 2006 John Maddock
Copyright (c) 2006 Stephen Nutt
Copyright (c) 2007 John Maddock
Copyright (c) 2007, Damian Eads
Copyright (c) 2008 Eric Niebler
Copyright (c) 2008 Roelof Naude
Copyright (c) 2009 John Maddock
Copyright (c) 2010 Eric Niebler
Copyright (c) 2011 Aaron Graham
Copyright (c) 2011 Brandon Kohn
Copyright (c) 2011 Eric Niebler
Copyright (c) 2011 John Maddock
Copyright (c) 2012 Nathan Ridge
Copyright (c) 2012 Oswin Krause
Copyright (c) 2012 Robert Ramey
Copyright (c) 2013 Eurodecision
Copyright (c) 2014 Eric Niebler
Copyright (c) 2014 Mageswaran.D
Copyright (c) 2015 John Maddock
Copyright (c) 2015 Orson Peters
Copyright (c) 2015 Robert Ramey
Copyright (c) 2016 Adrian Veres
Copyright (c) 2017 John Maddock
Copyright (c) 2017 Michel Morin
Copyright (c) 2017 Robert Ramey
Copyright (c) 2017 Vinnie Falco
Copyright (c) 2020 John Maddock
Copyright (c) 2021 Orson Peters
Copyright (c) Tyler Reddy, 2016
Copyright 2002-2018 Peter Dimov
Copyright 2003-2005 Peter Dimov
Copyright 2004-2005 Peter Dimov
Copyright 2004-2006 Peter Dimov
Copyright 2004-2008 Peter Dimov
Copyright 2005-2013 Peter Dimov
Copyright 2006 Thorsten Ottosen
Copyright 2007 Tobias Schwinger
Copyright 2008 Christophe Henry
Copyright 2008,2012 Peter Dimov
Copyright 2009-2014 Neil Groves
Copyright 2011 Christophe Henry
Copyright 2012 (c) Google, Inc.
Copyright 2012 Lucanus Simonson
Copyright 2012, Philipp Moeller
Copyright 2013 Maciej Piechotka
Copyright 2015-2017 Peter Dimov
Copyright 2015-2019 Peter Dimov
Copyright 2015-2020 Peter Dimov
Copyright 2017-2019 Peter Dimov
Copyright Aleksey Gurtovoy 2004
Copyright Aleksey Gurtovoy 2006
Copyright Aleksey Gurtovoy 2008
Copyright Beman Dawes 1995-2001
Copyright Beman Dawes 2002-2009
Copyright Benjamin Sobotta 2012
Copyright Benjamin Worpitz 2018
Copyright Charly Chevalier 2015
Copyright Jens Maurer 2000-2001
Copyright Jessica Hamilton 2014
Copyright Neil Groves 2003-2004
Copyright Nikolay Mladenov 2007
Copyright Pavol Droba 2002-2003
Copyright Pavol Droba 2002-2004
Copyright Pavol Droba 2002-2006
Copyright Peter Dimov 2000-2002
Copyright Peter Dimov 2000-2003
Copyright Peter Dimov 2001-2002
Copyright Peter Dimov 2001-2003
Copyright Rene Rivera 2005-2016
Copyright Rene Rivera 2008-2013
Copyright Rene Rivera 2008-2015
Copyright Rene Rivera 2008-2017
Copyright Rene Rivera 2008-2019
Copyright Rene Rivera 2011-2012
Copyright Rene Rivera 2011-2015
Copyright Rene Rivera 2012-2015
Copyright Rene Rivera 2013-2015
Copyright Rene Rivera 2014-2015
Copyright Rene Rivera 2015-2016
Copyright Rene Rivera 2015-2019
Copyright Thorsten Ottosen 2006
Copyright Thorsten Ottosen 2008
(c) Copyright 2007 Andrew Sutton
(c) Copyright 2007 David Deakins
(c) Copyright 2008 CodeRage, LLC
(c) Copyright 2012 Vicente Botet
(c) Copyright 2013 Tim Blechmann
(c) Copyright Andrew Sutton 2007
(c) Copyright Artyom Beilis 2010
(c) Copyright Balint Cserni 2017
(c) Copyright Boris Gubenko 2007
(c) Copyright Bruno Lalande 2008
(c) Copyright Bryce Lelbach 2010
(c) Copyright Bryce Lelbach 2011
(c) Copyright Daniel Wallin 2004
(c) Copyright Daryle Walker 2001
(c) Copyright Edward Diener 2011
(c) Copyright Edward Diener 2012
(c) Copyright Edward Diener 2013
(c) Copyright Edward Diener 2014
(c) Copyright Edward Diener 2015
(c) Copyright Edward Diener 2016
(c) Copyright Edward Diener 2019
(c) Copyright Edward Diener 2020
(c) Copyright Gennaro Prota 2003
(c) Copyright Ion Gaztanaga 2005
(c) Copyright Ion Gaztanaga 2006
(c) Copyright Ion Gaztanaga 2008
(c) Copyright Ion Gaztanaga 2009
(c) Copyright Ion Gaztanaga 2014
(c) Copyright Milan Svoboda 2008
(c) Copyright Nick Thompson 2017
(c) Copyright Nick Thompson 2018
(c) Copyright Nick Thompson 2019
(c) Copyright Nick Thompson 2020
(c) Copyright Noel Belcourt 2007
(c) Copyright Pablo Halpern 2009
(c) Copyright Ronald Garcia 2002
Copyright (c) 2001 Bruce Florman
Copyright (c) 2001 Daniel Nuffer
Copyright (c) 2001 Daryle Walker
Copyright (c) 2001 Dietmar Kuehl
Copyright (c) 2002 Jeff Westfahl
Copyright (c) 2003 Eric Friedman
Copyright (c) 2003 Gennaro Prota
Copyright (c) 2003 Giovanni Bajo
Copyright (c) 2003 Vaclav Vesely
Copyright (c) 2003 Vesa Karvonen
Copyright (c) 2003 Vladimir Prus
Copyright (c) 2004 Angus Leeming
Copyright (c) 2004 Daniel Wallin
Copyright (c) 2005 Aaron Windsor
Copyright (c) 2005 Stefan Arentz
Copyright (c) 2006 Daniel Wallin
Copyright (c) 2006 Tomas Puverle
Copyright (c) 2008 Ion Gaztanaga
Copyright (c) 2009 Andrew Sutton
Copyright (c) 2009 Helge Bahmann
Copyright (c) 2009 Phil Endecott
Copyright (c) 2010 Artyom Beilis
Copyright (c) 2010 Bryce Lelbach
Copyright (c) 2010 Helge Bahmann
Copyright (c) 2010 Thomas Heller
Copyright (c) 2010 Tim Blechmann
Copyright (c) 2011 Bryce Lelbach
Copyright (c) 2011 Helge Bahmann
Copyright (c) 2011 Thomas Heller
Copyright (c) 2011 Tim Blechmann
Copyright (c) 2012 Artyom Beilis
Copyright (c) 2012 Bruno Lalande
Copyright (c) 2012 Paul Fultz II
Copyright (c) 2012 Tim Blechmann
Copyright (c) 2013 Agustin Berge
Copyright (c) 2013 Bruno Lalande
Copyright (c) 2013 Joaquim Duran
Copyright (c) 2013 Kenneth L. Ho
Copyright (c) 2013 Tim Blechmann
Copyright (c) 2014 Agustin Berge
Copyright (c) 2014 Ahmed Charles
Copyright (c) 2014 Bruno Lalande
Copyright (c) 2014 John Fletcher
Copyright (c) 2014 Paul Fultz II
Copyright (c) 2015 Artyom Beilis
Copyright (c) 2015 Ion Gaztanaga
Copyright (c) 2015 John Fletcher
Copyright (c) 2015 Paul Fultz II
Copyright (c) 2016 Barrett Adair
Copyright (c) 2016 Paul Fultz II
Copyright (c) 2018 Artyom Beilis
Copyright (c) Aaron Windsor 2007
Copyright (c) Chris Glover, 2016
Copyright (c) Kevlin Henney 2001
Copyright (c) Marshall Clow 2014
Copyright (c) Marshall Clow 2017
Copyright (c) Pablo Aguilar 2005
Copyright (c) Vladimir Prus 2003
Copyright 1991 Dieter Kraft, FHM
Copyright 1997-2008 by Agner Fog
Copyright 2002, 2009 Peter Dimov
Copyright 2002, 2020 Peter Dimov
Copyright 2002-2008 by Agner Fog
Copyright 2002-2014 by Agner Fog
Copyright 2004-2008 by Agner Fog
Copyright 2004-2013 by Agner Fog
Copyright 2005 Alexander Nasonov
Copyright 2005, 2014 Peter Dimov
Copyright 2005-2009 Daniel James
Copyright 2005-2011 Daniel James
Copyright 2005-2012 Daniel James
Copyright 2005-2014 Daniel James
Copyright 2006, 2020 Peter Dimov
Copyright 2007 Christian Henning
Copyright 2007, 2014 Peter Dimov
Copyright 2007, 2019 Peter Dimov
Copyright 2007, 2020 Peter Dimov
Copyright 2008 Christian Henning
Copyright 2008 Intel Corporation
Copyright 2008, 2020 Peter Dimov
Copyright 2009 Christian Henning
Copyright 2010 Christian Henning
Copyright 2010 Thomas Claveirole
Copyright 2012 Christian Henning
Copyright 2012 Olivier Tournaire
Copyright 2012-2020 John Maddock
Copyright 2013 Christian Henning
Copyright 2013 Christian Shelton
Copyright 2013 Cromwell D. Enage
Copyright 2015, 2016 Peter Dimov
Copyright 2015, 2019 Peter Dimov
Copyright 2016, 2017 Peter Dimov
Copyright 2017 James E. King III
Copyright 2017, 2018 Peter Dimov
Copyright 2017, 2019 Peter Dimov
Copyright 2018, 2020 Peter Dimov
Copyright 2019, 2020 Peter Dimov
Copyright 2019-20 Madhur Chauhan
Copyright Alexander Nasonov 2004
Copyright Anne M. Archibald 2008
Copyright Beman Dawes 2002, 2006
Copyright Beman Dawes 2003, 2006
Copyright Beman Dawes 2006, 2007
Copyright Beman Dawes, 2002-2005
Copyright Christopher Brown 2013
Copyright Cromwell D. Enage 2013
Copyright Cromwell D. Enage 2017
Copyright Cromwell D. Enage 2018
Copyright Cromwell D. Enage 2019
Copyright Jason Rhinelander 2016
Copyright John Maddock 2005-2006
Copyright John Maddock 2005-2008
Copyright Louis Dionne 2013-2017
Copyright Nicholas Thompson 2018
Copyright Nikhar Agrawal 2013-14
Copyright Paul A. Bristow 2006-7
Copyright Peter Dimov 2017, 2018
Copyright Thorsten Ottosen, 2009
copyright Louis Dionne 2013-2016
copyright Louis Dionne 2013-2017
(c) Copyright 2006 Douglas Gregor
(c) Copyright 2009 Eric Bose-Wolf
(c) Copyright 2013 Ruslan Baratov
(c) Copyright Anton Bikineev 2014
(c) Copyright David Abrahams 2000
(c) Copyright David Abrahams 2001
(c) Copyright David Abrahams 2002
(c) Copyright David Abrahams 2003
(c) Copyright David Abrahams 2004
(c) Copyright Douglas Gregor 2001
(c) Copyright Douglas Gregor 2002
(c) Copyright Douglas Gregor 2010
(c) Copyright Howard Hinnant 2004
(c) Copyright Joel de Guzman 2003
(c) Copyright John Maddock 2001-8
(c) Copyright John Maddock 2006-7
(c) Copyright John Maddock 2006-8
(c) Copyright Juergen Hunold 2008
(c) Copyright Roland Richter 2003
(c) Copyright Stefan Slapeta 2004
(c) Copyright Stephen Cleary 2000
Copyright (c) 2000 David Abrahams
Copyright (c) 2000 Stephen Cleary
Copyright (c) 2001 David Abrahams
Copyright (c) 2002 David Abrahams
Copyright (c) 2002 Joel de Guzman
Copyright (c) 2003 David Abrahams
Copyright (c) 2003 Hartmut Kaiser
Copyright (c) 2003 Howard Hinnant
Copyright (c) 2003 Joel de Guzman
Copyright (c) 2004 Hartmut Kaiser
Copyright (c) 2004 Joel de Guzman
Copyright (c) 2004 Ralf Mattethat
Copyright (c) 2005 Douglas Gregor
Copyright (c) 2005 Igor Chesnokov
Copyright (c) 2006 Douglas Gregor
Copyright (c) 2006 Piotr Wyderski
Copyright (c) 2006 Xiaogang Zhang
Copyright (c) 2006-7 John Maddock
Copyright (c) 2007 Douglas Gregor
Copyright (c) 2007 Hartmut Kaiser
Copyright (c) 2007 Joel de Guzman
Copyright (c) 2008 Michael Marcin
Copyright (c) 2009 Chris Hoeppler
Copyright (c) 2009 Francois Barel
Copyright (c) 2009 Gunter Winkler
Copyright (c) 2009 Hartmut Kaiser
Copyright (c) 2009 Pauli Virtanen
Copyright (c) 2009 Sebastian Redl
Copyright (c) 2009, Motorola, Inc
Copyright (c) 2010 Alfredo Correa
Copyright (c) 2011 ! Brandon Kohn
Copyright (c) 2011 Hartmut Kaiser
Copyright (c) 2011 Thomas Bernard
Copyright (c) 2012 Hartmut Kaiser
Copyright (c) 2012 Martin Raspaud
Copyright (c) 2012, Michele Caini
Copyright (c) 2013 Anton Bikineev
Copyright (c) 2013 Mateusz Loskot
Copyright (c) 2013 Pauli Virtanen
Copyright (c) 2013 Sebastian Redl
Copyright (c) 2014 Erik Erlandson
Copyright (c) 2014 Glen Fernandes
Copyright (c) 2014 Joel de Guzman
Copyright (c) 2014 Oliver Kowalke
Copyright (c) 2014 Thomas Bernard
Copyright (c) 2015 Sebastian Redl
Copyright (c) 2016 Norbert Wenzel
Copyright (c) 2016-2018 ERGO-Code
Copyright (c) 2016-2019 ERGO-Code
Copyright (c) 2017 Daniela Engert
Copyright (c) 2018 Alain Miniussi
Copyright (c) 2018 Evgeny Shulgin
Copyright (c) 2018 Sergei Fedorov
Copyright (c) 2018 Stefan Seefeld
Copyright (c) 2018-2019 ERGO-Code
Copyright (c) 2018-2021 ERGO-Code
Copyright (c) 2019 Joel de Guzman
Copyright (c) 2020 Nikita Kniazev
Copyright (c) David Abrahams 2001
Copyright (c) Douglas Gregor 2004
Copyright (c) Douglas Gregor 2008
Copyright 2001 Indiana University
Copyright 2002 Indiana University
Copyright 2006-2007 Boris Gubenko
Copyright 2007 Alexandre Courpron
Copyright 2007-2008 CodeRage, LLC
Copyright 2007-2012 Ion Gaztanaga
Copyright 2011 -2013 John Maddock
Copyright 2011 Paul A. Bristow To
Copyright 2017 James E. King, III
Copyright Barrett Adair 2015-2017
Copyright Barrett Adair 2015-2018
Copyright Barrett Adair 2016-2017
Copyright Dave Abrahams 2001-2002
Copyright Eric Friedman 2002-2003
Copyright James E. King III, 2017
Copyright John Maddock 2006, 2007
Copyright John Maddock 2006, 2010
Copyright John Maddock 2006, 2011
Copyright John Maddock 2006, 2012
Copyright John Maddock 2007, 2014
Copyright John Maddock 2008, 2012
Copyright John Maddock 2010, 2012
Copyright Paul Bristow 2006, 2007
Copyright Paul Bristow 2007, 2011
Copyright Thijs van den Berg 2014
Copyright Vladimir Prus 2002-2004
(c) Copyright 2004 Pavel Vozenilek
(c) Copyright 2005 Matthias Troyer
(c) Copyright 2007 Matthias Troyer
(c) Copyright 2008 Matthias Troyer
(c) Copyright 2013 Andrey Semashev
(c) Copyright 2016 Raffi Enficiaud
(c) Copyright 2017 Andrey Semashev
(c) Copyright Andrey Semashev 2017
(c) Copyright Antony Polukhin 2013
(c) Copyright Antony Polukhin 2014
(c) Copyright Craig Henderson 2002
(c) Copyright Dustin Spicuzza 2009
(c) Copyright Ignacy Gawedzki 2010
(c) Copyright Jonathan Graehl 2004
(c) Copyright Paul A. Bristow 2006
(c) Copyright Paul A. Bristow 2011
(c) Copyright Paul Mensonides 2002
(c) Copyright Paul Mensonides 2003
(c) Copyright Paul Mensonides 2005
(c) Copyright Paul Mensonides 2011
(c) Copyright Paul Mensonides 2012
(c) Copyright Raffi Enficiaud 2017
(c) Copyright Raffi Enficiaud 2018
(c) Copyright Raffi Enficiaud 2019
Copyright (c) 1995, Gerald Evenden
Copyright (c) 2002 Travis Oliphant
Copyright (c) 2003 Paul Mensonides
Copyright (c) 2003-2008 Jan Gaspar
Copyright (c) 2005-2007 Peder Holt
Copyright (c) 2006 Steven Watanabe
Copyright (c) 2006-2008 Johan Rade
Copyright (c) 2007 Alexey Baskakov
Copyright (c) 2007 Matthias Troyer
Copyright (c) 2008 Frank Mori Hess
Copyright (c) 2008 Steven Watanabe
Copyright (c) 2008-2009 Ben Hanson
Copyright (c) 2009 Boris Schaeling
Copyright (c) 2009 Frank Mori Hess
Copyright (c) 2009 Steven Watanabe
Copyright (c) 2009, Gunter Winkler
Copyright (c) 2009, Marco Guazzone
Copyright (c) 2010 Paul A. Bristow
Copyright (c) 2011 Emil Dotchevski
Copyright (c) 2011 Julio Hoffimann
Copyright (c) 2011 Paul A. Bristow
Copyright (c) 2011 Steven Watanabe
Copyright (c) 2012 Boris Schaeling
Copyright (c) 2012 Kohei Takahashi
Copyright (c) 2012 Paul A. Bristow
Copyright (c) 2013 Antony Polukhin
Copyright (c) 2013 Paul A. Bristow
Copyright (c) 2014 Andrey Semashev
Copyright (c) 2014 Christoph Weiss
Copyright (c) 2014 Kohei Takahashi
Copyright (c) 2015 Andrey Semashev
Copyright (c) 2015 Kohei Takahashi
Copyright (c) 2016 Kohei Takahashi
Copyright (c) 2017 Andrey Semashev
Copyright (c) 2017 Kohei Takahashi
Copyright (c) 2017-2018 Chris Beck
Copyright (c) 2018 Andrey Semashev
Copyright (c) 2018 Kohei Takahashi
Copyright (c) 2018, Quansight-Labs
Copyright (c) 2018-2019 Cem Bassoy
Copyright (c) 2019 Andrey Semashev
Copyright (c) 2019-2020 Peter Bell
Copyright (c) 2020 Alexander Grund
Copyright (c) 2020 Andrey Semashev
Copyright (c) Andrey Semashev 2017
Copyright (c) Pauli Virtanen, 2010
Copyright 2002, 2005 Daryle Walker
Copyright 2003 Guillaume Melquiond
Copyright 2005 Guillaume Melquiond
Copyright 2007 Stanford University
Copyright 2009-2011 Karsten Ahnert
Copyright 2009-2011 Mario Mulansky
Copyright 2009-2012 Karsten Ahnert
Copyright 2009-2012 Mario Mulansky
Copyright 2009-2013 Karsten Ahnert
Copyright 2009-2013 Mario Mulansky
Copyright 2009-2015 Mario Mulansky
Copyright 2010-2011 Karsten Ahnert
Copyright 2010-2011 Mario Mulansky
Copyright 2010-2012 Karsten Ahnert
Copyright 2010-2012 Mario Mulansky
Copyright 2010-2013 Karsten Ahnert
Copyright 2010-2013 Mario Mulansky
Copyright 2010-2014 Mario Mulansky
Copyright 2010-2015 Mario Mulansky
Copyright 2011 - 2013 John Maddock
Copyright 2011-2012 Karsten Ahnert
Copyright 2011-2012 Mario Mulansky
Copyright 2011-2013 Karsten Ahnert
Copyright 2011-2013 Mario Mulansky
Copyright 2011-2015 Mario Mulansky
Copyright 2012-2013 Karsten Ahnert
Copyright 2012-2013 Mario Mulansky
Copyright 2012-2015 Mario Mulansky
Copyright 2013-2014 Karsten Ahnert
Copyright 2013-2014 Mario Mulansky
Copyright 2015 Jon Lund Steffensen
Copyright 2015 Klemens Morgenstern
Copyright 2015-2016 Hans Dembinski
Copyright 2015-2017 Hans Dembinski
Copyright 2015-2018 Hans Dembinski
Copyright 2015-2019 Hans Dembinski
Copyright 2016 Klemens Morgenstern
Copyright 2017 Two Blue Cubes Ltd.
Copyright 2018-2019 Hans Dembinski
Copyright 2019 Przemyslaw Bartosik
Copyright Christoper Kohlhoff 2007
Copyright David Abrahams 2000-2002
Copyright David Abrahams 2001-2002
Copyright David Abrahams 2002-2003
Copyright David Abrahams 2003-2004
Copyright Douglas Gregor 2001-2003
Copyright Douglas Gregor 2001-2004
Copyright Douglas Gregor 2001-2006
Copyright Douglas Gregor 2002-2003
Copyright Douglas Gregor 2002-2004
Copyright Gottfried Ganssauge 2003
Copyright Howard Hinnant 2007-2010
Copyright Kevlin Henney, 2000-2005
Copyright Michael Drexl 2005, 2006
Copyright Sebastian Ramacher, 2007
Copyright Thijs van den Berg, 2008
(c) Copyright 2007 Anthony Williams
(c) Copyright 2008 Anthony Williams
(c) Copyright Aleksey Gurtovoy 2002
(c) Copyright Aleksey Gurtovoy 2003
(c) Copyright Beman Dawes 1995-2001
(c) Copyright Beman Dawes 1999-2003
(c) Copyright Daniel Frey 2002-2017
(c) Copyright Herve Bronnimann 2004
(c) Copyright Jeremy Siek 1999-2001
(c) Copyright Jessica Hamilton 2014
(c) Copyright Matthias Troyerk 2006
(c) Copyright Peter Dimov 2004-2005
(c) Copyright Reimar Doffinger 2018
(c) Copyright Thorsten Ottosen 2005
Copyright (c) 1988 by Theo Jurriens
Copyright (c) 1993-2019 C.B. Barber
Copyright (c) 2000, Frank Warmerdam
Copyright (c) 2001 Daniel C. Nuffer
Copyright (c) 2001-2003 Mac Murrett
Copyright (c) 2001-2005 Peter Dimov
Copyright (c) 2001-2008 Peter Dimov
Copyright (c) 2002, Frank Warmerdam
Copyright (c) 2003-2005 Peter Dimov
Copyright (c) 2004 Arkadiy Vertleyb
Copyright (c) 2005 Arkadiy Vertleyb
Copyright (c) 2005-2006 Dan Marsden
Copyright (c) 2005-2007 Dan Marsden
Copyright (c) 2006 Arkadiy Vertleyb
Copyright (c) 2006 Tobias Schwinger
Copyright (c) 2007 Tobias Schwinger
Copyright (c) 2012 Anthony Williams
Copyright (c) 2012 Lorenzo Caminiti
Copyright (c) 2013-2014 Damien Buhl
Copyright (c) 2016 K. Noel Belcourt
Copyright (c) 2019 T. Zachary Laine
Copyright (c) Benjamin Sobotta 2012
Copyright (c) Jeremy Siek 2001-2003
Copyright (c) T. Zachary Laine 2018
Copyright 2002 H Lohninger, TU Wein
Copyright 2003-2008 Joaquin M Lopez
Copyright 2003-2013 Joaquin M Lopez
Copyright 2003-2014 Joaquin M Lopez
Copyright 2003-2015 Joaquin M Lopez
Copyright 2003-2016 Joaquin M Lopez
Copyright 2003-2017 Joaquin M Lopez
Copyright 2003-2018 Joaquin M Lopez
Copyright 2003-2019 Joaquin M Lopez
Copyright 2003-2020 Joaquin M Lopez
Copyright 2006-2008 Joaquin M Lopez
Copyright 2006-2009 Joaquin M Lopez
Copyright 2006-2011 Joaquin M Lopez
Copyright 2006-2013 Joaquin M Lopez
Copyright 2006-2014 Joaquin M Lopez
Copyright 2006-2015 Joaquin M Lopez
Copyright 2006-2018 Joaquin M Lopez
Copyright 2006-2019 Joaquin M Lopez
Copyright 2006-2020 Joaquin M Lopez
Copyright 2008 Andreas Huber Doenni
Copyright 2008-2009 Frank Mori Hess
Copyright 2008-2010 Gordon Woodhull
Copyright 2011-2012 Steven Watanabe
Copyright 2012-2013 Steven Watanabe
Copyright 2012-2020 Antony Polukhin
Copyright 2013 University of Warsaw
Copyright 2013-2020 Antony Polukhin
Copyright 2015-2018 Andrey Semashev
Copyright 2015-2019 Antony Polukhin
Copyright 2015-2020 Antony Polukhin
Copyright 2016-2017 Joaquin M Lopez
Copyright 2016-2018 Andrey Semashev
Copyright 2016-2018 Joaquin M Lopez
Copyright 2016-2019 Antony Polukhin
Copyright 2016-2019 Joaquin M Lopez
Copyright 2016-2020 Joaquin M Lopez
Copyright 2017, NVIDIA CORPORATION.
Copyright 2017-2018 Joaquin M Lopez
Copyright 2018-2019 Antony Polukhin
Copyright 2019-2020 Antony Polukhin
Copyright Eric Niebler 2013-present
Copyright Frank Mori Hess 2007,2009
Copyright Frank Mori Hess 2007-2008
Copyright Frank Mori Hess 2007-2009
Copyright Frank Mori Hess 2007-2010
Copyright John R. Bandela 2000-2002
Copyright Kohei Takahashi 2012-2014
Copyright Paul A. Bristow 2006-2011
Copyright Shunsuke Sogame 2005-2006
Copyright Steven Watanabe 2009-2011
Copyright Steven Watanabe 2010-2011
(c) Copyright 2002, 2003 Beman Dawes
(c) Copyright 2002-4 Pavel Vozenilek
(c) Copyright 2016 Ashish Sadanandan
(c) Copyright Eric Niebler 2004-2005
(c) Copyright Gennadiy Rozental 2001
(c) Copyright Hubert Holin 2003-2005
(c) Copyright Jeremiah Willcock 2004
(c) Copyright John Maddock 2005-2006
(c) Copyright Jonathan Turkanis 2003
(c) Copyright Jonathan Turkanis 2004
(c) Copyright Markus Schoepflin 2005
(c) Copyright Markus Schoepflin 2007
(c) Copyright Michael Glassford 2004
(c) Copyright Peter Dimov 2001, 2002
(c) Copyright Rani Sharoni 2003-2005
(c) Copyright Thomas Claveirole 2010
(c) Copyright Yuriy Krasnoschek 2009
Copyright (c) 1998-2002 John Maddock
Copyright (c) 1998-2004 John Maddock
Copyright (c) 1998-2005 John Maddock
Copyright (c) 1998-2009 John Maddock
Copyright (c) 1999-2003 Jaakko Jarvi
Copyright (c) 2001 Alexander Peslyak
Copyright (c) 2001, 2002 Peter Dimov
Copyright (c) 2001, Daniel C. Nuffer
Copyright (c) 2001-2003 John Maddock
Copyright (c) 2002, 2003 Peter Dimov
Copyright (c) 2002-2003 Martin Wille
Copyright (c) 2003 Gerald I. Evenden
Copyright (c) 2003-2005 John Maddock
Copyright (c) 2004 Gerald I. Evenden
Copyright (c) 2005 Matthew Calabrese
Copyright (c) 2005-2008 Daniel James
Copyright (c) 2005-2009 Jongsoo Park
Copyright (c) 2005-2011 Daniel James
Copyright (c) 2005-2016 Daniel James
Copyright (c) 2007 Cybozu Labs, Inc.
Copyright (c) 2007 Marcin Kalicinski
Copyright (c) 2007, 2008 Peter Dimov
Copyright (c) 2007, 2013 Peter Dimov
Copyright (c) 2007, 2014 Peter Dimov
Copyright (c) 2007, Tobias Schwinger
Copyright (c) 2008 Gerald I. Evenden
Copyright (c) 2008, 2009 Peter Dimov
Copyright (c) 2008, 2011 Peter Dimov
Copyright (c) 2008, 2018 Peter Dimov
Copyright (c) 2008-2011 Daniel James
Copyright (c) 2008-2016 Daniel James
Copyright (c) 2009, 2015 Peter Dimov
Copyright (c) 2010-2011 David Bellot
Copyright (c) 2011-2013 Andrew Hundt
Copyright (c) 2013 Tim Blechmann ARM
Copyright (c) 2015-2019 Vinnie Falco
Copyright (c) 2016-2019 Damian Jarek
Copyright (c) 2016-2019 Vinnie Falco
Copyright (c) 2017 James E. King III
Copyright (c) 2018 James E. King III
Copyright (c) 2020 Michael Feldmeier
Copyright (c) Christof Meerwald 2003
Copyright (c) Damian Eads, 2007-2008
Copyright (c) Intel Corporation 2008
Copyright 1999-2003 Aleksey Gurtovoy
Copyright 2011, 2012 Paul A. Bristow
Copyright 2011-2013 Thorsten Ottosen
Copyright 2013 Christopher Kormanyos
Copyright 2013, 2017 Andrey Semashev
Copyright 2013, 2017-2018 Cray, Inc.
Copyright 2014 Christopher Kormanyos
Copyright 2015, 2017 Andrey Semashev
Copyright 2015, 2020 Andrey Semashev
Copyright 2016, 2017 Andrey Semashev
Copyright 2018, 2019 Andrey Semashev
Copyright Aleksey Gurtovoy 2000-2002
Copyright Aleksey Gurtovoy 2000-2003
Copyright Aleksey Gurtovoy 2000-2004
Copyright Aleksey Gurtovoy 2000-2006
Copyright Aleksey Gurtovoy 2000-2008
Copyright Aleksey Gurtovoy 2000-2009
Copyright Aleksey Gurtovoy 2000-2010
Copyright Aleksey Gurtovoy 2001-2004
Copyright Aleksey Gurtovoy 2001-2006
Copyright Aleksey Gurtovoy 2001-2007
Copyright Aleksey Gurtovoy 2001-2008
Copyright Aleksey Gurtovoy 2002-2004
Copyright Aleksey Gurtovoy 2002-2006
Copyright Aleksey Gurtovoy 2003-2004
Copyright Aleksey Gurtovoy 2003-2007
Copyright Andrii Sydorchuk 2010-2012
Copyright Antony Polukhin, 2011-2020
Copyright Antony Polukhin, 2013-2014
Copyright Antony Polukhin, 2013-2020
Copyright Antony Polukhin, 2016-2019
Copyright Antony Polukhin, 2016-2020
Copyright Christopher Kormanyos 2013
Copyright Christopher Kormanyos 2014
Copyright Matthew Pulver 2018 - 2019
Copyright Paul A. Bristow 2006, 2007
Copyright Paul A. Bristow 2007, 2009
Copyright Paul A. Bristow 2007, 2010
Copyright Paul A. Bristow 2007, 2012
Copyright Paul A. Bristow 2008, 2009
Copyright Paul A. Bristow 2008, 2010
Copyright Paul A. Bristow 2008, 2014
Copyright Paul A. Bristow 2009, 2011
Copyright Paul A. Bristow 2011, 2012
Copyright Steven J. Ross 2001 - 2009
Copyright Steven J. Ross 2001 - 2014
Copyright Thorsten Ottosen 2003-2004
Copyright Thorsten Ottosen 2003-2005
Copyright Thorsten Ottosen 2003-2006
Copyright Thorsten Ottosen 2003-2007
Copyright Thorsten Ottosen 2003-2008
copyright 2004 Brian Ravnsgaard Riis
(c) Copyright 2005-7 Anthony Williams
(c) Copyright 2005-8 Anthony Williams
(c) Copyright 2006-7 Anthony Williams
(c) Copyright 2006-8 Anthony Williams
(c) Copyright 2007-2009 Andrew Sutton
(c) Copyright 2007-8 Anthony Williams
(c) Copyright 2007-9 Anthony Williams
(c) Copyright 2008-9 Anthony Williams
(c) Copyright 2009-2011 Frederic Bron
(c) Copyright Beman Dawes 2001 - 2003
(c) Copyright Beman Dawes 2002 - 2003
(c) Copyright Darin Adler 2001 - 2002
(c) Copyright Daryle Walker 2000-2001
(c) Copyright Daryle Walker 2001-2002
(c) Copyright Edward Diener 2011,2012
(c) Copyright Edward Diener 2011,2013
(c) Copyright Edward Diener 2011,2014
(c) Copyright Edward Diener 2011-2015
(c) Copyright Edward Diener 2011-2020
(c) Copyright Edward Diener 2012,2013
(c) Copyright Edward Diener 2014,2019
(c) Copyright Eric Friedman 2002-2003
(c) Copyright Ion Gaztanaga 2004-2015
(c) Copyright Ion Gaztanaga 2005-2012
(c) Copyright Ion Gaztanaga 2005-2013
(c) Copyright Ion Gaztanaga 2005-2014
(c) Copyright Ion Gaztanaga 2005-2015
(c) Copyright Ion Gaztanaga 2005-2016
(c) Copyright Ion Gaztanaga 2006-2012
(c) Copyright Ion Gaztanaga 2006-2013
(c) Copyright Ion Gaztanaga 2006-2014
(c) Copyright Ion Gaztanaga 2006-2015
(c) Copyright Ion Gaztanaga 2007-2012
(c) Copyright Ion Gaztanaga 2007-2013
(c) Copyright Ion Gaztanaga 2007-2014
(c) Copyright Ion Gaztanaga 2008-2012
(c) Copyright Ion Gaztanaga 2008-2013
(c) Copyright Ion Gaztanaga 2008-2015
(c) Copyright Ion Gaztanaga 2009-2012
(c) Copyright Ion Gaztanaga 2009-2013
(c) Copyright Ion Gaztanaga 2010-2012
(c) Copyright Ion Gaztanaga 2010-2013
(c) Copyright Ion Gaztanaga 2010-2016
(c) Copyright Ion Gaztanaga 2011-2012
(c) Copyright Ion Gaztanaga 2011-2013
(c) Copyright Ion Gaztanaga 2011-2014
(c) Copyright Ion Gaztanaga 2012-2012
(c) Copyright Ion Gaztanaga 2012-2013
(c) Copyright Ion Gaztanaga 2012-2015
(c) Copyright Ion Gaztanaga 2012-2016
(c) Copyright Ion Gaztanaga 2013-2013
(c) Copyright Ion Gaztanaga 2013-2014
(c) Copyright Ion Gaztanaga 2014-2014
(c) Copyright Ion Gaztanaga 2014-2015
(c) Copyright Ion Gaztanaga 2014-2017
(c) Copyright Ion Gaztanaga 2015-2015
(c) Copyright Ion Gaztanaga 2015-2016
(c) Copyright Ion Gaztanaga 2015-2017
(c) Copyright Ion Gaztanaga 2016-2016
(c) Copyright Ion Gaztanaga 2017-2017
(c) Copyright Ion Gaztanaga 2017-2018
(c) Copyright Ion Gaztanaga 2018-2018
(c) Copyright Ion Gaztanaga 2019-2020
(c) Copyright Jens Maurer 2001 - 2002
(c) Copyright Jens Maurer 2001 - 2003
(c) Copyright Jens Maurer 2002 - 2003
(c) Copyright John Maddock 2006, 2015
(c) Copyright Toon Knapen 2001 - 2003
Copyright (c) 2001-2003 Daniel Nuffer
Copyright (c) 2002 Raghavendra Satish
Copyright (c) 2002-2003 Eric Friedman
Copyright (c) 2003-2004 Gennaro Prota
Copyright (c) 2004 Kristopher Beevers
Copyright (c) 2005, 2014 Eric Niebler
Copyright (c) 2005-2006 Joao Abecasis
Copyright (c) 2006, Stephan Diederich
Copyright (c) 2007 - Sebastien Fabbro
Copyright (c) 2007, 2008, Damian Eads
Copyright (c) 2007, 2013 John Maddock
Copyright (c) 2007-8 Anthony Williams
Copyright (c) 2007-9 Anthony Williams
Copyright (c) 2008-2011 Bruno Lalande
Copyright (c) 2008-2012 Bruno Lalande
Copyright (c) 2008-2013 Bruno Lalande
Copyright (c) 2008-2013 Tim Blechmann
Copyright (c) 2008-2014 Bruno Lalande
Copyright (c) 2008-2015 Bruno Lalande
Copyright (c) 2008-2016 Tim Blechmann
Copyright (c) 2008-2017 Bruno Lalande
Copyright (c) 2009-2011 Artyom Beilis
Copyright (c) 2009-2013 Tim Blechmann
Copyright (c) 2010-2011 Bryce Lelbach
Copyright (c) 2010-2011 Thomas Heller
Copyright (c) 2010-2011 Tim Blechmann
Copyright (c) 2011 Jan Frederick Eick
Copyright (c) 2011 Paul A. Bristow To
Copyright (c) 2011-2012 Bruno Lalande
Copyright (c) 2012-2014 Bruno Lalande
Copyright (c) 2013-2014 Agustin Berge
Copyright (c) 2013-2014 Ion Gaztanaga
Copyright (c) 2014 Mathjax Consortium
Copyright (c) 2014-2015 Bruno Lalande
Copyright (c) 2014-2015 John Fletcher
Copyright (c) 2015-2017 Martin Hensel
Copyright (c) 2016 2017 Felix Lenders
Copyright (c) 2019 Max-Planck-Society
Copyright (c) Marshall Clow 2008-2012
Copyright (c) Marshall Clow 2010-2012
Copyright (c) Marshall Clow 2011-2012
Copyright (c) Marshall Clow 2012-2012
Copyright (c) Marshall Clow 2012-2015
Copyright 2007-2008 Christian Henning
Copyright 2016 Klemens D. Morgenstern
Copyright 2017 Valentin Noah Hartmann
Copyright Andrey Semashev 2007 - 2013
Copyright Andrey Semashev 2007 - 2014
Copyright Andrey Semashev 2007 - 2015
Copyright Andrey Semashev 2007 - 2016
Copyright Andrey Semashev 2018 - 2020
Copyright Beman Dawes 1994-2007, 2011
Copyright Beman Dawes 2002-2005, 2009
copyright Gonzalo Brito Gadeschi 2015
(c) Copyright 2007-10 Anthony Williams
(c) Copyright 2008-10 Anthony Williams
(c) Copyright Benedek Thaler 2015-2016
(c) Copyright Daryle Walker 2001, 2006
(c) Copyright Guillaume Melquiond 2003
(c) Copyright Howard Hinnant 2007-2010
(c) Copyright John Maddock 2001 - 2002
(c) Copyright John Maddock 2001 - 2003
(c) Copyright John Maddock 2002 - 2003
(c) Copyright Nicolai M. Josuttis 2001
(c) Copyright Olaf Krzikalla 2004-2006
(c) Copyright Vicente J. Botet Escriba
(c) Rasmus Munk Larsen, Stanford, 2004
Copyright (c) 1998-2003 Joel de Guzman
Copyright (c) 1998-2008 Joel de Guzman
Copyright (c) 2001-2002 Joel de Guzman
Copyright (c) 2001-2003 Hartmut Kaiser
Copyright (c) 2001-2003 Joel de Guzman
Copyright (c) 2001-2007 Hartmut Kaiser
Copyright (c) 2001-2007 Joel de Guzman
Copyright (c) 2001-2008 Hartmut Kaiser
Copyright (c) 2001-2008 Joel de Guzman
Copyright (c) 2001-2009 Joel de Guzman
Copyright (c) 2001-2010 Hartmut Kaiser
Copyright (c) 2001-2010 Joel de Guzman
Copyright (c) 2001-2011 Hartmut Kaiser
Copyright (c) 2001-2011 Joel de Guzman
Copyright (c) 2001-2011 Thomas Bernard
Copyright (c) 2001-2012 Hartmut Kaiser
Copyright (c) 2001-2012 Joel de Guzman
Copyright (c) 2001-2013 Hartmut Kaiser
Copyright (c) 2001-2013 Joel de Guzman
Copyright (c) 2001-2014 Joel de Guzman
Copyright (c) 2001-2015 Joel de Guzman
Copyright (c) 2001-2019 Joel de Guzman
Copyright (c) 2002-2003 David Abrahams
Copyright (c) 2002-2003 Hartmut Kaiser
Copyright (c) 2002-2003 Joel de Guzman
Copyright (c) 2002-2006 Hartmut Kaiser
Copyright (c) 2004 Jonathan Brandmeyer
Copyright (c) 2005-2006 Alain Miniussi
Copyright (c) 2005-2006 Douglas Gregor
Copyright (c) 2005-2008 Hartmut Kaiser
Copyright (c) 2005-2010 Joel de Guzman
Copyright (c) 2005-2011 Joel de Guzman
Copyright (c) 2005-2012 Joel de Guzman
Copyright (c) 2005-2013 Joel de Guzman
Copyright (c) 2007-2011 Hartmut Kaiser
Copyright (c) 2008, 2016 Tim Blechmann
Copyright (c) 2008-2011 Hartmut Kaiser
Copyright (c) 2009 Christopher Schmidt
Copyright (c) 2009, 2011 Helge Bahmann
Copyright (c) 2009, 2016 Tim Blechmann
Copyright (c) 2009-2010 Hartmut Kaiser
Copyright (c) 2009-2020 Vladimir Batov
Copyright (c) 2010 Christopher Schmidt
Copyright (c) 2011, 2016 Tim Blechmann
Copyright (c) 2011-2012 ! Brandon Kohn
Copyright (c) 2011-2012 Thomas Bernard
Copyright (c) 2012, Jaydeep P. Bardhan
Copyright (c) 2012, Matthew G. Knepley
Copyright (c) 2014 Riccardo Marcangelo
Copyright (c) 2014, Janani Padmanabhan
Copyright (c) 2015 Andrzej Krzemienski
Copyright (c) 2016 Andrzej Krzemienski
Copyright (c) 2016-2019 Viktor Kirilov
Copyright (c) 2017 Andrzej Krzemienski
Copyright (c) 2020 Krystian Stasiowski
Copyright (c) 2022 Two Blue Cubes Ltd.
Copyright (c) Christopher Diggins 2005
Copyright 2002, 2009, 2014 Peter Dimov
Copyright 2004-2005 by Enthought, Inc.
Copyright 2007 University of Karlsruhe
Copyright 2015, 2017, 2019 Peter Dimov
Copyright 2016, 2018, 2019 Peter Dimov
Copyright Alexander Nasonov, 2006-2010
Copyright Beman Dawes 1994, 2006, 2008
Copyright Beman Dawes 2003, 2006, 2008
Copyright Beman Dawes 2003, 2006, 2010
Copyright Beman Dawes 2003, 2006, 2011
Copyright Beman Dawes 2010, 2011, 2014
Copyright John Maddock 2005-2006, 2011
Copyright John Maddock 2006-7, 2013-14
Copyright Peter Dimov 2017, 2018, 2020
copyright 2008- s, The SciPy community
(c) Copyright 2005-2006 Matthias Troyer
(c) Copyright 2005-2007 Matthias Troyer
(c) Copyright Boris Gubenko 2006 - 2007
(c) Copyright Gennaro Prota 2003 - 2004
(c) Copyright Paul Mensonides 2002-2011
Copyright (c) 1989-2004 Johannes Braams
Copyright (c) 1994 by Xerox Corporation
Copyright (c) 1996-2008 Rice University
Copyright (c) 1998-2000 Dr John Maddock
Copyright (c) 2000, 2001 Stephen Cleary
Copyright (c) 2001-2009, Hartmut Kaiser
Copyright (c) 2005, 2006 Douglas Gregor
Copyright (c) 2007-2008 Steven Watanabe
Copyright (c) 2007-2009 Steven Watanabe
Copyright (c) 2007-2010 Steven Watanabe
Copyright (c) 2008-2009 Frank Mori Hess
Copyright (c) 2009-2010, Marco Guazzone
Copyright (c) 2009-2012, Marco Guazzone
Copyright (c) 2010 Thomas P. Robitaille
Copyright (c) 2011-2015 Akira Takahashi
Copyright (c) 2011-2020 Antony Polukhin
Copyright (c) 2012 Pieter Bastiaan Ober
Copyright (c) 2012-2014 Kohei Takahashi
Copyright (c) 2012-2020 Antony Polukhin
Copyright (c) 2013-2020 Antony Polukhin
Copyright (c) 2014 Pieter Bastiaan Ober
Copyright (c) 2014, Andrzej Krzemienski
Copyright (c) 2014,2018 Kohei Takahashi
Copyright (c) 2014-2015 Kohei Takahashi
Copyright (c) 2014-2020 Andrey Semashev
Copyright (c) 2014-2020 Antony Polukhin
Copyright (c) 2015-2020 Antony Polukhin
Copyright (c) 2016-2020 Antony Polukhin
Copyright (c) 2018-2020 Antony Polukhin
Copyright (c) 2019-2020 Alexander Grund
Copyright (c) 2019-2020 Antony Polukhin
Copyright 2000 University of Notre Dame
Copyright 2001 University of Notre Dame
Copyright 2002-2003 Guillaume Melquiond
Copyright 2009 Vicente J. Botet Escriba
Copyright 2010 Vicente J. Botet Escriba
Copyright 2011 Vicente J. Botet Escriba
Copyright 2012 Vicente J. Botet Escriba
Copyright 2019-20 Christopher Kormanyos
Copyright Christopher Kormanyos 2013-14
Copyright Paul A. Bristow 2007, 2013-14
Copyright Ralf W. Grosse-Kunstleve 2006
Copyright Vicente J. Botet Escriba 2009
Copyright Vicente J. Botet Escriba 2010
Copyright Vicente J. Botet Escriba 2012
(c) Copyright 2007-2010 Anthony Williams
(c) Copyright 2009-2012 Anthony Williams
(c) Copyright 2013, 2020 Andrey Semashev
(c) Copyright Christopher Jefferson 2011
(c) Copyright David Abrahams 2001 - 2002
(c) Copyright David Abrahams 2002 - 2003
(c) Copyright Jeremy William Murphy 2015
(c) Copyright Jeremy William Murphy 2016
(c) Copyright Microsoft Corporation 2014
(c) Copyright R.W. Grosse-Kunstleve 2002
(c) Copyright Thorsten Ottosen 2002-2003
Copyright (arg) 2001-2014 Joel de Guzman
Copyright (c) 2001, 2002 Enthought, Inc.
Copyright (c) 2001-2003 William E. Kempf
Copyright (c) 2003, 2007-14 Matteo Frigo
Copyright (c) 2003-2005 Peter J. Verveer
Copyright (c) 2004-2008 Rene Nyffenegger
Copyright (c) 2006-2007 Matias Capeletto
Copyright (c) 2006-2007 Tobias Schwinger
Copyright (c) 2007-2008 Tobias Schwinger
Copyright (c) 2008 Federico J. Fernandez
Copyright (c) 2008-2012 Simonson Lucanus
Copyright (c) 2008-2018 Lorenzo Caminiti
Copyright (c) 2008-2019 Lorenzo Caminiti
Copyright (c) 2009-2012 Lorenzo Caminiti
Copyright (c) 2010 Athanasios Iliopoulos
Copyright (c) 2011 Christopher Jefferson
Copyright (c) 2012-2012 Andrii Sydorchuk
Copyright (c) 2013 Christopher Kormanyos
Copyright (c) 2014, 2019 Andrey Semashev
Copyright (c) 2014, 2020 Andrey Semashev
Copyright (c) 2015 Agustin K-ballo Berge
Copyright (c) 2016-2018 T. Zachary Laine
Copyright (c) Microsoft Corporation 2014
Copyright 2001, 2004, 2011 Daryle Walker
Copyright 2002-2006 Andreas Huber Doenni
Copyright 2002-2007 Andreas Huber Doenni
Copyright 2002-2008 Andreas Huber Doenni
Copyright 2002-2010 Andreas Huber Doenni
Copyright 2002-2016 The SciPy Developers
Copyright 2005-2006 Andreas Huber Doenni
Copyright 2005-2008 Andreas Huber Doenni
Copyright 2010-2012, D. E. Shaw Research
Copyright 2012-2013 Andreas Angelopoulos
Copyright Gottfried Ganssauge 2003..2006
(c) Copyright 2003-2007 Jonathan Turkanis
(c) Copyright 2004-2007 Jonathan Turkanis
(c) Copyright 2005-2007 Jonathan Turkanis
(c) Copyright Jonathan Turkanis 2004-2005
(c) Copyright Samuli-Petrus Korhonen 2017
CNRS/Univ. Clermont II Copyright 2014 LRI
Copyright (c) 1999-2003 Jeremiah Willcock
Copyright (c) 2001 by Andrei Alexandrescu
Copyright (c) 2001-2009, 2012 Peter Dimov
Copyright (c) 2002 by Andrei Alexandrescu
Copyright (c) 2002-2006 Marcin Kalicinski
Copyright (c) 2002-2007 Marcin Kalicinski
Copyright (c) 2004, 2005 Arkadiy Vertleyb
Copyright (c) 2005-2022, NumPy Developers
Copyright (c) 2007-2009 Joachim Faulhaber
Copyright (c) 2007-2010 Joachim Faulhaber
Copyright (c) 2007-2011 Joachim Faulhaber
Copyright (c) 2007-2012 Joachim Faulhaber
Copyright (c) 2008-2009 Joachim Faulhaber
Copyright (c) 2008-2010 Joachim Faulhaber
Copyright (c) 2008-2011 Joachim Faulhaber
Copyright (c) 2008-2012 Joachim Faulhaber
Copyright (c) 2009-2009 Joachim Faulhaber
Copyright (c) 2009-2010 Joachim Faulhaber
Copyright (c) 2009-2011 Joachim Faulhaber
Copyright (c) 2010-2010 Joachim Faulhaber
Copyright (c) 2010-2011 Joachim Faulhaber
Copyright (c) 2011-2011 Joachim Faulhaber
Copyright (c) 2012 - 2014 Andrey Semashev
Copyright (c) 2013 - 2014 Andrey Semashev
Copyright (c) 2013 - 2020 Andrey Semashev
Copyright (c) 2014, Athanasios Iliopoulos
Copyright (c) 2016 Klemens D. Morgenstern
Copyright (c) 2017 - 2018 Andrey Semashev
Copyright (c) 2017 Klemens D. Morgenstern
Copyright (c) 2018 Klemens D. Morgenstern
Copyright (c) 2019 - 2020 Alexander Grund
Copyright (c) 2019 Klemens D. Morgenstern
Copyright 2006 Eric Niebler, Olivier Gygi
Copyright 2006 Michael van der Westhuizen
Copyright 2008 Adobe Systems Incorporated
Copyright Arno Schoedl & Neil Groves 2009
Copyright Kevlin Henney, 2000, 2001, 2002
copyright (c) 1995-2010 Geodan, Amsterdam
(c) Copyright 2011Vicente J. Botet Escriba
(c) Copyright Aleksey Gurtovoy 2002 - 2003
(c) Copyright Beman Dawes 2006, 2009, 2014
(c) Copyright Edward Diener 2011,2012,2013
(c) Copyright Edward Diener 2011,2012,2019
(c) Copyright Edward Diener 2011-2015,2019
(c) Copyright Edward Diener 2012,2013,2019
(c) Copyright Peter Dimov 2001, 2002, 2003
Copyright (c) 1994 Hewlett-Packard Company
Copyright (c) 2000 Cadenza New Zealand Ltd
Copyright (c) 2001, 2002, 2003 Peter Dimov
Copyright (c) 2001, 2002, 2012 Peter Dimov
Copyright (c) 2002, 2008, 2013 Peter Dimov
Copyright (c) 2002, 2009, 2014 Peter Dimov
Copyright (c) 2002, 2018, 2019 Peter Dimov
Copyright (c) 2003, 2006 Gerald I. Evenden
Copyright (c) 2005-2015, Michele Simionato
Copyright (c) 2006, 2009 Marcin Kalicinski
Copyright (c) 2006-2008 Alexander Chemeris
Copyright (c) 2007, 2008, 2012 Peter Dimov
Copyright (c) 2010-2019 Max-Planck-Society
Copyright (c) 2010-2020 Max-Planck-Society
Copyright (c) 2017, 2018 James E. King III
Copyright 1984, 1995 by Stephen L. Moshier
Copyright 1984, 1996 by Stephen L. Moshier
Copyright 2005 Daniel Egloff, Eric Niebler
Copyright 2005 Daniel Egloff, Olivier Gygi
Copyright 2005 Eric Niebler, Daniel Egloff
Copyright 2006 Daniel Egloff, Olivier Gygi
Copyright 2006 Olivier Gygi, Daniel Egloff
Copyright 2006, Eric Niebler, Olivier Gygi
Copyright 2010 Daniel Wallin, Eric Niebler
Copyright 2015-2018 Klemens D. Morgenstern
Copyright Nick Thompson, John Maddock 2020
Copyright Paul A. Bristow 2006, 2007, 2012
Copyright Paul A. Bristow 2006, 2012, 2017
Copyright Paul A. Bristow 2016, 2017, 2018
Portions Copyright (c) 2002 David Abrahams
(c) Copyright 2010 Vicente J. Botet Escriba
(c) Copyright 2011 Vicente J. Botet Escriba
(c) Copyright 2012 Vicente J. Botet Escriba
(c) Copyright 2013 Vicente J. Botet Escriba
(c) Copyright 2014 Vicente J. Botet Escriba
(c) Copyright Eric Ford & Hubert Holin 2001
(c) Copyright Eric Ford 2001 & Hubert Holin
(c) Copyright Markus Schoepflin 2002 - 2003
(c) Copyright Vicente J. Botet Escriba 2010
(c) Copyright Vicente J. Botet Escriba 2014
(c) Rasmus Munk Larsen, Stanford University
Copyright (c) 1993-2019 The Geometry Center
Copyright (c) 2003-2004, 2008 Gennaro Prota
Copyright (c) 2003-2006, 2008 Gennaro Prota
Copyright (c) 2009-2010 Christopher Schmidt
Copyright (c) 2009-2011 Christopher Schmidt
Copyright (c) 2010-2011 Christopher Schmidt
Copyright (c) 2011 Vicente J. Botet Escriba
Copyright (c) 2011-2013, 2016 Tim Blechmann
Copyright (c) 2012 Vicente J. Botet Escriba
Copyright (c) 2013 Vicente J. Botet Escriba
Copyright (c) 2014 Vicente J. Botet Escriba
Copyright (c) 2014-2016 Andrzej Krzemienski
Copyright (c) 2015 Vicente J. Botet Escriba
Copyright (c) 2015-2018 Andrzej Krzemienski
Copyright (c) 2017 Vicente J. Botet Escriba
Copyright (c) 2019-2020 Krystian Stasiowski
Copyright 1984 - 1994 by Stephen L. Moshier
Copyright 1985 by Stephen L. Moshier Direct
Copyright 2002 Brad King and Douglas Gregor
Copyright 2012 (c) Jeffrey Lee Hellrung, Jr
Copyright Christopher Kormanyos 2002 - 2011
Copyright Christopher Kormanyos 2002 - 2013
(c) Rasmus Munk Larsen, Stanford, 1999, 2004
Copyright (c) 2001-2011 - Scilab Enterprises
Copyright (c) 2002 Eric Friedman, Itay Maman
Copyright (c) 2002 Juan Carlos Arevalo-Baeza
Copyright (c) 2003 Eric Friedman, Itay Maman
Copyright (c) 2008, 2009, 2016 Tim Blechmann
Copyright (c) 2010 - Jordi Gutierrez Hermoso
Copyright (c) 2012 Barend Gehrels, Amsterdam
Copyright (c) 2013 Barend Gehrels, Amsterdam
Copyright (c) 2014 Barend Gehrels, Amsterdam
Copyright (c) 2014, 2015 Andrzej Krzemienski
Copyright (c) 2014,2015,2018 Kohei Takahashi
Copyright (c) 2015 Barend Gehrels, Amsterdam
Copyright (c) 2017 Barend Gehrels, Amsterdam
Copyright (c) 2019 Barend Gehrels, Amsterdam
Copyright (c) 2020 Barend Gehrels, Amsterdam
Copyright 1997-2001 University of Notre Dame
Copyright 2009-2010 Vicente J. Botet Escriba
Copyright 2009-2011 Vicente J. Botet Escriba
Copyright 2009-2012 Vicente J. Botet Escriba
Copyright Beman Dawes and Daryle Walker 1999
Copyright Daniel Wallin, David Abrahams 2005
Copyright Daniel Wallin, David Abrahams 2010
Copyright David Abrahams, Daniel Wallin 2003
Copyright David Abrahams, Daniel Wallin 2005
Copyright Thorsten Ottosen, Neil Groves 2006
Copyright Vicente J. Botet Escriba 2009-2011
(c) Copyright Guillaume Melquiond 2002 - 2003
(c) Copyright Joaquin M Lopez Munoz 2006-2013
Copyright (c) 2011-2014, The OpenBLAS Project
Copyright (c) 2013-2014, 2020 Andrey Semashev
Copyright (c) 2014 - 2018 Andrzej Krzemienski
Copyright (c) 2014-2018, 2020 Andrey Semashev
Copyright (c) 2015 - 2017 Andrzej Krzemienski
Copyright 2000 Jeremy Siek (jsiek@lsc.nd.edu)
Copyright 2005 Eric Niebler, Michael Gauckler
Copyright 2005 Trustees of Indiana University
Copyright 2006 Trustees of Indiana University
Copyright 2009 Trustees of Indiana University
Copyright David Abrahams and Jeremy Siek 2003
Copyright John Maddock 2006, 2007, 2012, 2014
Copyright Peter Dimov and David Abrahams 2002
Copyright (c) 2004 CrystalClear Software, Inc.
Copyright (c) 2005 CrystalClear Software, Inc.
Copyright (c) 2006 CrystalClear Software, Inc.
Copyright (c) 2006, 2007 Julio M. Merino Vidal
Copyright (c) 2009-2017 The MathJax Consortium
Copyright (c) 2010-2017 The MathJax Consortium
Copyright (c) 2011 Jeff Flinn, Boris Schaeling
Copyright (c) 2011-2015 The MathJax Consortium
Copyright (c) 2011-2017 The MathJax Consortium
Copyright (c) 2012 Mateusz Loskot, London, UK.
Copyright (c) 2013 Mateusz Loskot, London, UK.
Copyright (c) 2013-2017 The MathJax Consortium
Copyright (c) 2014 Mateusz Loskot, London, UK.
Copyright (c) 2014-2017 The MathJax Consortium
Copyright (c) 2015-2017 The MathJax Consortium
Copyright (c) 2016 Modified Work Barrett Adair
Copyright (c) 2016-2017 The MathJax Consortium
Copyright 2001, 2003, 2004, 2012 Daryle Walker
Copyright 2005-2007 Adobe Systems Incorporated
Copyright 2011 Garmin Ltd. or its subsidiaries
Copyright 2012 Chung-Lin Wen, Davide Anastasia
Copyright J.S. Roy (js@jeannot.org), 2002-2005
(c) Copyright Daniel Frey and Robert Ramey 2009
Copyright (c) 1995 Maarten Hilferink, Amsterdam
Copyright (c) 2002 Brad King and Douglas Gregor
Copyright (c) 2003 Gunter Winkler, Joerg Walter
Copyright (c) 2003-2011 Christopher M. Kohlhoff
Copyright (c) 2003-2020 Christopher M. Kohlhoff
Copyright (c) 2005 Arkadiy Vertleyb, Peder Holt
Copyright (c) 2005 Voipster / Indrek dot Juhani
Copyright (c) 2005-2020 Christopher M. Kohlhoff
Copyright (c) 2006-2009, 2012 Alexander Nasonov
Copyright (c) 2009, Pauli Virtanen <pav@iki.fi>
Copyright (c) 2012 - 2014, 2017 Andrey Semashev
Copyright (c) 2013 - 2018, 2020 Andrey Semashev
Copyright (c) 2013 Tim Blechmann Linux-specific
Copyright (c) 2015 Oracle and/or its affiliates
Copyright (c) 2015, Pauli Virtanen <pav@iki.fi>
Copyright (c) 2016 Oracle and/or its affiliates
Copyright (c) 2017 Oracle and/or its affiliates
Copyright (c) 2018 Oracle and/or its affiliates
Copyright (c) 2019 Oracle and/or its affiliates
Copyright (c) 2020 Oracle and/or its affiliates
Copyright 2002 Rensselaer Polytechnic Institute
Copyright 2004-9 Trustees of Indiana University
Copyright 2010 Fabien Castan, Christian Henning
Copyright 2010 Gaetano Mendola, 2011 Simon West
copyright (c) 2014 Oracle and/or its affiliates
copyright (c) 2015 Oracle and/or its affiliates
copyright (c) 2016 Oracle and/or its affiliates
copyright (c) 2017 Oracle and/or its affiliates
copyright (c) 2018 Oracle and/or its affiliates
copyright (c) 2019 Oracle and/or its affiliates
copyright (c) 2020 Oracle and/or its affiliates
(c) Copyright 2004 Robert Ramey and Martin Ecker
(c) Copyright 2009-2012 Vicente J. Botet Escriba
(c) Copyright 2010-2011 Vicente J. Botet Escriba
(c) Copyright 2011-2012 Vicente J. Botet Escriba
(c) Copyright 2011-2013 Vicente J. Botet Escriba
(c) Copyright 2011-2015 Vicente J. Botet Escriba
(c) Copyright 2013,2014 Vicente J. Botet Escriba
(c) Copyright 2013,2015 Vicente J. Botet Escriba
(c) Copyright David Abrahams, Vicente Botet 2009
(c) Copyright Eric Jourdanneau, Joel Falcou 2010
(c) Copyright John Maddock and Steve Cleary 2000
(c) Copyright Vicente J. Botet Escriba 2013-2014
(c) Copyright Vicente J. Botet Escriba 2013-2017
(c) Copyright Vicente J. Botet Escriba 2014-2015
CNRS/Univ. Clermont II Copyright 2009 - 2011 LRI
Copyright (c) 2001, Thomas Flemming, tf@ttqv.com
Copyright (c) 2003-2004 Jeremy B. Maitin-Shepard
Copyright (c) 2008 Ilya Sokolov, Boris Schaeling
Copyright (c) 2009, Spirent Communications, Inc.
Copyright (c) 2010 Eric Jourdanneau, Joel Falcou
Copyright (c) 2010 Felipe Tanus, Boris Schaeling
Copyright (c) 2010 Nuovation System Designs, LLC
Copyright (c) 2011-2012 Vicente J. Botet Escriba
Copyright (c) 2011-2013 Vicente J. Botet Escriba
Copyright (c) 2012-2013 Vicente J. Botet Escriba
Copyright (c) 2013 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2013 John Maddock, Antony Polukhin
Copyright (c) 2013,2014 Vicente J. Botet Escriba
Copyright (c) 2013-2014 Vicente J. Botet Escriba
Copyright (c) 2014 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2014, 2015, 2016, 2017 Jarryd Beck
Copyright (c) 2014, Oracle and/or its affiliates
Copyright (c) 2014-2015 Vicente J. Botet Escriba
Copyright (c) 2014-2017 Vicente J. Botet Escriba
Copyright (c) 2015, Oracle and/or its affiliates
Copyright (c) 2016, Oracle and/or its affiliates
Copyright (c) 2017 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2017, Oracle and/or its affiliates
Copyright (c) 2018 Adam Butcher, Antony Polukhin
Copyright (c) 2018 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2018, Oracle and/or its affiliates
Copyright (c) 2019, Oracle and/or its affiliates
Copyright (c) 2020, Oracle and/or its affiliates
Copyright 1984, 1987, 1995 by Stephen L. Moshier
Copyright 1984, 1987, 2000 by Stephen L. Moshier
Copyright 1984, 1995, 2000 by Stephen L. Moshier
Copyright 1985, 1987, 2000 by Stephen L. Moshier
Copyright 2003 Guillaume Melquiond, Sylvain Pion
Copyright Justinas Vygintas Daugmaudis 2010-2018
Copyright Paul A. Bristow 2006, 2007, 2009, 2010
Copyright Paul A. Bristow 2007, 2009, 2010, 2012
Copyright Paul A. Bristow 2007, 2010, 2012, 2014
copyright (c) 2013, Oracle and/or its affiliates
copyright (c) 2014, Oracle and/or its affiliates
copyright (c) 2015, Oracle and/or its affiliates
copyright (c) 2016, Oracle and/or its affiliates
copyright (c) 2017, Oracle and/or its affiliates
copyright (c) 2018, Oracle and/or its affiliates
copyright (c) 2020, Oracle and/or its affiliates
(c) Rasmus Munk Larsen, Stanford University, 2000
(c) Rasmus Munk Larsen, Stanford University, 2004
Copyright (c) 2002-2003 Eric Friedman, Itay Maman
Copyright (c) 2006 Trustees of Indiana University
Copyright (c) 2007 Trustees of Indiana University
Copyright (c) 2007-2011 Barend Gehrels, Amsterdam
Copyright (c) 2007-2012 Barend Gehrels, Amsterdam
Copyright (c) 2007-2013 Barend Gehrels, Amsterdam
Copyright (c) 2007-2014 Barend Gehrels, Amsterdam
Copyright (c) 2007-2015 Barend Gehrels, Amsterdam
Copyright (c) 2007-2016 Barend Gehrels, Amsterdam
Copyright (c) 2007-2017 Barend Gehrels, Amsterdam
Copyright (c) 2007-2020 Barend Gehrels, Amsterdam
Copyright (c) 2008-2012 Barend Gehrels, Amsterdam
Copyright (c) 2008-2014 Barend Gehrels, Amsterdam
Copyright (c) 2008-2015 Barend Gehrels, Amsterdam
Copyright (c) 2009 Trustees of Indiana University
Copyright (c) 2009-2012 Barend Gehrels, Amsterdam
Copyright (c) 2009-2015 Barend Gehrels, Amsterdam
Copyright (c) 2010-2012 Barend Gehrels, Amsterdam
Copyright (c) 2011-2012 Barend Gehrels, Amsterdam
Copyright (c) 2011-2015 Barend Gehrels, Amsterdam
Copyright (c) 2012-2014 Barend Gehrels, Amsterdam
Copyright (c) 2012-2015 Barend Gehrels, Amsterdam
Copyright (c) 2012-2020 Barend Gehrels, Amsterdam
Copyright (c) 2014-2015 Barend Gehrels, Amsterdam
Copyright (c) 2015-2016 Barend Gehrels, Amsterdam
Copyright (c) 2015-2020 Barend Gehrels, Amsterdam
Copyright (c) 2017-2017 Barend Gehrels, Amsterdam
Copyright (c) 2018-2019 Barend Gehrels, Amsterdam
Copyright (c) 2019-2019 Barend Gehrels, Amsterdam
Copyright 1984, 1987 by Stephen L. Moshier Direct
Copyright 1984, 1991 by Stephen L. Moshier Direct
Copyright 1985, 1987 by Stephen L. Moshier Direct
Copyright 2002 The Trustees of Indiana University
Copyright 2003 The Trustees of Indiana University
Copyright 2004 The Trustees of Indiana University
Copyright 2005 Felix Hofling, Guillaume Melquiond
Copyright 2005 The Trustees of Indiana University
Copyright 2006 The Trustees of Indiana University
Copyright 2008 Christian Henning, Lubomir Bourdev
Copyright 2009 The Trustees of Indiana University
Copyright 2010 The Trustees of Indiana University
Copyright 2012 Kenneth Riddile, Christian Henning
Copyright 2012 The Trustees of Indiana University
Copyright Abel Sinkovics (abel@sinkovics.hu) 2010
Copyright Abel Sinkovics (abel@sinkovics.hu) 2011
Copyright Abel Sinkovics (abel@sinkovics.hu) 2012
Copyright Abel Sinkovics (abel@sinkovics.hu) 2013
Copyright Abel Sinkovics (abel@sinkovics.hu) 2014
Copyright Abel Sinkovics (abel@sinkovics.hu) 2015
Copyright Abel Sinkovics (abel@sinkovics.hu) 2016
Copyright Abel Sinkovics (abel@sinkovics.hu) 2017
Copyright Abel Sinkovics (abel@sinkovics.hu) 2018
(c) Copyright Dave Abrahams and Daryle Walker 2001
(c) Copyright Jeremy Siek and John R. Bandela 2001
(c) Copyright John Maddock & Thorsten Ottosen 2005
(c) Copyright Kevlin Henney and Dave Abrahams 1999
Copyright (c) 2000-2002 Joerg Walter, Mathias Koch
Copyright (c) 2000-2004 Joerg Walter, Mathias Koch
Copyright (c) 2001 Vladimir Prus <ghost@cs.msu.su>
Copyright (c) 2003-2008 Matthias Christian Schabel
Copyright (c) 2003-2009 Matthias Christian Schabel
Copyright (c) 2010 David Fong and Michael Saunders
Copyright (c) 2019 Dario Menendez, Banco Santander
Copyright 2005 David Abrahams and Aleksey Gurtovoy
Copyright 2012 Fernando Vilas 2010 Daniel Trebbien
Copyright 2014 Renato Tegon Forti, Antony Polukhin
Copyright 2018 Mateusz Loskot <mateusz@loskot.net>
Copyright Alexander Nasonov & Paul A. Bristow 2006
Copyright David Abrahams and Nikolay Mladenov 2003
Copyright (c) 2000 Gary Powell (powellg@amazon.com)
Copyright (c) 2001 Peter Dimov and Multi Media Ltd.
Copyright (c) 2001, 2002 Python Software Foundation
Copyright (c) 2001-2007 Hartmut Kaiser Revised 2007
Copyright (c) 2002 Peter Dimov and Multi Media Ltd.
Copyright (c) 2002,2003 CrystalClear Software, Inc.
Copyright (c) 2002-2004 CrystalClear Software, Inc.
Copyright (c) 2002-2005 CrystalClear Software, Inc.
Copyright (c) 2002-2020 CrystalClear Software, Inc.
Copyright (c) 2003-2004 CrystalClear Software, Inc.
Copyright (c) 2003-2005 CrystalClear Software, Inc.
Copyright (c) 2004-2005 CrystalClear Software, Inc.
Copyright (c) 2006, Systems Optimization Laboratory
Copyright (c) 2007, John Travers <jtravs@gmail.com>
Copyright (c) 2009-2011 Mateusz Loskot, London, UK.
Copyright (c) 2009-2012 Mateusz Loskot, London, UK.
Copyright (c) 2009-2013 Mateusz Loskot, London, UK.
Copyright (c) 2009-2014 Mateusz Loskot, London, UK.
Copyright (c) 2009-2015 Mateusz Loskot, London, UK.
Copyright (c) 2009-2017 Mateusz Loskot, London, UK.
Copyright (c) 2011-2012 Mateusz Loskot, London, UK.
Copyright (c) 2012-2014 Mateusz Loskot, London, UK.
Copyright (c) 2014-2015 Mateusz Loskot, London, UK.
Copyright (c) 2018 Adeel Ahmad, Islamabad, Pakistan
Copyright 2004, 2005 Trustees of Indiana University
Copyright 2004-5 The Trustees of Indiana University
Copyright 2012 Olivier Tournaire, Christian Henning
Copyright 2016 Klemens Morgenstern, Antony Polukhin
Copyright 2019 Miral Shah <miralshah2211@gmail.com>
Copyright David Abrahams 2002, Joel de Guzman, 2002
Copyright Thorsten Ottosen, Neil Groves 2006 - 2008
(c) Copyright 2005 Matthias Troyer and Dave Abrahams
(c) Copyright Greg Colvin and Beman Dawes 1998, 1999
Copyright (c) 1998-2003 by the University of Florida
Copyright (c) 2003, Fernando Luis Cacciola Carballal
Copyright (c) 2005, Fernando Luis Cacciola Carballal
Copyright (c) 2006 Xiaogang Zhang, 2015 John Maddock
Copyright (c) 2011, 2012 Jeff Flinn, Boris Schaeling
Copyright (c) 2013 Kyle Lutz <kyle.r.lutz@gmail.com>
Copyright (c) 2014 Samuel Debionne, Grenoble, France
Copyright (c) 2014-2016 Oracle and/or its affiliates
Copyright (c) 2014-2018 Oracle and/or its affiliates
Copyright (c) 2014-2020 Oracle and/or its affiliates
Copyright (c) 2015 Jakub Pola <jakub.pola@gmail.com>
Copyright (c) 2015 Jakub Szuppe <j.szuppe@gmail.com>
Copyright (c) 2015-2016 Oracle and/or its affiliates
Copyright (c) 2015-2018 Oracle and/or its affiliates
Copyright (c) 2015-2020 Oracle and/or its affiliates
Copyright (c) 2016 Jakub Szuppe <j.szuppe@gmail.com>
Copyright (c) 2016-2018 Oracle and/or its affiliates
Copyright (c) 2016-2019 Oracle and/or its affiliates
Copyright (c) 2016-2020 Oracle and/or its affiliates
Copyright (c) 2017-2018 Oracle and/or its affiliates
Copyright (c) 2017-2019 Oracle and/or its affiliates
Copyright (c) 2017-2020 Oracle and/or its affiliates
Copyright (c) 2018 Jakub Szuppe <j.szuppe@gmail.com>
Copyright (c) 2018, Cem Bassoy, cem.bassoy@gmail.com
Copyright (c) 2018-2019 Oracle and/or its affiliates
Copyright (c) 2018-2020 Oracle and/or its affiliates
Copyright (c) 2020 Caian Benedicto, Campinas, Brazil
Copyright 2000 John Maddock (john@johnmaddock.co.uk)
Copyright 2013 Christian Henning and Juan V. Puertos
Copyright 2015 Ontario Institute for Cancer Research
Copyright David Abrahams 2002, Nikolay Mladenov 2007
Copyright David Abrahams and Thomas Becker 2000-2006
Copyright Peter Dimov and Multi Media Ltd 2001, 2002
copyright (c) 2013-2017 Oracle and/or its affiliates
copyright (c) 2013-2018 Oracle and/or its affiliates
copyright (c) 2013-2019 Oracle and/or its affiliates
copyright (c) 2013-2020 Oracle and/or its affiliates
copyright (c) 2014-2015 Oracle and/or its affiliates
copyright (c) 2014-2017 Oracle and/or its affiliates
copyright (c) 2014-2018 Oracle and/or its affiliates
copyright (c) 2014-2019 Oracle and/or its affiliates
copyright (c) 2014-2020 Oracle and/or its affiliates
copyright (c) 2015-2016 Oracle and/or its affiliates
copyright (c) 2015-2017 Oracle and/or its affiliates
copyright (c) 2015-2019 Oracle and/or its affiliates
copyright (c) 2015-2020 Oracle and/or its affiliates
copyright (c) 2016-2018 Oracle and/or its affiliates
copyright (c) 2016-2020 Oracle and/or its affiliates
copyright (c) 2017-2018 Oracle and/or its affiliates
copyright (c) 2017-2020 Oracle and/or its affiliates
copyright (c) 2018-2020 Oracle and/or its affiliates
copyright (c) 2019-2020 Oracle and/or its affiliates
(c) Copyright 2002 Robert Ramey - http://www.rrsd.com
(c) Copyright 2004 Robert Ramey - http://www.rrsd.com
(c) Copyright 2005 Robert Ramey - http://www.rrsd.com
(c) Copyright 2007 Robert Ramey - http://www.rrsd.com
(c) Copyright 2008-2009,2012 Vicente J. Botet Escriba
(c) Copyright 2009 Robert Ramey - http://www.rrsd.com
(c) Copyright 2011,2012,2015 Vicente J. Botet Escriba
(c) Copyright 2011-2012,2015 Vicente J. Botet Escriba
(c) Copyright 2014 Robert Ramey - http://www.rrsd.com
(c) Copyright Vicente J. Botet Escriba 2008-2009,2012
Copyright (c) 2000 Gary Powell (gwpowell@hotmail.com)
Copyright (c) 2001 Jeremy Siek <jsiek@cs.indiana.edu>
Copyright (c) 2001-2002 Chuck Allison and Jeremy Siek
Copyright (c) 2002 Gary Powell (gwpowell@hotmail.com)
Copyright (c) 2002-2003 David Moore, William E. Kempf
Copyright (c) 2004 The Trustees of Indiana University
Copyright (c) 2006 The Trustees of Indiana University
Copyright (c) 2007 Douglas Gregor and Matthias Troyer
Copyright (c) 2007 The Trustees of Indiana University
Copyright (c) 2011-2013 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2011-2014 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2011-2015 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2011-2016 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2011-2017 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2011-2018 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2011-2019 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2012-2013 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2012-2015 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2012-2020 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2013-2014 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2013-2015 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2013-2017 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2014-2015 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2014-2015, Oracle and/or its affiliates
Copyright (c) 2014-2017 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2014-2017, Oracle and/or its affiliates
Copyright (c) 2014-2018 Adam Wulkiewicz, Lodz, Poland
Copyright (c) 2014-2018, Oracle and/or its affiliates
Copyright (c) 2014-2019, Oracle and/or its affiliates
Copyright (c) 2014-2020, Oracle and/or its affiliates
Copyright (c) 2015-2017, Oracle and/or its affiliates
Copyright (c) 2015-2018, Oracle and/or its affiliates
Copyright (c) 2015-2020, Oracle and/or its affiliates
Copyright (c) 2016, 2018 Oracle and/or its affiliates
Copyright (c) 2016-2017, Oracle and/or its affiliates
Copyright (c) 2016-2020, Oracle and/or its affiliates
Copyright (c) 2017, 2019 Oracle and/or its affiliates
Copyright (c) 2017-2018, Oracle and/or its affiliates
Copyright (c) 2017-2019, Oracle and/or its affiliates
Copyright (c) 2017-2020, Oracle and/or its affiliates
Copyright (c) 2018-2019, Oracle and/or its affiliates
Copyright (c) 2018-2020, Oracle and/or its affiliates
Copyright (c) 2019-2020, Oracle and/or its affiliates
Copyright (c) 2020 Digvijay Janartha, Hamirpur, India
copyright (c) 2013, 2014 Oracle and/or its affiliates
copyright (c) 2013-2014, Oracle and/or its affiliates
copyright (c) 2013-2015, Oracle and/or its affiliates
copyright (c) 2013-2017, Oracle and/or its affiliates
copyright (c) 2013-2018, Oracle and/or its affiliates
copyright (c) 2013-2019, Oracle and/or its affiliates
copyright (c) 2013-2020, Oracle and/or its affiliates
copyright (c) 2014-2017, Oracle and/or its affiliates
copyright (c) 2014-2018, Oracle and/or its affiliates
copyright (c) 2014-2019, Oracle and/or its affiliates
copyright (c) 2014-2020, Oracle and/or its affiliates
copyright (c) 2015-2016, Oracle and/or its affiliates
copyright (c) 2015-2017, Oracle and/or its affiliates
copyright (c) 2015-2018, Oracle and/or its affiliates
copyright (c) 2015-2019, Oracle and/or its affiliates
copyright (c) 2015-2020, Oracle and/or its affiliates
copyright (c) 2016-2019, Oracle and/or its affiliates
copyright (c) 2016-2020, Oracle and/or its affiliates
copyright (c) 2017, 2019 Oracle and/or its affiliates
copyright (c) 2017-2018, Oracle and/or its affiliates
copyright (c) 2017-2019, Oracle and/or its affiliates
copyright (c) 2017-2020, Oracle and/or its affiliates
copyright (c) 2018-2019, Oracle and/or its affiliates
copyright (c) 2018-2020, Oracle and/or its affiliates
(c) Copyright Beman Dawes and Ullrich Koethe 1995-2001
(c) Copyright David Abrahams 2001, Howard Hinnant 2001
(c) Copyright Hubert Holin and Daryle Walker 2001-2002
(c) Rasmus Munk Larsen, Stanford University, 2000,2004
Copyright (c) 2002-2017 Free Software Foundation, Inc.
Copyright (c) 2014, 2018, Oracle and/or its affiliates
Copyright (c) 2014, 2019, Oracle and/or its affiliates
Copyright (c) 2016 Wenzel Jakob <wenzel.jakob@epfl.ch>
Copyright (c) 2020 Richard Hodges (hodges.r@gmail.com)
Copyright (c) Jeremy Siek 2001, Marc Wintermantel 2002
Copyright 1984, 1987, 1988, 2000 by Stephen L. Moshier
Copyright 1984, 1987, 1989, 1995 by Stephen L. Moshier
Copyright 1984, 1987, 1989, 2000 by Stephen L. Moshier
Copyright 1984, 1987, 1992, 2000 by Stephen L. Moshier
Copyright 2004-2006 The Trustees of Indiana University
Copyright 2005-2009 The Trustees of Indiana University
Copyright 2007-2008 Andreas Pokorny, Christian Henning
Copyright 2007-2008 Christian Henning, Andreas Pokorny
Copyright 2007-2012 Christian Henning, Andreas Pokorny
Copyright 2007-2012 Christian Henning, Lubomir Bourdev
Copyright 2010-2012 Kenneth Riddile, Christian Henning
copyright (c) 2014, 2018, Oracle and/or its affiliates
copyright (c) 2014, 2019, Oracle and/or its affiliates
copyright (c) 2015, 2018, Oracle and/or its affiliates
copyright (c) 2017, 2019, Oracle and/or its affiliates
copyright (c) 2018, 2019, Oracle and/or its affiliates
(c) 2020 Niall Douglas <http://www.nedproductions.biz/>
(c) Copyright Boris Rasin and Antony Polukhin 2014-2019
(c) Copyright Dave Abrahams and Daniel Walker 1999-2003
(c) Copyright Robert Ramey 2003. Jonathan Turkanis 2004
(c) Rasmus Munk Larsen, Stanford University, 1999, 2004
(c) Rasmus Munk Larsen, Stanford University, 2000, 2004
Copyright (c) 1995, 2007-2015 Barend Gehrels, Amsterdam
Copyright (c) 1995-2013 Jean-loup Gailly and Mark Adler
Copyright (c) 2000 Gary Powell (gary.powell@sierra.com)
Copyright (c) 2001 Gary Powell (gary.powell@sierra.com)
Copyright (c) 2002 Lars Gullik Bjonnes <larsbj@lyx.org>
Copyright (c) 2011 Boris Schaeling (boris@highscore.de)
Copyright (c) 2014 Roshan <thisisroshansmail@gmail.com>
Copyright (c) 2015 Orson Peters <orsonpeters@gmail.com>
Copyright (c) 2021 Orson Peters <orsonpeters@gmail.com>
Copyright (c) Donald Stufft and individual contributors
Copyright 1984, 1987, 1988 by Stephen L. Moshier Direct
Copyright 1984, 1987, 1989 by Stephen L. Moshier Direct
Copyright 1984, 1987, 1993 by Stephen L. Moshier Direct
Copyright 1985, 1987, 1989 by Stephen L. Moshier Direct
Copyright 2004, 2005 The Trustees of Indiana University
Copyright 2014-2015 Renato Tegon Forti, Antony Polukhin
Copyright 2019 Pranam Lashkari <plashkari628@gmail.com>
(c) Copyright 2006 David Abrahams - http://www.boost.org
(c) Copyright Daryle Walker and Stephen Cleary 2001-2002
(c) Copyright Fernando Luis Cacciola Carballal 2000-2004
Copyright (c) 2001 Jaakko Jarvi (jaakko.jarvi@cs.utu.fi)
Copyright (c) 2001-2004 Peter Dimov and Multi Media Ltd.
Copyright (c) 2002 Jaakko Jarvi (jaakko.jarvi@cs.utu.fi)
Copyright (c) 2002,2003,2005 CrystalClear Software, Inc.
Copyright (c) 2002,2003,2020 CrystalClear Software, Inc.
Copyright (c) 2002-2003,2005 CrystalClear Software, Inc.
Copyright (c) 2012 Massachusetts Institute of Technology
Copyright (c) 2019 Vinnie Falco (vinnie.falco@gmail.com)
Copyright (c) 2020 Vinnie Falco (vinnie.falco@gmail.com)
Copyright 2008 CodeRage, LLC 2004-2007 Jonathan Turkanis
Copyright 2014 Marco Guazzone (marco.guazzone@gmail.com)
Copyright Abel Sinkovics (abel@sinkovics.hu) 2009 - 2010
Copyright Abel Sinkovics (abel@sinkovics.hu) 2009 - 2011
Copyright Abel Sinkovics (abel@sinkovics.hu) 2009 - 2012
Copyright Abel Sinkovics (abel@sinkovics.hu) 2010 - 2011
Copyright Abel Sinkovics (abel@sinkovics.hu) 2011 - 2012
Copyright Ralf W. Grosse-Kunstleve & David Abrahams 2006
(c) ACM, 2011. http://doi.acm.org/10.1145/1916461.1916469
(c) Copyright 2002-2008, Fernando Luis Cacciola Carballal
Copyright (c) 1999-2006 Cortex Software GmbH, Kantstrasse
Copyright (c) 2001, 2002 Peter Dimov and Multi Media Ltd.
Copyright (c) 2002, 2003 Peter Dimov and Multi Media Ltd.
Copyright (c) 2002,2003, 2007 CrystalClear Software, Inc.
Copyright (c) 2002,2003, 2020 CrystalClear Software, Inc.
Copyright (c) 2003, 2008 Fernando Luis Cacciola Carballal
Copyright (c) 2006-2013 The University of Colorado Denver
Copyright (c) 2007 Douglas Gregor <doug.gregor@gmail.com>
Copyright (c) 2009 Ben Hanson (http://www.benhanson.net/)
Copyright (c) 2013-2014 Kyle Lutz <kyle.r.lutz@gmail.com>
Copyright (c) 2013-2015 Kyle Lutz <kyle.r.lutz@gmail.com>
Copyright (c) 2014-2015 Samuel Debionne, Grenoble, France
Copyright (c) 2015 Francisco Jose Tapia fjtapia@gmail.com
Copyright (c) 2016 Francisco Jose Tapia fjtapia@gmail.com
Copyright (c) 2017 Francisco Jose Tapia fjtapia@gmail.com
Copyright (c) 2018 Alain Miniussi <alain.miniussi@oca.eu>
Copyright (c) 2018-2019, Cem Bassoy, cem.bassoy@gmail.com
Copyright (c) 2019 Mika Fischer (mika.fischer@zoopnet.de)
Copyright 1997, 1998, 1999, 2000 University of Notre Dame
Copyright 2002 Aleksey Gurtovoy (agurtovoy@meta-comm.com)
Copyright 2014 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2015 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2017 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2018 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2019 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2020 Glen Joseph Fernandes (glenjofe@gmail.com)
(c) Copyright 2002-2009 Robert Ramey - http://www.rrsd.com
(c) Copyright 2002-2014 Robert Ramey - http://www.rrsd.com
(c) Copyright 2002-2020 Robert Ramey - http://www.rrsd.com
(c) Copyright 2011-2012,2017-2018 Vicente J. Botet Escriba
Copyright (c) 1996 Silicon Graphics Computer Systems, Inc.
Copyright (c) 1998 Silicon Graphics Computer Systems, Inc.
Copyright (c) 2004-2006 The Trustees of Indiana University
Copyright (c) 2004-2008 The Trustees of Indiana University
Copyright (c) 2004-2009 The Trustees of Indiana University
Copyright (c) 2005-2006 The Trustees of Indiana University
Copyright (c) 2005-2008 The Trustees of Indiana University
Copyright (c) 2005-2010 The Trustees of Indiana University
Copyright (c) 2006-2007, Robert Hetland <hetland@tamu.edu>
Copyright (c) 2006-2010 The Trustees of Indiana University
Copyright (c) 2011, 2012 Martin Lambers <marlam@marlam.de>
Copyright (c) 2012 Flavio De Lorenzi (fdlorenzi@gmail.com)
Copyright 1999, 2000 Jaakko Jarvi (jaakko.jarvi@cs.utu.fi)
Copyright 2009 (c) Dean Michael Berris <me@deanberris.com>
(c) 1995 Ernst Stadlober, Institut fuer Statistitk, TU Graz
Copyright (c) 2001 Jeremy Siek, Douglas Gregor, Brian Osman
Copyright (c) 2005, Rasmus Munk Larsen, Stanford University
Copyright (c) 2006 Tiago de Paula Peixoto <tiago@forked.de>
Copyright (c) 2006-2009 Dmitry Bufistov and Andrey Parfenov
Copyright (c) 2014, 2019, 2020 Oracle and/or its affiliates
Copyright (c) 2017 Denis Demidov <dennis.demidov@gmail.com>
Copyright (c) 2017-2018 Alexandr Poltavsky, Antony Polukhin
Copyright 2013 Juan V. Puertos G-Cluster, Christian Henning
(c) 2015-2020 Niall Douglas <http://www.nedproductions.biz/>
(c) 2017-2020 Niall Douglas <http://www.nedproductions.biz/>
(c) 2018-2020 Niall Douglas <http://www.nedproductions.biz/>
(c) 2019-2020 Niall Douglas <http://www.nedproductions.biz/>
Copyright (c) 2001 Housemarque Oy http://www.housemarque.com
Copyright (c) 2002-2005, Jean-Sebastien Roy (js@jeannot.org)
Copyright (c) 2004-2005, Jean-Sebastien Roy (js@jeannot.org)
Copyright (c) 2014, 2018, 2019, Oracle and/or its affiliates
Copyright (c) Alexander Zaitsev <zamazan4ik@gmail.by> , 2017
Copyright (c) Tobias Schwinger http://spirit.sourceforge.net
Copyright 1984, 1987, 1988, 1992, 2000 by Stephen L. Moshier
Copyright 1984, 1987, 1989, 1992, 2000 by Stephen L. Moshier
(c) Copyright Runar Undheim, Robert Ramey & John Maddock 2008
Copyright (c) 2000-2003 Brian McNamara and Yannis Smaragdakis
Copyright (c) 2000-2013 The University of California Berkeley
Copyright (c) 2002,2003,2005,2020 CrystalClear Software, Inc.
Copyright (c) 2003 Martin Wille http://spirit.sourceforge.net
Copyright (c) 2011 Aaron Graham http://spirit.sourceforge.net
Copyright (c) 2014 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright (c) 2017 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright (c) 2020 Krystian Stasiowski (sdkrystian@gmail.com)
Copyright (c) Alexander Zaitsev <zamazan4ik@gmail.com> , 2016
Copyright (c) Alexander Zaitsev <zamazan4ik@gmail.com> , 2017
Copyright (c) Charles Karney (2008-2017) <charles@karney.com>
Copyright (c) Glen Joseph Fernandes 2019 (glenjofe@gmail.com)
Copyright 1984, 1987, 1988, 1992 by Stephen L. Moshier Direct
Copyright 1984, 1987, 1989, 1992 by Stephen L. Moshier Direct
Copyright Daniel Walker, Eric Niebler, Michel Morin 2008-2012
(c) 2018 - 2019 Niall Douglas <http://www.nedproductions.biz/>
(c) 2018 - 2020 Niall Douglas <http://www.nedproductions.biz/>
(c) Copyright 2002-2008 Robert Ramey and Joaquin M Lopez Munoz
Copyright (c) 1999, 2000 Jaakko Jarvi (jaakko.jarvi@cs.utu.fi)
Copyright (c) 1999, 2000, 2001 North Carolina State University
Copyright (c) 2001 Bruce Florman http://spirit.sourceforge.net
Copyright (c) 2001 Daniel Nuffer http://spirit.sourceforge.net
Copyright (c) 2002 Jeff Westfahl http://spirit.sourceforge.net
Copyright (c) 2003 Giovanni Bajo http://spirit.sourceforge.net
Copyright (c) 2003 Vaclav Vesely http://spirit.sourceforge.net
Copyright (c) 2005-2006 Douglas Gregor <doug.gregor@gmail.com>
Copyright (c) 2006 Joao Abecasis http://spirit.sourceforge.net
Copyright (c) 2007-2009 Ben Hanson (http://www.benhanson.net/)
Copyright (c) 2008-2009 Ben Hanson (http://www.benhanson.net/)
Copyright (c) 2010 2015 Francisco Jose Tapia fjtapia@gmail.com
Copyright (c) 2010 Bryce Lelbach http://spirit.sourceforge.net
Copyright (c) 2010 Matthias Walter (xammy@xammy.homelinux.net)
Copyright (c) 2011 Bryce Lelbach http://spirit.sourceforge.net
Copyright (c) 2013 Agustin Berge http://spirit.sourceforge.net
Copyright (c) 2017 Kristian Popov <kristian.popov@outlook.com>
Copyright (c) Tyler Reddy, Richard Gowers, and Max Linke, 2016
Copyright 2012-2019 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2014,2018 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2014-2015 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2014-2016 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2014-2020 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2016-2021 Matthew Brett, Isuru Fernando, Matti Picus
Copyright 2017-2018 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2017-2019 Glen Joseph Fernandes (glenjofe@gmail.com)
Copyright 2019-2020 Glen Joseph Fernandes (glenjofe@gmail.com)
(c) Copyright Andreas Huber Doenni 2002-2005, Eric Niebler 2006
(c) Copyright Peter Dimov and Multi Media Ltd. 2001, 2002, 2003
Copyright (c) 1996,1997 Silicon Graphics Computer Systems, Inc.
Copyright (c) 1996-1998 Silicon Graphics Computer Systems, Inc.
Copyright (c) 2001, 2002, 2003 Peter Dimov and Multi Media Ltd.
Copyright (c) 2002 Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2003 Gustavo Guerra http://spirit.sourceforge.net
Copyright (c) 2003 Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2003 Joel de Guzman http://spirit.sourceforge.net
Copyright (c) 2003 Jonathan de Halleux (dehalleux@pelikhan.com)
Copyright (c) 2004 David M. Cooke <cookedm@physics.mcmaster.ca>
Copyright (c) 2009 Francois Barel http://spirit.sourceforge.net
Copyright (c) 2011 Thomas Bernard http://spirit.sourceforge.net
Copyright (c) 2016 Frank Hein, maxence business consulting gmbh
Copyright Daryle Walker, Hubert Holin, John Maddock 2006 - 2007
(c) Copyright Mat Marcus, Jesse Jones and Adobe Systems Inc 2001
Copyright (c) 2000-2010 Joerg Walter, Mathias Koch, David Bellot
Copyright (c) 2000-2011 Joerg Walter, Mathias Koch, David Bellot
Copyright (c) 2000-2013 Joerg Walter, Mathias Koch. David Bellot
Copyright (c) 2003, Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2007 Matthias Troyer <troyer@boost-consulting.com>
Copyright Neil Groves & Thorsten Ottosen & Pavol Droba 2003-2004
copyrighted 2004 by David M. Cooke <cookedm@physics.mcmaster.ca>
(c) 2000 W. Hoermann & J. Leydold, Institut f. Statistik, WU Wien
(c) 2007 W. Hoermann & J. Leydold, Institut f. Statistik, WU Wien
Copyright (c) 2002-2003 Toon Knapen, Kresimir Fresl, Joerg Walter
Copyright (c) 2003, 2007-14 Massachusetts Institute of Technology
Copyright (c) 2006 Tobias Schwinger http://spirit.sourceforge.net
Copyright (c) 2006-2008 Emil Dotchevski and Reverge Studios, Inc.
Copyright (c) 2006-2009 Emil Dotchevski and Reverge Studios, Inc.
Copyright (c) 2006-2010 Emil Dotchevski and Reverge Studios, Inc.
Copyright (c) 2006-2013 Emil Dotchevski and Reverge Studios, Inc.
Copyright (c) 2008-2009 Emil Dotchevski and Reverge Studios, Inc.
Copyright (c) 2008-2016 Emil Dotchevski and Reverge Studios, Inc.
Copyright (c) 2008-2017 Emil Dotchevski and Reverge Studios, Inc.
Copyright (c) 2018-2020 Emil Dotchevski and Reverge Studios, Inc.
(c) Copyright David Abrahams, Jeremy Siek, Daryle Walker 1999-2001
Copyright (c) 2000-2007 Joerg Walter, Mathias Koch, Gunter Winkler
Copyright (c) 2000-2009 Joerg Walter, Mathias Koch, Gunter Winkler
Copyright (c) 2001, Daniel C. Nuffer http://spirit.sourceforge.net
Copyright (c) 2002-2003 Martin Wille http://spirit.sourceforge.net
Copyright (c) 2018 Yaghyavardhan Singh Khangarot, Hyderabad, India
Copyright 2002 Herve Bronnimann, Guillaume Melquiond, Sylvain Pion
Copyright 2012 Christian Henning, Andreas Pokorny, Lubomir Bourdev
Copyright (c) 2001-2002 Enthought, Inc. 2003-2022, SciPy Developers
Copyright (c) 2001-2003 Daniel Nuffer http://spirit.sourceforge.net
Copyright (c) 2001-2009 Daniel Nuffer http://spirit.sourceforge.net
Copyright (c) 2002 Raghavendra Satish http://spirit.sourceforge.net
Copyright (c) 2007 Free Software Foundation, Inc. <http://fsf.org/>
Copyright (c) 2009 Free Software Foundation, Inc. <http://fsf.org/>
Copyright (c) 2020, Debabrata Mandal <mandaldebabrata123@gmail.com>
Copyright 2019 Olzhas Zhumabek <anonymous.from.applecity@gmail.com>
Copyright (c) 1998-2002 Joel de Guzman http://spirit.sourceforge.net
Copyright (c) 1998-2003 Joel de Guzman http://spirit.sourceforge.net
Copyright (c) 2001-2003 Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2001-2003 Joel de Guzman http://spirit.sourceforge.net
Copyright (c) 2001-2007 Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2001-2008 Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2001-2010 Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2001-2011 Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2001-2011 Joel de Guzman http://spirit.sourceforge.net
Copyright (c) 2001-2012 Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2001-2012 Joel de Guzman http://spirit.sourceforge.net
Copyright (c) 2001-2014 Joel de Guzman http://spirit.sourceforge.net
Copyright (c) 2002-2003 Hartmut Kaiser http://spirit.sourceforge.net
Copyright (c) 2002-2006 Hartmut Kaiser http://spirit.sourceforge.net
(c) Copyright 2004-2009 Robert Ramey, Martin Ecker and Takatoshi Kondo
Copyright (c) 1996, 1997, 1998, 1999, 2000 Gerard Jungman, Brian Gough
Copyright (c) 2008 Rep Invariant Systems, Inc. (info@repinvariant.com)
(c) Copyright 2007, 2008 Steven Watanabe, Joseph Gauterin, Niels Dekker
Copyright (c) 2007, 2008 Steven Watanabe, Joseph Gauterin, Niels Dekker
Copyright (c) 2015 Muhammad Junaid Muzammil <mjunaidmuzammil@gmail.com>
Copyright 2002-2003 Herve Bronnimann, Guillaume Melquiond, Sylvain Pion
Copyright 2007-2008 Christian Henning, Andreas Pokorny, Lubomir Bourdev
Copyright 2007-2012 Christian Henning, Andreas Pokorny, Lubomir Bourdev
Copyright (c) 1998-2000 Theodore C. Belding University of Michigan Center
Copyright (c) 2000-2013 Joerg Walter, Mathias Koch, Athanasios Iliopoulos
Copyright 2003-2013 Joaquin M Lopez Munoz. 2019 Mike Dev <mike.dev@gmx.de>
(c) Copyright 2002 Rani Sharoni (rani_sharoni@hotmail.com) and Robert Ramey
(c) Copyright 2003-4 Pavel Vozenilek and Robert Ramey - http://www.rrsd.com
(c) Copyright Steve Cleary, Beman Dawes, Howard Hinnant & John Maddock 2000
Copyright 2014 by P.-G. Martinsson, V. Rokhlin, Y. Shkolnisky, and M. Tygert
Copyright (c) 2021-04-21 Stefan van der Walt https://github.com/stefanv/lloyd
copyright A. Volgenant/Amsterdam School of Economics, University of Amsterdam
Copyright (c) 2002-2003 Juan Carlos Arevalo-Baeza http://spirit.sourceforge.net
(c) Copyright Steve Cleary, Beman Dawes, Howard Hinnant & John Maddock 2000-2005
Copyright (c) 2000-2010 Joerg Walter, Mathias Koch, Gunter Winkler, David Bellot
Copyright 1987-, A. Volgenant/Amsterdam School of Economics, University of Amsterdam
(c) Copyright 2010 Just Software Solutions Ltd http://www.justsoftwaresolutions.co.uk
copyright (c) 2005 troy d. straszheim <troy@resophonic.com> http://www.resophonic.com
Copyright (c) 2002 Brad King (brad.king@kitware.com) Douglas Gregor (gregod@cs.rpi.edu)
(c) Copyright 2009-2011 Frederic Bron, Robert Stewart, Steven Watanabe & Roman Perepelitsa
(c) Copyright Dave Abrahams, Steve Cleary, Beman Dawes, Howard Hinnant & John Maddock 2000
(c) Copyright Dave Abrahams, Steve Cleary, Beman Dawes, Howard Hinnant and John Maddock 2000
Copyright (c) 2018 Sylvain Gubian <sylvain.gubian@pmi.com> , Yang Xiang <yang.xiang@pmi.com>
(c) Copyright Steve Cleary, Beman Dawes, Aleksey Gurtovoy, Howard Hinnant & John Maddock 2000
Copyright (c) 2003 Jonathan de Halleux (dehalleux@pelikhan.com) http://spirit.sourceforge.net
(c) Copyright Dave Abrahams, Steve Cleary, Beman Dawes, Howard Hinnant & John Maddock 2000-2003
(c) Copyright David Abrahams Steve Cleary, Beman Dawes, Howard Hinnant & John Maddock 2000-2002
Copyright (c) 1999-2001 Jaakko Jarvi (jaakko.jarvi@cs.utu.fi) Gary Powell (gwpowell@hotmail.com)
Copyright (c) Tyler Reddy, Ross Hemsley, Edd Edmondson, Nikolai Nowaczyk, Joe Pitt-Francis, 2015
Copyright (c) 2013 Jakob Lykke Andersen, University of Southern Denmark (jlandersen@imada.sdu.dk)
(c) Copyright Dave Abrahams, Steve Cleary, Beman Dawes, Howard Hinnant and John Maddock 2000, 2010
Copyright (c) 2001 Jaakko Jarvi (jaakko.jarvi@cs.utu.fi) 2001 Gary Powell (gary.powell@sierra.com)
Copyright (c) 2003 Jonathan de Halleux http://spirit.sourceforge.net http://www.boost.org/libs/spirit
Copyright (c) 1992-2013 The University of Tennessee and The University of Tennessee Research Foundation
(c) Copyright Dave Abrahams, Steve Cleary, Beman Dawes, Aleksey Gurtovoy, Howard Hinnant & John Maddock 2000
Copyright (c) 1990-2004 by Johannes Braams texniek at braams.cistron.nl Kersengaarde 33 2723 BP Zoetermeer NL
Copyright (c) 2003, The Regents of the University of California, through Lawrence Berkeley National Laboratory
Copyright (c) 2008 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2009 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2010 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2003-2009, The Regents of the University of California, through Lawrence Berkeley National Laboratory
Copyright (c) 2000-2010 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2000-2022 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2008-2010 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2009-2010 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2009-2011 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2009-2012 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2011-2012 Wolfgang Hoermann and Josef Leydold Institute for Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2000-2006 Wolfgang Hoermann and Josef Leydold Dept. for Statistics, University of Economics, Vienna, Austria
Copyright (c) 2000-2006, 2010 Wolfgang Hoermann and Josef Leydold Department of Statistics and Mathematics, WU Wien, Austria
Copyright (c) 2001 Ronald Garcia, Indiana University (garcia@osl.iu.edu) Andrew Lumsdaine, Indiana University (lums@osl.iu.edu)
Copyright (c) 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021 Python Software Foundation
(c) KOKOKOKOKKuKyKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKxKyK KyKxKzKzKzKzKzKzKzKzKzKzKzKzKyKxKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzKzK K K KzK K
Copyright 2002 Marc Wintermantel (wintermantel@even-ag.ch) ETH Zurich, Center of Structure Technologies (https://web.archive.org/web/20050307090307/http://www.structures.ethz.ch/)

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

sqlparse 0.4.4 - BSD-2-Clause AND BSD-3-Clause


copyright Y, Andi
Copyright (c) 2016, Andi Albrecht <albrecht.andi@gmail.com>
Copyright (c) 2009-2020 the sqlparse authors and contributors

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

threadpoolctl 3.1.0 - BSD-2-Clause AND BSD-3-Clause


Copyright (c) 2017, Intel Corporation
(Copyright (c) 2017, Intel Corporation)
Copyright (c) 2019, threadpoolctl contributors

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

werkzeug 2.3.4 - BSD-2-Clause AND BSD-3-Clause


Copyright 2007 Pallets
copyright 2007 Pallets

BSD-2-Clause AND BSD-3-Clause

---------------------------------------------------------

---------------------------------------------------------

scikit-learn 1.0.2 - BSD-3-Clause


(c) 2014
(c) INRIA
(c) INRIA 2010
(c) INRIA 2011
(c) INRIA 2014
Copyright INRIA
(c) 2011 import warnings
Copyright (c) 2011, 2012
Copyright (c) 2018, pandas
Copyright 2014 Steven Loria
Copyright 2011-2019 Twitter, Inc.
(c) INRIA, University of Amsterdam
Copyright 2015 Jon Lund Steffensen
Copyright 2007-2019 by the Sphinx team
Copyright (c) 2003-2016 Paul T. McGuire
Copyright (c) 2001, 2002 Enthought, Inc.
Copyright (c) 2003-2017 SciPy Developers
Copyright (c) 2007-2021 The scikit-learn
Copyright 2011-2019 The Bootstrap Authors
Copyright (c) 2011 Renato de Pontes Pereira
Copyright (c) 2007-2014 The LIBLINEAR Project
copyrights by Aric Hagberg <hagberg@lanl.gov>
Copyright (c) 2004-2017 Holger Krekel and others
copyright f'2007 - datetime.now .year, scikit-learn
Copyright (c) Donald Stufft and individual contributors
Copyright (c) 2000-2009 Chih-Chung Chang and Chih-Jen Lin
Copyright (c) 2011 Olivier Grisel <olivier.grisel@ensta.org>
Copyright (c) 2007-2019 by the Sphinx team (see AUTHORS file)
Copyright (c) 2011 David Warde-Farley <wardefar at iro dot umontreal dot ca>
Copyright 2011-2019 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
Copyright (c) 2007-2009 Cournapeau David <cournape@gmail.com> 2010 Fabian Pedregosa <fabian.pedregosa@inria.fr>
Copyright (c) 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018 Python Software Foundation
Copyright (c) 2007 David Cournapeau <cournape@gmail.com> 2010 Fabian Pedregosa <fabian.pedregosa@inria.fr> 2010 Olivier Grisel <olivier.grisel@ensta.org>

Copyright (c) <year> <owner> . All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

   3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------

---------------------------------------------------------

pillow 9.5.0 - HPND


(c) Tavmjung Bah
Copyright 2020 Google LLC
Copyright 2014 Google Inc.
Copyright 2016 Google Inc.
Copyright (c) 2018 Google LLC
Copyright (c) 2013 Eric Soroos
Copyright (c) 2020 by Pan Jing
Copyright (c) Eric Soroos 2016
Copyright (c) Eric Soroos 2017
Copyright (c) 2011 Google, Inc.
Copyright (c) 2002-2017, and GNU
Copyright (c) 2009 Fredrik Lundh
Copyright (c) Fredrik Lundh 1994
Copyright (c) Fredrik Lundh 1995
Copyright (c) Fredrik Lundh 1996
Copyright (c) Fredrik Lundh 1997
Copyright (c) Fredrik Lundh 1999
Copyright (c) Fredrik Lundh 2009
Copyright (c) 2004 by Secret Labs
Copyright (c) 2013 by Eric Soroos
Copyright (c) Secret Labs AB 1997
Copyright (c) Secret Labs AB 1998
Copyright (c) Secret Labs AB 1999
Copyright (c) Secret Labs AB 2002
Copyright (c) Secret Labs AB 2008
Copyright 2008 The Bungee Project
Copyright (c) 2004 by Bob Ippolito
Copyright (c) 2006 by Tavmjong Bah
Copyright (c) Mickael Bonfill 2017
Copyright (c) 1995 by Fredrik Lundh
Copyright (c) 1996 by Fredrik Lundh
Copyright (c) 1997 by Fredrik Lundh
Copyright (c) 1998-2001 Marti Maria
Copyright (c) 2002 by Fredrik Lundh
Copyright (c) 2003 by Fredrik Lundh
Copyright (c) 2004 by Fredrik Lundh
Copyright (c) 2005 by Fredrik Lundh
Copyright (c) 2006 by Fredrik Lundh
Copyright (c) 2009 by Fredrik Lundh
Copyright (c) 2012 by Brian Crowell
Copyright (c) Fredrik Lundh 1995-96
Copyright (c) Fredrik Lundh 1995-97
Copyright (c) Fredrik Lundh 1996-97
Copyright (c) 1998 by Secret Labs AB
Copyright (c) 2002 by Kevin B. Kenny
Copyright (c) 2002 by Secret Labs AB
Copyright (c) 2003 by Secret Labs AB
Copyright (c) 2004 by William Baxter
Copyright (c) 2014 Alastair Houghton
Copyright (c) Secret Labs AB 1997-98
Copyright (c) Secret Labs AB 1997-99
Copyright (c) 1996-2000 Fredrik Lundh
Copyright (c) 1997 by Secret Labs AB.
Copyright (c) 1998 by Toby J Sargeant
Copyright (c) 1999 by Secret Labs AB.
Copyright (c) 2002-2003 Kevin Cazabon
Copyright (c) 2003 by Bitstream, Inc.
Copyright (c) 2004 by Secret Labs AB.
Copyright (c) 2006 by Secret Labs AB.
Copyright (c) 2016 by Mickael Bonfill
Copyright (c) Fredrik Lundh 1995-1997
Copyright (c) Fredrik Lundh 1995-2003
Copyright (c) Fredrik Lundh 1996-2001
Copyright (c) Fredrik Lundh 1996-2003
Copyright (c) Fredrik Lundh 1997-2004
Portions copyright 2015, Khaled Hosny
Copyright (c) 1987 Adobe Systems, Inc.
Copyright (c) 1995-96 by Fredrik Lundh
Copyright (c) 1998-2000 Secret Labs AB
Copyright (c) Secret Labs AB 1997-2001
Copyright (c) Secret Labs AB 1997-2002
Copyright (c) Secret Labs AB 1997-2003
Copyright (c) Secret Labs AB 1997-2004
Copyright (c) Secret Labs AB 1997-2005
Copyright (c) Secret Labs AB 2002-2004
Copyright (c) 2008 by Karsten Hiddemann
Copyright (c) 2014 by Alastair Houghton
copyright (c) 1991-1995, Thomas G. Lane
Copyright (c) 1995-1996 by Fredrik Lundh
Copyright (c) 1995-1997 by Fredrik Lundh
Copyright (c) 1995-2001 by Fredrik Lundh
Copyright (c) 1995-2002 by Fredrik Lundh
Copyright (c) 1995-2003 by Fredrik Lundh
Copyright (c) 1995-2004 by Fredrik Lundh
Copyright (c) 1995-2005 by Fredrik Lundh
Copyright (c) 1995-2006 by Fredrik Lundh
Copyright (c) 1995-2009 by Fredrik Lundh
Copyright (c) 1995-2011 by Fredrik Lundh
Copyright (c) 1996-1997 by Fredrik Lundh
Copyright (c) 1996-2000 by Fredrik Lundh
Copyright (c) 1996-2003 by Fredrik Lundh
Copyright (c) 1996-2004 by Fredrik Lundh
Copyright (c) 1996-2006 by Fredrik Lundh
Copyright (c) 1997-1998 by Fredrik Lundh
Copyright (c) 1997-2003 by Fredrik Lundh
Copyright (c) 1997-2005 by Fredrik Lundh
Copyright (c) 1997-98 by Secret Labs AB.
Copyright (c) 1997-99 by Secret Labs AB.
Copyright (c) 1998-2003 by Fredrik Lundh
Copyright (c) 2000-2003 by Fredrik Lundh
Copyright (c) 2001-2002 by Fredrik Lundh
Copyright (c) 2001-2004 by Fredrik Lundh
Copyright (c) 2002-2004 by Fredrik Lundh
Copyright (c) 2003-2005 by Fredrik Lundh
Copyright 1984, 1987 Adobe Systems, Inc.
Copyright 2018 by Jack Halten Fahnestock
Copyright (c) 1995-2001 by Secret Labs AB
Copyright (c) 1997-1998 by Secret Labs AB
Copyright (c) 1997-1999 by Secret Labs AB
Copyright (c) 1997-2000 by Secret Labs AB
Copyright (c) 1997-2011 by Secret Labs AB
Copyright (c) 1998-2005 by Secret Labs AB
Copyright (c) 1998-2007 by Secret Labs AB
Copyright (c) 1999-2005 by Secret Labs AB
Copyright (c) 2001-2002 by Secret Labs AB
Copyright (c) 2001-2004 by Secret Labs AB
Copyright (c) 2002-2004 by Secret Labs AB
Copyright (c) 2003-2005 by Secret Labs AB
Copyright (c) 2015 Information Technology
Copyright (c) 2018 Dimitar Toshkov Zhekov
Copyright (c) 1997-2001 by Secret Labs AB.
Copyright (c) 1997-2002 by Secret Labs AB.
Copyright (c) 1997-2003 by Secret Labs AB.
Copyright (c) 1997-2004 by Secret Labs AB.
Copyright (c) 1997-2005 by Secret Labs AB.
Copyright (c) 1997-2006 by Secret Labs AB.
Copyright (c) 1997-2009 by Secret Labs AB.
Copyright (c) 1998-2003 by Secret Labs AB.
Copyright (c) 1998-2004 by Secret Labs AB.
Copyright (c) 2004 by Health Research Inc.
Copyright (c) 1993-1996 Lucent Technologies
Copyright (c) 1997-2007 Adobe Systems, Inc.
Copyright (c) 2000-2006 Adobe Systems, Inc.
Copyright (c) 2014 Coriolis Systems Limited
Copyright 2007 International Color Consortium
Copyright (c) 1994-1998 Sun Microsystems, Inc.
Copyright (c) 2014 by Coriolis Systems Limited
Copyright 1987-2001 Adobe Systems Incorporated
Copyright 1987-2004 Adobe Systems Incorporated
Copyright 1987-2006 Adobe Systems Incorporated
Copyright 1997-2006 Adobe Systems Incorporated
Copyright International Color Consortium, 2009
Portions Copyright 1988 Digital Equipment Corp.
Copyright (c) 1998-2000 by Scriptics Corporation
Copyright (c) 2020 Free Software Foundation, Inc.
Copyright (c) 2016 Marcin Kurczewski <rr-@sakuya.pl>
Portions Copyright 1988 Digital Equipment Corporation
Copyright (c) 2010 Oliver Tonnhofer <olt@bogosoft.com>
Copyright (c) 2014 Dov Grobgeld <dov.grobgeld@gmail.com>
Copyright 2013 Google Inc.Noto Color EmojiRegularVersion
Copyright (c) 2018 Roel Nieskens, https://pixelambacht.nl
Copyright (c) 2016-2022 Khaled Hosny <khaled@aliftype.com>
copyright 2003 kevin_cazabon@hotmail.com kevin@cazabon.com
Copyright (c) 1987-1994 The Regents of the University of California
Copyright (c) 2010-2023 by Jeffrey A. Clark (Alex) and contributors
Copyright 2002, 2003, 2005, 2008, 2009, 2010, 2012 GNU Freefont contributors
Copyright (c) 2002-2003 Kevin Cazabon kevin@cazabon.com https://www.cazabon.com
copyright 1995-2011 Fredrik Lundh, 2010-2023 Jeffrey A. Clark (Alex) and contributors
Portions copyright 1997, 2009, 2011 American Mathematical Society <http://www.ams.org>
Copyright 2002, 2003, 2005, 2008, 2009, 2010, 2012 GNU Freefont contributors. FreeMono FreeMono
copyrighted by the Regents of the University of California, Sun Microsystems, Inc., Scriptics Corporation
Copyright 2016 Adobe (http://www.adobe.com/).Adobe Variable Font PrototypeRegular1.004 ADBO AdobeVFPrototype-Default ADOBEVersion
Copyright 2014, 2015 Adobe Systems Incorporated (http://www.adobe.com/).Noto Sans JP RegularRegular1.004 GOOG NotoSansJP-Regular ADOBEVersion
copyright 2010-2011, Google Corporation.Open Sans Condensed LightItalic1.10 1ASC OpenSansCondensed-LightItalicOpen Sans Condensed Light ItalicVersion

Historical Permission Notice and Disclaimer

<copyright notice>

Permission to use, copy, modify and distribute this software and its documentation for any purpose and without fee is hereby granted, provided that the above copyright notice appear in all copies , and that both that the copyright notice and this permission notice appear in supporting documentation , and that the name of <copyright holder> <or related entities> not be used in advertising or publicity pertaining to distribution of the software without specific, written prior permission . <copyright holder> makes no representations about the suitability of this software for any purpose. It is provided "as is" without express or implied warranty. <copyright holder> DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS . IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

alembic 1.11.1 - MIT


(c) Zeno Rocha
copyright 2010-2023, Mike Bayer
Copyright 2009-2023 Michael Bayer
(c) Copyright 2010-2023, Mike Bayer
Copyright 2007-2023 by the Sphinx team
Copyright (c) 2005-2019 the SQLAlchemy authors and contributors
Copyright (c) 2005-2021 the SQLAlchemy authors and contributors

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

attrs 23.1.0 - MIT


(c) N Revealed
Hynek Schlawack copyright f'2015
Copyright (c) 2015 Hynek Schlawack
Copyright (c) 2015 Hynek Schlawack"
Copyright (c) 2015 Hynek Schlawack" == mod.__copyright
Copyright ..." is shown in the HTML footer. Default is True.

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

backports.functools-lru-cache 1.6.4 - MIT


Copyright Jason R. Coombs

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

blinker 1.6.2 - MIT


Copyright 2010 Jason Kirtland
copyright 2010 Jason Kirtland
Copyright (c) 2006 Patrick K. O'Brien, Mike C. Fletcher, Matthew R. Scott

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

charset-normalizer 3.1.0 - MIT


COPYRIGHT (c) FOOBAR
copyright 2019, Ahmed TAHRI
Copyright (c) 2019 TAHRI Ahmed R.
copyright (c) 2021 by Ahmed TAHRI
Copyright (c) 2019 Ahmed TAHRI Ousret
(c) 2012 Denny Vrandecic (http://simia.net/letters/)
Copyright (c) Ahmed TAHRI Ousret (https://github.com/Ousret)
(c) https://stackoverflow.com/questions/3041986/apt-command-line-interface-like-yes-no-input

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

cmaes 0.9.1 - MIT


Copyright (c) 2020-2021 CyberAgent, Inc.

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

cmd2 2.4.3 - MIT


Copyright (c) 2018 Jared Crapo
copyright 2010-2021, cmd2 contributors
Copyright (c) 2008-2023 Catherine Devlin and others

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

colorlog 6.7.0 - MIT


Copyright (c) 2012-2021 Sam Clements <sam@borntyping.co.uk>

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

configparser 5.3.0 - MIT


Copyright Jason R. Coombs

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

entrypoints 0.4 - MIT


copyright 2015, Thomas Kluyver
Copyright (c) Thomas Kluyver and contributors
Copyright (c) 2015 Thomas Kluyver and contributors

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

gunicorn 20.1.0 - MIT


(c) Meebo, Inc.
Copyright 2013 Dariusz Suchojad
Copyright (c) 2008-2010, Eventlet
Copyright 2001-2005 by Vinay Sajip
copyright 2009- s, Benoit Chesneau
Copyright (c) 2005-2006, Bob Ippolito
Copyright (c) 2007-2010, Linden Research, Inc.
(c) Paul J. Davis <paul.joseph.davis@gmail.com>
(c) Benoit Chesneau <benoitc@e-engura.org> 2009-2015
Copyright 2009 Paul J. Davis <paul.joseph.davis@gmail.com>

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

lightgbm 3.3.5 - MIT


Bf16ToF32Odd (c) Packet4f
Copyright (c) 2017 yohhoy
Copyright Paul Dreik 2019
Bf16ToF32Even (c) Packet4f
Copyright 2013 Google Inc.
Copyright (c) Daniel Lemire
Copyright 2020 Daniel Lemire
Copyright (c) 2010, Intel Corp.
Copyright (c) 2014 Mageswaran.D
Copyright (c) 2013 Dropbox, Inc.
Copyright (c) 2007 Julien Pommier
Copyright (c) 2009 Claire Maurice
Copyright (c) 2011 Hannes Hofmann
Copyright (c) Fabian Giesen, 2016
Copyright (c) 2010 Vincent Lejeune
Copyright (c) 2020 IBM Corporation
Copyright (c) Microsoft Corporation
Copyright (c) 2001 Intel Corporation
Copyright (c) 2011, Intel Corporation
Copyright 2017 The TensorFlow Authors
Copyright (c) 2018 Wave Computing, Inc.
Copyright (c) 2016 Microsoft Corporation
Copyright (c) 2017 Microsoft Corporation
Copyright (c) 2018 Microsoft Corporation
Copyright (c) 2019 Microsoft Corporation
Copyright (c) 2020 Microsoft Corporation
Copyright (c) 2021 Microsoft Corporation
Copyright 2010-2012, D. E. Shaw Research
(c) 2012,2014 Advanced Micro Devices, Inc.
Copyright (c) 2012 - 2016, Victor Zverovich
Copyright (c) 2017 Codeplay Software Limited
Copyright (c) 2012 - present, Victor Zverovich
Copyright (c) 2014 yoco <peter.xiau@gmail.com>
Copyright (c) 2009 Keir Mierle <mierle@gmail.com>
Copyright (c) 2009 Rohit Garg <rpg.314@gmail.com>
Copyright (c) 2013 Kyle Lutz <kyle.r.lutz@gmail.com>
Copyright (c) 2015 Jakub Pola <jakub.pola@gmail.com>
Copyright (c) 2015 Jakub Szuppe <j.szuppe@gmail.com>
Copyright (c) 2016 Eugene Brevdo <ebrevdo@gmail.com>
Copyright (c) 2016 Jakub Szuppe <j.szuppe@gmail.com>
Copyright (c) 2018 - present, Remotion (Igor Schulz)
Copyright (c) 2018 Jakub Szuppe <j.szuppe@gmail.com>
Copyright (c) 2011 Timothy E. Holy tim.holy@gmail.com
Copyright (c) 2014 Roshan <thisisroshansmail@gmail.com>
Copyright (c) 2009 Hauke Heibel <hauke.heibel@gmail.com>
Copyright (c) 2009 Kenneth Riddile <kfriddile@yahoo.com>
Copyright (c) 2010 Hauke Heibel <hauke.heibel@gmail.com>
Copyright (c) 2014 Pedro Gonnet (pedro.gonnet@gmail.com)
Copyright (c) 2016 Pedro Gonnet (pedro.gonnet@gmail.com)
Copyright (c) 2016 Tobias Wood <tobias@spinicist.org.uk>
Copyright (c) 2009 Ricard Marxer <email@ricardmarxer.com>
Copyright (c) 2010 Jitse Niesen <jitse@maths.leeds.ac.uk>
Copyright (c) 2011 Jitse Niesen <jitse@maths.leeds.ac.uk>
Copyright (c) 2012 Alexey Korepanov <kaikaikai@yandex.ru>
Copyright (c) 2013 Jean Ceccato <jean.ceccato@ensimag.fr>
Copyright (c) 2013 Jitse Niesen <jitse@maths.leeds.ac.uk>
Copyright (c) 2013-2014 Kyle Lutz <kyle.r.lutz@gmail.com>
Copyright (c) 2013-2015 Kyle Lutz <kyle.r.lutz@gmail.com>
Copyright (c) 2020 Antonio Sanchez <cantonios@google.com>
Copyright (c) 2008 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2009 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2010 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2011 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2013 Gauthier Brun <brun.gauthier@gmail.com>
Copyright (c) 2009 Mathieu Gautier <mathieu.gautier@cea.fr>
Copyright (c) 2013 Nicolas Carre <nicolas.carre@ensimag.fr>
Copyright (c) 2016 Rasmus Munk Larsen (rmlarsen@google.com)
Copyright (c) 2016 Rasmus Munk Larsen <rmlarsen@google.com>
Copyright (c) 2017 Denis Demidov <dennis.demidov@gmail.com>
Copyright (c) 2018 Rasmus Munk Larsen <rmlarsen@google.com>
Copyright (c) 2019 Rasmus Munk Larsen <rmlarsen@google.com>
Copyright (c) 2007 Michael Olbrich <michael.olbrich@gmx.net>
Copyright (c) 2010 Thomas Capricelli <orzel@freehackers.org>
Copyright (c) 2013 Pavel Holoborodko <pavel@holoborodko.com>
Copyright (c) 2008 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2009 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2010 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2010-2013 Hauke Heibel <hauke.heibel@gmail.com>
Copyright (c) 2012 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2014 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2015 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2016 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2017 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2018 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2019 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2010,2012 Jitse Niesen <jitse@maths.leeds.ac.uk>
Copyright (c) 2011-2012 Jitse Niesen <jitse@maths.leeds.ac.uk>
Copyright (c) 2017 Kristian Popov <kristian.popov@outlook.com>
Copyright (c) 2006-2008 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2006-2009 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2006-2010 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2007-2009 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2007-2010 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2007-2011 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2008-2009 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2008-2010 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2009, Jay Loden, Dave Daeschler, Giampaolo Rodola
Copyright (c) 2009-2010 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2010 Konstantinos Margaritis <markos@freevec.org>
Copyright (c) 2016 Konstantinos Margaritis <markos@freevec.org>
Copyright (c) 2014 Benoit Steiner (benoit.steiner.goog@gmail.com)
Copyright (c) 2014 Benoit Steiner <benoit.steiner.goog@gmail.com>
Copyright (c) 2015 Benoit Steiner <benoit.steiner.goog@gmail.com>
Copyright (c) 2016 Benoit Steiner (benoit.steiner.goog@gmail.com)
Copyright (c) 2016 Benoit Steiner <benoit.steiner.goog@gmail.com>
Copyright (c) 2008-2009 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2008-2010 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2008-2011 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2008-2014 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2008-2015 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2008-2016 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2008-2017 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2008-2018 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2008-2019 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2009-2010 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2009-2014 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2009-2015 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2009-2019 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2010-2011 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2010-2016 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2011-2014 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2011-2018 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2012-2016 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2013-2014 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2013-2016 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2014-2017 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2014-2019 Gael Guennebaud <gael.guennebaud@inria.fr>
Copyright (c) 2012 - present, Victor Zverovich and fmt contributors
Copyright (c) 2013 Pierre Zoppitelli <pierre.zoppitelli@ensimag.fr>
Copyright (c) 2018 - present, Victor Zverovich and fmt contributors
Copyright (c) 2008-2016 Konstantinos Margaritis <markos@freevec.org>
Copyright (c) 2010-2016 Konstantinos Margaritis <markos@freevec.org>
Copyright (c) 2020 Everton Constantino (everton.constantino@ibm.com)
Copyright (c) 2006-2008, 2010 Benoit Jacob <jacob.benoit.1@gmail.com>
Copyright (c) 2015 Muhammad Junaid Muzammil <mjunaidmuzammil@gmail.com>

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

mako 1.2.4 - MIT


Copyright 2008 by Armin Ronacher
Copyright (c) 2006 Edgewall Software
Copyright 2007-2022 by the Sphinx team
(c) OpenJS Foundation and other contributors
Copyright JS Foundation and other contributors
Copyright OpenJS Foundation and other contributors
Copyright 2006-2020 the Mako authors and contributors
Copyright 2006-2022 the Mako authors and contributors
(c) Copyright the Mako authors and contributors. Documentation generated using http://sphinx.pocoo.org
(c) 2009-2021 Jeremy Ashkenas, Julian Gonggrijp, and DocumentCloud and Investigative Reporters & Editors Underscore

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

optuna 2.8.0 - MIT



MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

pyjwt 2.7.0 - MIT


Copyright 2015-2022 Jose Padilla
copyright 2015-2022, Jose Padilla
Copyright (c) 2015-2022 Jose Padilla

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

pyparsing 3.0.9 - MIT


Copyright 2004-2010
Copyright, Tom Coonan
Copyright (c) 2021 Dot
Copyright 2004, Paul McGuire
Copyright 2006, Paul McGuire
Copyright 2008 Chris Lambrou
Copyright 2008, Paul McGuire
Copyright 2010, Paul McGuire
Copyright 2011, Paul McGuire
Copyright 2015, Paul McGuire
Copyright 2016, Paul McGuire
Copyright 2018, Paul McGuire
Copyright 2019, Paul McGuire
Copyright 2020, Paul McGuire
Copyright 2021, Paul McGuire
Copyright Paul McGuire, 2019
Copyright Paul McGuire, 2021
copyright 2006, Paul McGuire
Copyright, 2010, Paul McGuire
Copyright 2007 by Paul McGuire
Copyright, 2007 - Paul McGuire
Copyright, 2012 - Paul McGuire
Copyright 2006, by Paul McGuire
Copyright 2008, by Paul McGuire
Copyright 2012, Paul T. McGuire
Copyright 2022, by Paul McGuire
Copyright (c) 2003, Paul McGuire
Copyright (c) 2004, Paul McGuire
Copyright (c) 2006, Paul McGuire
Copyright (c) 2009 Zarko Zivanov
Copyright (c) 2016, Paul McGuire
Copyright 2010,2019 Paul McGuire
Copyright, 2006, by Paul McGuire
Copyright (c) 2008, InformAsic AB
Copyright 2002-2021, Paul McGuire
Copyright 2005-2006, Paul McGuire
Copyright 2009, 2011 Paul McGuire
Copyright (c) 2018 Paul T. McGuire
Copyright Ellis & Grant, Inc. 2005
Copyright 2003-2019 by Paul McGuire
Copyright 2011,2015 Paul T. McGuire
Copyright (c) 2003,2019 Paul McGuire
Copyright (c) 2006,2016 Paul McGuire
Copyright 2003, 2019 by Paul McGuire
Copyright 2004-2016, by Paul McGuire
Copyright 2007-2011, by Paul McGuire
Copyright 2010, 2019 by Paul McGuire
Copyright 2012, 2019 Paul T. McGuire
copyright 2018-2021, Paul T. McGuire
Copyright (c) 2003,2016, Paul McGuire
Copyright (c) 2004, 2006 Paul McGuire
Copyright (c) 2004-2016, Paul McGuire
Copyright copy 2003-2022 Paul McGuire
Copyright (c) 2006, 2016, Paul McGuire
Copyright (c) 2006, 2019, Paul McGuire
Copyright (c) 2003-2019 Paul T. McGuire
Copyright (c) 2003-2022 Paul T. McGuire
Copyright (c) 2004-2011 Paul T. McGuire
Copyright (c) 1992-1993 Jean-loup Gailly
Copyright (c) 2006, Estrate, the Netherlands
Copyright 1989 by Carnegie Mellon University
Copyright (c) 2000 Rudolf Usselmann rudi@asics.ws
Copyright (c) 2006 Tim Cera timcera@earthlink.net
Copyright Petri Savolainen <firstname.lastname@iki.fi>
copyright 1999, Kluwer Academic Publishers, Norwell, MA
Copyright 2004, by Alberto Santini http://www.albertosantini.it/chess
copyright 1998, Sutherland HDL Inc, Portland, Oregon, USA Contact www.sutherland.com
Copyright (c) 1999 Fulvio Corno, Matteo Sonze Reorda, Giovanni Squillero Politecnico di Torino

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

pytz 2023.3 - MIT


Copyright (c) 2003-2019 Stuart Bishop <stuart@stuartbishop.net>

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

pyyaml 6.0 - MIT


Copyright (c) 2017-2021 Ingy dot Net
Copyright (c) 2006-2016 Kirill Simonov

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

querystring-parser 1.2.4 - MIT



MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

six 1.16.0 - MIT


copyright u'2010-2020, Benjamin Peterson
Copyright (c) 2010-2020 Benjamin Peterson

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

sqlalchemy 2.0.15 - MIT


(c) Zeno Rocha
Copyright (c) Microsoft
Copyright Sphinx contributors
Copyright 2007-2023 by the Sphinx team
Copyright SQLAlchemy 2.0 Documentation
(c) OpenJS Foundation and other contributors
Copyright (c) 2005-2023 Michael Bayer and contributors
Copyright (c) 2010 Gaetan de Menten gdementen@gmail.com
Copyright 2005-2023 SQLAlchemy authors and contributors
Copyright (c) Microsoft Corporation', Microsoft SQL Azure
Copyright (c) 2021 the SQLAlchemy authors and contributors
Copyright (c) 2022 the SQLAlchemy authors and contributors
Copyright 2007-2023, the SQLAlchemy authors and contributors
copyright 2007-2023, the SQLAlchemy authors and contributors
Copyright (c) 2005-2021 the SQLAlchemy authors and contributors
Copyright (c) 2005-2023 the SQLAlchemy authors and contributors
Copyright (c) 2006-2023 the SQLAlchemy authors and contributors
Copyright (c) 2009-2023 the SQLAlchemy authors and contributors
Copyright (c) 2010-2023 the SQLAlchemy authors and contributors
Copyright (c) 2013-2023 the SQLAlchemy authors and contributors
Copyright (c) 2020-2023 the SQLAlchemy authors and contributors
Copyright (c) 2021-2023 the SQLAlchemy authors and contributors

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

tabulate 0.9.0 - MIT


Copyright (c) 2011-2020 Sergey Astanin and contributors

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

tqdm 4.65.0 - MIT


Copyright (c) 2013 noamraph
(c) Noam Yorav-Raphael, original author
(c) Casper da Costa-Luis casperdcl (https://github.com/casperdcl)

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

urllib3 1.26.16 - MIT


Copyright 2015 Google Inc.
Copyright (c) 2010-2020 Benjamin Peterson
Copyright (c) 2015-2016 Will Bond <will@wbond.net>
Copyright (c) 2008-2020 Andrey Petrov and contributors
Copyright (c) 2012 Senko Rasic <senko.rasic@dobarkod.hr>

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

wcwidth 0.2.6 - MIT


Copyright (c) 2014 Jeff Quast <contact@jeffquast.com>

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

zipp 3.15.0 - MIT


Copyright Jason R. Coombs

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

certifi 2023.5.7 - MPL-2.0


(c) 2006 Entrust, Inc.
(c) 1999 Entrust.net Limited
(c) 2009 Entrust, Inc. - for
(c) 2012 Entrust, Inc. - for
(c) 2015 Entrust, Inc. - for
(c) 2006 Entrust, Inc. Label Entrust Root Certification
(c) 1999 Entrust.net Limited Label Entrust.net Premium 2048 Secure Server CA Serial

Mozilla Public License Version 2.0

   1. Definitions

      1.1. "Contributor" means each individual or legal entity that creates, contributes to the creation of, or owns Covered Software.

      1.2. "Contributor Version" means the combination of the Contributions of others (if any) used by a Contributor and that particular Contributor's Contribution.

      1.3. "Contribution" means Covered Software of a particular Contributor.

      1.4. "Covered Software" means Source Code Form to which the initial Contributor has attached the notice in Exhibit A, the Executable Form of such Source Code Form, and Modifications of such Source Code Form, in each case including portions thereof.

      1.5. "Incompatible With Secondary Licenses" means

         (a) that the initial Contributor has attached the notice described in Exhibit B to the Covered Software; or

         (b) that the Covered Software was made available under the terms of version 1.1 or earlier of the License, but not also under the terms of a Secondary License.

      1.6. "Executable Form" means any form of the work other than Source Code Form.

      1.7. "Larger Work" means a work that combines Covered Software with other material, in a separate file or files, that is not Covered Software.

      1.8. "License" means this document.

      1.9. "Licensable" means having the right to grant, to the maximum extent possible, whether at the time of the initial grant or subsequently, any and all of the rights conveyed by this License.

      1.10. "Modifications" means any of the following:

         (a) any file in Source Code Form that results from an addition to, deletion from, or modification of the contents of Covered Software; or

         (b) any new file in Source Code Form that contains any Covered Software.

      1.11. "Patent Claims" of a Contributor means any patent claim(s), including without limitation, method, process, and apparatus claims, in any patent Licensable by such Contributor that would be infringed, but for the grant of the License, by the making, using, selling, offering for sale, having made, import, or transfer of either its Contributions or its Contributor Version.

      1.12. "Secondary License" means either the GNU General Public License, Version 2.0, the GNU Lesser General Public License, Version 2.1, the GNU Affero General Public License, Version 3.0, or any later versions of those licenses.

      1.13. "Source Code Form" means the form of the work preferred for making modifications.

      1.14. "You" (or "Your") means an individual or a legal entity exercising rights under this License. For legal entities, "You" includes any entity that controls, is controlled by, or is under common control with You. For purposes of this definition, "control" means (a) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (b) ownership of more than fifty percent (50%) of the outstanding shares or beneficial ownership of such entity.

   2. License Grants and Conditions

      2.1. Grants

      Each Contributor hereby grants You a world-wide, royalty-free, non-exclusive license:

         (a) under intellectual property rights (other than patent or trademark) Licensable by such Contributor to use, reproduce, make available, modify, display, perform, distribute, and otherwise exploit its Contributions, either on an unmodified basis, with Modifications, or as part of a Larger Work; and

         (b) under Patent Claims of such Contributor to make, use, sell, offer for sale, have made, import, and otherwise transfer either its Contributions or its Contributor Version.

      2.2. Effective Date

      The licenses granted in Section 2.1 with respect to any Contribution become effective for each Contribution on the date the Contributor first distributes such Contribution.

      2.3. Limitations on Grant Scope

      The licenses granted in this Section 2 are the only rights granted under this License. No additional rights or licenses will be implied from the distribution or licensing of Covered Software under this License. Notwithstanding Section 2.1(b) above, no patent license is granted by a Contributor:

         (a) for any code that a Contributor has removed from Covered Software; or

         (b) for infringements caused by: (i) Your and any other third party's modifications of Covered Software, or (ii) the combination of its Contributions with other software (except as part of its Contributor Version); or

         (c) under Patent Claims infringed by Covered Software in the absence of its Contributions.

      This License does not grant any rights in the trademarks, service marks, or logos of any Contributor (except as may be necessary to comply with the notice requirements in Section 3.4).

      2.4. Subsequent Licenses

      No Contributor makes additional grants as a result of Your choice to distribute the Covered Software under a subsequent version of this License (see Section 10.2) or under the terms of a Secondary License (if permitted under the terms of Section 3.3).

      2.5. Representation

      Each Contributor represents that the Contributor believes its Contributions are its original creation(s) or it has sufficient rights to grant the rights to its Contributions conveyed by this License.

      2.6. Fair Use

      This License is not intended to limit any rights You have under applicable copyright doctrines of fair use, fair dealing, or other equivalents.

      2.7. Conditions

      Sections 3.1, 3.2, 3.3, and 3.4 are conditions of the licenses granted in Section 2.1.

   3. Responsibilities

      3.1. Distribution of Source Form

      All distribution of Covered Software in Source Code Form, including any Modifications that You create or to which You contribute, must be under the terms of this License. You must inform recipients that the Source Code Form of the Covered Software is governed by the terms of this License, and how they can obtain a copy of this License. You may not attempt to alter or restrict the recipients' rights in the Source Code Form.

      3.2. Distribution of Executable Form

      If You distribute Covered Software in Executable Form then:

         (a) such Covered Software must also be made available in Source Code Form, as described in Section 3.1, and You must inform recipients of the Executable Form how they can obtain a copy of such Source Code Form by reasonable means in a timely manner, at a charge no more than the cost of distribution to the recipient; and

         (b) You may distribute such Executable Form under the terms of this License, or sublicense it under different terms, provided that the license for the Executable Form does not attempt to limit or alter the recipients' rights in the Source Code Form under this License.

      3.3. Distribution of a Larger Work

      You may create and distribute a Larger Work under terms of Your choice, provided that You also comply with the requirements of this License for the Covered Software. If the Larger Work is a combination of Covered Software with a work governed by one or more Secondary Licenses, and the Covered Software is not Incompatible With Secondary Licenses, this License permits You to additionally distribute such Covered Software under the terms of such Secondary License(s), so that the recipient of the Larger Work may, at their option, further distribute the Covered Software under the terms of either this License or such Secondary License(s).

      3.4. Notices

      You may not remove or alter the substance of any license notices (including copyright notices, patent notices, disclaimers of warranty, or limitations of liability) contained within the Source Code Form of the Covered Software, except that You may alter any license notices to the extent required to remedy known factual inaccuracies.

      3.5. Application of Additional Terms

      You may choose to offer, and to charge a fee for, warranty, support, indemnity or liability obligations to one or more recipients of Covered Software. However, You may do so only on Your own behalf, and not on behalf of any Contributor. You must make it absolutely clear that any such warranty, support, indemnity, or liability obligation is offered by You alone, and You hereby agree to indemnify every Contributor for any liability incurred by such Contributor as a result of warranty, support, indemnity or liability terms You offer. You may include additional disclaimers of warranty and limitations of liability specific to any jurisdiction.

   4. Inability to Comply Due to Statute or Regulation

   If it is impossible for You to comply with any of the terms of this License with respect to some or all of the Covered Software due to statute, judicial order, or regulation then You must: (a) comply with the terms of this License to the maximum extent possible; and (b) describe the limitations and the code they affect. Such description must be placed in a text file included with all distributions of the Covered Software under this License. Except to the extent prohibited by statute or regulation, such description must be sufficiently detailed for a recipient of ordinary skill to be able to understand it.

   5. Termination

      5.1. The rights granted under this License will terminate automatically if You fail to comply with any of its terms. However, if You become compliant, then the rights granted under this License from a particular Contributor are reinstated (a) provisionally, unless and until such Contributor explicitly and finally terminates Your grants, and (b) on an ongoing basis, if such Contributor fails to notify You of the non-compliance by some reasonable means prior to 60 days after You have come back into compliance. Moreover, Your grants from a particular Contributor are reinstated on an ongoing basis if such Contributor notifies You of the non-compliance by some reasonable means, this is the first time You have received notice of non-compliance with this License from such Contributor, and You become compliant prior to 30 days after Your receipt of the notice.

      5.2. If You initiate litigation against any entity by asserting a patent infringement claim (excluding declaratory judgment actions, counter-claims, and cross-claims) alleging that a Contributor Version directly or indirectly infringes any patent, then the rights granted to You by any and all Contributors for the Covered Software under Section 2.1 of this License shall terminate.

      5.3. In the event of termination under Sections 5.1 or 5.2 above, all end user license agreements (excluding distributors and resellers) which have been validly granted by You or Your distributors under this License prior to termination shall survive termination.

   6. Disclaimer of Warranty

   Covered Software is provided under this License on an "as is" basis, without warranty of any kind, either expressed, implied, or statutory, including, without limitation, warranties that the Covered Software is free of defects, merchantable, fit for a particular purpose or non-infringing. The entire risk as to the quality and performance of the Covered Software is with You. Should any Covered Software prove defective in any respect, You (not any Contributor) assume the cost of any necessary servicing, repair, or correction. This disclaimer of warranty constitutes an essential part of this License. No use of any Covered Software is authorized under this License except under this disclaimer.

   7. Limitation of Liability

   Under no circumstances and under no legal theory, whether tort (including negligence), contract, or otherwise, shall any Contributor, or anyone who distributes Covered Software as permitted above, be liable to You for any direct, indirect, special, incidental, or consequential damages of any character including, without limitation, damages for lost profits, loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses, even if such party shall have been informed of the possibility of such damages. This limitation of liability shall not apply to liability for death or personal injury resulting from such party's negligence to the extent applicable law prohibits such limitation. Some jurisdictions do not allow the exclusion or limitation of incidental or consequential damages, so this exclusion and limitation may not apply to You.

   8. Litigation

   Any litigation relating to this License may be brought only in the courts of a jurisdiction where the defendant maintains its principal place of business and such litigation shall be governed by laws of that jurisdiction, without reference to its conflict-of-law provisions. Nothing in this Section shall prevent a party's ability to bring cross-claims or counter-claims.

   9. Miscellaneous

   This License represents the complete agreement concerning the subject matter hereof. If any provision of this License is held to be unenforceable, such provision shall be reformed only to the extent necessary to make it enforceable. Any law or regulation which provides that the language of a contract shall be construed against the drafter shall not be used to construe this License against a Contributor.

   10. Versions of the License

      10.1. New Versions

      Mozilla Foundation is the license steward. Except as provided in Section 10.3, no one other than the license steward has the right to modify or publish new versions of this License. Each version will be given a distinguishing version number.

      10.2. Effect of New Versions

      You may distribute the Covered Software under the terms of the version of the License under which You originally received the Covered Software, or under the terms of any subsequent version published by the license steward.

      10.3. Modified Versions

      If you create software not governed by this License, and you want to create a new license for such software, you may create and use a modified version of this License if you rename the license and remove any references to the name of the license steward (except to note that such modified license differs from this License).

      10.4. Distributing Source Code Form that is Incompatible With Secondary Licenses

      If You choose to distribute Source Code Form that is Incompatible With Secondary Licenses under the terms of this version of the License, the notice described in Exhibit B of this License must be attached. Exhibit A - Source Code Form License Notice

This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0. If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.

If it is not possible or desirable to put the notice in a particular file, then You may include the notice in a location (such as a LICENSE file in a relevant directory) where a recipient would be likely to look for such a notice.

You may add additional accurate notices of copyright ownership.

Exhibit B - "Incompatible With Secondary Licenses" Notice

This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.

---------------------------------------------------------

---------------------------------------------------------

matplotlib 3.7.1 - PSF-2.0


(c) Tavmjong Bah
(c) Tavmjung Bah
Copyright Font's
Copyright xa9 2017
b'Copyright xa9 2017
(c) Frank Siegert 1996
(c) 2003 by Bitstream, Inc.
Copyright <http://www.ams.org>
X11R4 release, copyright M.I.T.
Copyright (c) 2010 Doug Hellmann
Copyright 2010-2012, Google Inc.
Copyright (c) 2002 Hansruedi Baer
Copyright (c) 2003 Hansruedi Baer
Copyright (c) 2009 Pierre Raybaut
Copyright (c) 2006 by Tavmjong Bah
Copyright (c) 2007-2008 Permission
Copyright (c) 2011 Ethan Schoonover
Copyright (c) 2002 by Kevin B. Kenny
Copyright (c) 1994, Basil K. Malyshev
Copyright (c) 2003 by Bitstream, Inc.
Copyright (c) 2010, Bartosz Telenczuk
copyright 2014, Matplotlib developers
(c) 2001-2010 by the STI Pub Companies
Copyright (c) 2002-2011 John D. Hunter
ECopyright (c) 2003 by Bitstream, Inc.
FCopyright (c) 2003 by Bitstream, Inc.
Copyright (c) 2001-2004 by Fredrik Lundh
Copyright (c) 2002-2005 Maxim Shemanarev
Copyright 2004 John Gill and John Hunter
Copyright The Matplotlib development team
Copyright (c) 1993-1996 Lucent Technologies
Copyright (c) 1994, 1995, Basil K. Malyshev
Portions copyright (c) 1990 by Elsevier, Inc.
Copyright (c) 1994-1998 Sun Microsystems, Inc.
Copyright (c) 2012- Matplotlib Development Team
Copyright (c) 1997 American Mathematical Society
Copyright (c) 1998-2000 by Scriptics Corporation
Copyright (c) 2001-2005 by the STI Pub Companies
Copyright (c) 2001-2010 by the STI Pub Companies
Copyright 1995, Trinity College Computing Center
LCopyright (c) 2001-2010 by the STI Pub Companies
Copyright (c) 1989, 1991 Adobe Systems Incorporated
Copyright (c) 2010-2013 by tyPoland Lukasz Dziedzic
Copyright (c) 2005 Tony Juricic (tonygeek@yahoo.com)
Portions copyright (c) 1998-2003 by MicroPress, Inc.
Copyright (c) Jeremy O'Donoghue & John Hunter, 2003-4
Copyright (c) 1997, 2009 American Mathematical Society
(c) Copyright 1989-1992, Bitstream Inc., Cambridge, MA.
Copyright 1990 as an unpublished work by Bitstream Inc.
Copyright (c) 1985, 1987, 1988 Adobe Systems Incorporated
Copyright (c) 1989, 1990, 1991 Adobe Systems Incorporated
Copyright (c) 1989, 1990, 1991, Adobe Systems Incorporated
Copyright (c) 2009 John Horigan (http://www.antigrain.com)
Copyright 2020- by the Matplotlib development team. :license
Copyright (c) 1985, 1987, 1988, 1989 Adobe Systems Incorporated
Copyright (c) 1985, 1987, 1988, 1991 Adobe Systems Incorporated
Copyright (c) 1985, 1987, 1989, 1990 Adobe Systems Incorporated
Copyright (c) 1985, 1987, 1989, 1991 Adobe Systems Incorporated
Copyright (c) 1985, 1987, 1989, 1992 Adobe Systems Incorporated
Copyright (c) 1996. The Regents of the University of California
Copyright (c) 2002-2005 Maxim Shemanarev (http://antigrain.com/)
Copyright (c) 2003-2004 Andrew Straw, Jeremy O'Donoghue and others
Copyright (c) 1987-1994 The Regents of the University of California
Copyright (c) 2002-2005 Maxim Shemanarev (http://www.antigrain.com)
Copyright (c) 1985, 1987, 1988, 1989, 1997 Adobe Systems Incorporated
Copyright (c) 1985, 1987, 1989, 1990, 1991 Adobe Systems Incorporated
Copyright (c) 1985, 1987, 1989, 1990, 1997 Adobe Systems Incorporated
Copyright (c) 1989, 1990, 1991, 1993, 1997 Adobe Systems Incorporated
Copyright (c) 1985, 1987, 1989, 1990, 1993, 1997 Adobe Systems Incorporated
Copyright (c) 1989, 1990, 1991, 1992, 1993, 1997 Adobe Systems Incorporated
Copyright (c) 1997, 2009, American Mathematical Society (http://www.ams.org)
Copyright (c) 2002 Cynthia Brewer, Mark Harrower, and The Pennsylvania State University
copyrighted by the Regents of the University of California, Sun Microsystems, Inc., Scriptics Corporation
copyright 2002-2012 John Hunter, Darren Dale, Eric Firing, Michael Droettboom and the Matplotlib development team f'2012- sourceyear The Matplotlib development team

PSF-2.0

---------------------------------------------------------

---------------------------------------------------------

typing-extensions 4.6.2 - Python-2.0


Copyright (c) 1995-2001 Corporation for National Research Initiatives
Copyright (c) 1991 - 1995, Stichting Mathematisch Centrum Amsterdam, The Netherlands
Copyright (c) 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022 Python Software Foundation

PYTHON SOFTWARE FOUNDATION LICENSE VERSION 2

   1. This LICENSE AGREEMENT is between the Python Software Foundation ("PSF"), and the Individual or Organization ("Licensee") accessing and otherwise using this software ("Python") in source or binary form and its associated documentation.

   2. Subject to the terms and conditions of this License Agreement, PSF hereby grants Licensee a nonexclusive, royalty-free, world-wide license to reproduce, analyze, test, perform and/or display publicly, prepare derivative works, distribute, and otherwise use Python alone or in any derivative version, provided, however, that PSF's License Agreement and PSF's notice of copyright, i.e., "Copyright (c) 2001, 2002, 2003, 2004, 2005, 2006 Python Software Foundation; All Rights Reserved" are retained in Python alone or in any derivative version prepared by Licensee.

   3. In the event Licensee prepares a derivative work that is based on or incorporates Python or any part thereof, and wants to make the derivative work available to others as provided herein, then Licensee hereby agrees to include in any such work a brief summary of the changes made to Python.

   4. PSF is making Python available to Licensee on an "AS IS" basis. PSF MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED. BY WAY OF EXAMPLE, BUT NOT LIMITATION, PSF MAKES NO AND DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF PYTHON WILL NOT INFRINGE ANY THIRD PARTY RIGHTS.

   5. PSF SHALL NOT BE LIABLE TO LICENSEE OR ANY OTHER USERS OF PYTHON FOR ANY INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF MODIFYING, DISTRIBUTING, OR OTHERWISE USING PYTHON, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED OF THE POSSIBILITY THEREOF.

   6. This License Agreement will automatically terminate upon a material breach of its terms and conditions.

   7. Nothing in this License Agreement shall be deemed to create any relationship of agency, partnership, or joint venture between PSF and Licensee. This License Agreement does not grant permission to use PSF trademarks or trade name in a trademark sense to endorse or promote products or services of Licensee, or any third party.

   8. By copying, installing or otherwise using Python, Licensee agrees to be bound by the terms and conditions of this License Agreement. BEOPEN.COM LICENSE AGREEMENT FOR PYTHON 2.0

BEOPEN PYTHON OPEN SOURCE LICENSE AGREEMENT VERSION 1

   1. This LICENSE AGREEMENT is between BeOpen.com ("BeOpen"), having an office at 160 Saratoga Avenue, Santa Clara, CA 95051, and the Individual or Organization ("Licensee") accessing and otherwise using this software in source or binary form and its associated documentation ("the Software").

   2. Subject to the terms and conditions of this BeOpen Python License Agreement, BeOpen hereby grants Licensee a non-exclusive, royalty-free, world-wide license to reproduce, analyze, test, perform and/or display publicly, prepare derivative works, distribute, and otherwise use the Software alone or in any derivative version, provided, however, that the BeOpen Python License is retained in the Software, alone or in any derivative version prepared by Licensee.

   3. BeOpen is making the Software available to Licensee on an "AS IS" basis. BEOPEN MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED. BY WAY OF EXAMPLE, BUT NOT LIMITATION, BEOPEN MAKES NO AND DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE ANY THIRD PARTY RIGHTS.

   4. BEOPEN SHALL NOT BE LIABLE TO LICENSEE OR ANY OTHER USERS OF THE SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THE SOFTWARE, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED OF THE POSSIBILITY THEREOF.

   5. This License Agreement will automatically terminate upon a material breach of its terms and conditions.

   6. This License Agreement shall be governed by and interpreted in all respects by the law of the State of California, excluding conflict of law provisions. Nothing in this License Agreement shall be deemed to create any relationship of agency, partnership, or joint venture between BeOpen and Licensee. This License Agreement does not grant permission to use BeOpen trademarks or trade names in a trademark sense to endorse or promote products or services of Licensee, or any third party. As an exception, the "BeOpen Python" logos available at http://www.pythonlabs.com/logos.html may be used according to the permissions granted on that web page.

   7. By copying, installing or otherwise using the software, Licensee agrees to be bound by the terms and conditions of this License Agreement. CNRI OPEN SOURCE LICENSE AGREEMENT (for Python 1.6b1) IMPORTANT: PLEASE READ THE FOLLOWING AGREEMENT CAREFULLY.

BY CLICKING ON "ACCEPT" WHERE INDICATED BELOW, OR BY COPYING, INSTALLING OR OTHERWISE USING PYTHON 1.6, beta 1 SOFTWARE, YOU ARE DEEMED TO HAVE AGREED TO THE TERMS AND CONDITIONS OF THIS LICENSE AGREEMENT.

   1. This LICENSE AGREEMENT is between the Corporation for National Research Initiatives, having an office at 1895 Preston White Drive, Reston, VA 20191 ("CNRI"), and the Individual or Organization ("Licensee") accessing and otherwise using Python 1.6, beta 1 software in source or binary form and its associated documentation, as released at the www.python.org Internet site on August 4, 2000 ("Python 1.6b1").

   2. Subject to the terms and conditions of this License Agreement, CNRI hereby grants Licensee a non-exclusive, royalty-free, world-wide license to reproduce, analyze, test, perform and/or display publicly, prepare derivative works, distribute, and otherwise use Python 1.6b1 alone or in any derivative version, provided, however, that CNRIs License Agreement is retained in Python 1.6b1, alone or in any derivative version prepared by Licensee.

   Alternately, in lieu of CNRIs License Agreement, Licensee may substitute the following text (omitting the quotes): "Python 1.6, beta 1, is made available subject to the terms and conditions in CNRIs License Agreement. This Agreement may be located on the Internet using the following unique, persistent identifier (known as a handle): 1895.22/1011. This Agreement may also be obtained from a proxy server on the Internet using the URL:http://hdl.handle.net/1895.22/1011".

   3. In the event Licensee prepares a derivative work that is based on or incorporates Python 1.6b1 or any part thereof, and wants to make the derivative work available to the public as provided herein, then Licensee hereby agrees to indicate in any such work the nature of the modifications made to Python 1.6b1.

   4. CNRI is making Python 1.6b1 available to Licensee on an "AS IS" basis. CNRI MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED. BY WAY OF EXAMPLE, BUT NOT LIMITATION, CNRI MAKES NO AND DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF PYTHON 1.6b1 WILL NOT INFRINGE ANY THIRD PARTY RIGHTS.

   5. CNRI SHALL NOT BE LIABLE TO LICENSEE OR ANY OTHER USERS OF THE SOFTWARE FOR ANY INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT OF USING, MODIFYING OR DISTRIBUTING PYTHON 1.6b1, OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED OF THE POSSIBILITY THEREOF.

   6. This License Agreement will automatically terminate upon a material breach of its terms and conditions.

   7. This License Agreement shall be governed by and interpreted in all respects by the law of the State of Virginia, excluding conflict of law provisions. Nothing in this License Agreement shall be deemed to create any relationship of agency, partnership, or joint venture between CNRI and Licensee. This License Agreement does not grant permission to use CNRI trademarks or trade name in a trademark sense to endorse or promote products or services of Licensee, or any third party.

   8. By clicking on the "ACCEPT" button where indicated, or by copying, installing or otherwise using Python 1.6b1, Licensee agrees to be bound by the terms and conditions of this License Agreement. ACCEPT CWI LICENSE AGREEMENT FOR PYTHON 0.9.0 THROUGH 1.2

Copyright (c) 1991 - 1995, Stichting Mathematisch Centrum Amsterdam, The Netherlands. All rights reserved.

Permission to use, copy, modify, and distribute this software and its documentation for any purpose and without fee is hereby granted, provided that the above copyright notice appear in all copies and that both that copyright notice and this permission notice appear in supporting documentation, and that the name of Stichting Mathematisch Centrum or CWI not be used in advertising or publicity pertaining to distribution of the software without specific, written prior permission.

STICHTING MATHEMATISCH CENTRUM DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH CENTRUM BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

---------------------------------------------------------

---------------------------------------------------------

waitress 2.1.2 - ZPL-2.1


Copyright 1996 by Sam Rushing
Copyright (c) 2002 Zope Foundation and Contributors
Copyright (c) 2004 Zope Foundation and Contributors
Copyright (c) 2005 Zope Foundation and Contributors
Copyright (c) 2013 Zope Foundation and Contributors
Copyright (c) 2001-2004 Zope Foundation and Contributors
Copyright (c) 2001-2005 Zope Foundation and Contributors
Copyright (c) 2001, 2002 Zope Foundation and Contributors
copyright 2012- s, Agendaless Consulting <chrism@plope.com>

Zope Public License (ZPL) Version 2.1 A copyright notice accompanies this license document that identifies the copyright holders.

This license has been certified as open source. It has also been designated as GPL compatible by the Free Software Foundation (FSF).

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

   1. Redistributions in source code must retain the accompanying copyright notice, this list of conditions, and the following disclaimer.

   2. Redistributions in binary form must reproduce the accompanying copyright notice, this list of conditions, and the following disclaimer in the documentation and/or other materials provided with the distribution.

   3. Names of the copyright holders must not be used to endorse or promote products derived from this software without prior written permission from the copyright holders.

   4. The right to distribute this software or to use it for any purpose does not give you the right to use Servicemarks (sm) or Trademarks (tm) of the copyright holders. Use of them is covered by separate agreement with the copyright holders.

   5. If any files are modified, you must cause the modified files to carry prominent notices stating that you changed the files and the date of any change.

Disclaimer

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

---------------------------------------------------------
