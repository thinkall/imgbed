import warnings

from flaml.automl.ml import *

warnings.warn(
    "Importing from `flaml.ml` is deprecated. Please use `flaml.automl.ml`.",
    DeprecationWarning,
)
