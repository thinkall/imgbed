import functools
import time
from typing import Any, Callable

from flaml.automl.logger import logger


def timer_decorator(func: Callable) -> Callable:
    """
    A decorator that measures the execution time of a function.

    Args:
        func: The function to be decorated

    Returns:
        wrapper: The wrapped function that includes timing functionality
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        execution_time = end_time - start_time
        logger.info(f"Function '{func.__name__}' took {execution_time:.4f} seconds to execute")
        return result

    return wrapper
