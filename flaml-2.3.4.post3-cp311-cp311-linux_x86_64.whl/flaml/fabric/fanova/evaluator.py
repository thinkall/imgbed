from typing import Dict, List, Optional, Tuple, Union

import numpy as np
from optuna._transform import _SearchSpaceTransform
from optuna.importance._base import BaseImportanceEvaluator
from sklearn.ensemble import RandomForestRegressor

from flaml.fabric.fanova.fanova import FanovaTree


class FanovaImportanceEvaluator(BaseImportanceEvaluator):
    """Cython accelerated fANOVA importance evaluator.

    Args:
        n_trees:
            The number of trees in the forest.
        max_depth:
            The maximum depth of the trees in the forest.
        seed:
            Controls the randomness of the forest. For deterministic behavior, specify a value
            other than :obj:`None`.
        completed_trials:
            Avoid to call ``study.get_trials()`` and use this value instead (default: None).
    """

    def __init__(
        self,
        *,
        n_trees: int = 64,
        max_depth: int = 64,
        seed: Optional[int] = None,
    ) -> None:
        self._forest = RandomForestRegressor(
            n_estimators=n_trees,
            max_depth=max_depth,
            min_samples_split=2,
            min_samples_leaf=1,
            random_state=seed,
        )

    def evaluate(
        self,
        hp_df,
        scores,
        search_space,
    ) -> Dict[str, float]:
        hp_df.reset_index(drop=True, inplace=True)
        if len(search_space) == 0:
            return {}

        # fANOVA does not support parameter distributions with a single value.
        # However, there is no reason to calculate parameter importance in such case anyway,
        # since it will always be 0 as the parameter is constant in the objective function.

        # Many (deep) copies of the search spaces are required during the tree traversal and using
        # Optuna distributions will create a bottleneck.
        # Therefore, search spaces (parameter distributions) are represented by a single
        # `numpy.ndarray`, coupled with a list of flags that indicate whether they are categorical
        # or not.
        trans = _SearchSpaceTransform(search_space, transform_log=False, transform_step=False)
        n_trials = len(hp_df)
        trans_params = np.empty((n_trials, trans.bounds.shape[0]), dtype=np.float64)
        trans_values = np.asarray(scores, dtype=np.float64)

        for trial_idx, series in hp_df.iterrows():
            trans_params[trial_idx] = trans.transform(series.to_dict())

        if trans_params.size == 0:  # `params` were given but as an empty list.
            return {}

        self._forest.fit(X=trans_params, y=trans_values)

        importances = compute_importance(self._forest, trans, search_space.keys())
        total_importance = sum(importances.values())
        for name in importances:
            importances[name] /= total_importance

        return importances


def compute_importance(
    forest: RandomForestRegressor,
    transform: _SearchSpaceTransform,
    param_names: List[str],
) -> Dict[str, float]:
    search_spaces = transform.bounds
    trees = [FanovaTree(e.tree_, search_spaces) for e in forest.estimators_]

    if all(tree.variance == 0 for tree in trees):
        # If all trees have 0 variance, we cannot assess any importances.
        # This could occur if for instance `X.shape[0] == 1`.
        raise RuntimeError("Encountered zero total variance in all trees.")

    variances = np.empty(shape=(len(param_names), len(trees)), dtype=np.float64)
    importances = {}

    for i, name in enumerate(param_names):
        raw_feature = transform.column_to_encoded_columns[i]
        for tree_index, tree in enumerate(trees):
            marginal_variance = tree.get_marginal_variance(raw_feature)
            variances[i, tree_index] = np.clip(marginal_variance, 0.0, None)

        importance, _ = get_importance(trees, i, variances)
        importances[name] = importance

    return importances


def get_importance(
    trees: List[FanovaTree],
    feature: int,
    variances: np.ndarray,
) -> Tuple[float, float]:
    fractions: Union[List[float], np.ndarray] = []

    for tree_index, tree in enumerate(trees):
        tree_variance = tree.variance
        if tree_variance > 0.0:
            fraction = variances[feature, tree_index] / tree_variance
            fractions = np.append(fractions, fraction)

    fractions = np.asarray(fractions)
    return float(fractions.mean()), float(fractions.std())
