from pyspark.sql import SparkSession
import sys


def logInfoPy(msg: str):
    try:
        spark = SparkSession.getActiveSession()
        if spark is None:
            raise Exception("No Active Session found.")
        spark.sparkContext._jvm.com.microsoft.azure.synapse.ml.pandas.SynapseMLPandasLogger.logInfoEvent(
            msg
        )
    except Exception:
        logInfoSys(msg)
        return False


def logWarningPy(msg: str):
    try:
        spark = SparkSession.getActiveSession()
        if spark is None:
            raise Exception("No Active Session found.")
        spark.sparkContext._jvm.com.microsoft.azure.synapse.ml.pandas.SynapseMLPandasLogger.logWarningEvent(
            msg
        )
    except Exception:
        logWarningSys(msg)
        return False


def logErrorPy(msg: str):
    try:
        spark = SparkSession.getActiveSession()
        if spark is None:
            raise Exception("No Active Session found.")
        spark.sparkContext._jvm.com.microsoft.azure.synapse.ml.pandas.SynapseMLPandasLogger.logErrorEvent(
            msg
        )
    except Exception:
        logErrorSys(msg)
        return False


def logInfoSys(msg: str):
    try:
        print("SynapseMLPandas: ", msg, file=sys.stderr)
    except Exception:
        return False


def logWarningSys(msg: str):
    try:
        print("SynapseMLPandas: ", msg, file=sys.stderr)
    except Exception:
        return False


def logErrorSys(msg: str):
    try:
        print("SynapseMLPandas: ", msg, file=sys.stderr)
    except Exception:
        return False


info = warning = error = None


def init():
    global info, warning, error
    try:
        spark = SparkSession.getActiveSession()
        if spark is None:
            raise Exception("No Active Session found.")
        info = logInfoPy
        warning = logWarningPy
        error = logErrorPy
    except Exception:
        info = logInfoSys
        warning = logWarningSys
        error = logErrorSys


init()
