from pyspark.sql import SparkSession
from .common import SynapseCredential
from azure.core.credentials import AccessToken


class TokenServiceClient:

    def __init__(self, *args, **kwargs):
        pass

    def get_account_name_and_credential_of_linked_service(
        self, linked_service: str = ""
    ) -> (str, "SynapseCredential"):
        """Gets account_name and credentials for the given linked service.

        Args:
        linked_service: Linked service name.

        Returns:
        account_name and credentials.

        Raises:
        Exception: If unable to fetch credentials and other details.
        """
        try:
            from urllib.parse import urlparse

            # primary datalake storage linked service name
            if not linked_service:
                workspace_name = self._get_workspace_name()
                linked_service = workspace_name + "-WorkspaceDefaultStorage"

            spark = (
                SparkSession.builder.appName("SynapseCredentialPy")
                .config("spark.executor.allowSparkContext", "true")
                .getOrCreate()
            )
            token_library = (
                spark._jvm.com.microsoft.azure.synapse.tokenlibrary.TokenLibrary
            )
            full_connection_string = token_library.getFullConnectionString(
                linked_service
            )
            _full_connection_string = full_connection_string.split(";")
            url = _full_connection_string[0][4:]
            account_name = urlparse(url).netloc.split(".")[0]
            token = _full_connection_string[1][6:]
            # SAS token check
            if token.startswith("?"):
                return account_name, token
            token_exp = self._get_token_exp(token)
            _token = AccessToken(token, token_exp)
            credential = SynapseCredential(token=_token)

            return account_name, credential
        except Exception as exception:
            raise Exception(f"Unable to get account_name and credential {exception}")

    def get_aad_credential(self, audience: str) -> "SynapseCredential":
        """Gets AAD credentials.

        Args:
        audience: Audience for resource template.

        Returns:
        credentials.

        Raises:
        Exception: If unable to fetch credentials.
        """
        try:
            spark = (
                SparkSession.builder.appName("SynapseCredentialPy")
                .config("spark.executor.allowSparkContext", "true")
                .getOrCreate()
            )
            token_library = (
                spark._jvm.com.microsoft.azure.synapse.tokenlibrary.TokenLibrary
            )
            resource = """{"audience": "%s", "name": ""}""" % audience
            access_token = token_library.getAccessToken(resource)
            _token = AccessToken(access_token.token(), int(access_token.expireTime()))
            credential = SynapseCredential(token=_token)

            return credential
        except Exception as exception:
            raise Exception("Unable to fetch credentials.", exception)

    def _get_workspace_name(self) -> str:
        sc = (
            SparkSession.builder.appName("SynapseCredentialPy")
            .config("spark.executor.allowSparkContext", "true")
            .getOrCreate()
        )
        envc = sc._jvm.mssparkutils.env
        workspace = envc.getWorkspaceName()

        return workspace

    def _get_token_exp(self, token: str) -> int:
        """Gets expiration of the token.

        Args:
        token: Token.

        Returns:
        expiration time.
        """
        import jwt

        payload = jwt.decode(token, options={"verify_signature": False})
        return payload["exp"]
