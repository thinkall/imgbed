AUTOML_DISPLAY_CONFIGURATIONS = [
    "task",
    "automl_mode",
    "metric",
    "time_budget",
    "early_stop",
    "featurization",
]
